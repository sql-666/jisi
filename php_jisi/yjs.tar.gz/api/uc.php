<?php
define('IQWPHP_PATH', '../');
define('APP_NAME', 'uc');
define('APP_PATH', './uc/');
define('IQW_DATA_PATH', '../data/');
define('RUNTIME_PATH', IQW_DATA_PATH . 'runtime/uc/');
define('APP_DEBUG', false);
require("./_core/setup.php");