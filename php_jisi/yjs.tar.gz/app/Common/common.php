<?php



function wxConfig(){

	return array("appid"=>"wx3bb6874285a7d01e","appsecret"=>"b3396de61ec0fb86aac3592223125e3b"); //唱将

}



//获取用户头像，判断是否微信头像为空，否则返回用户头像

function getwxImg($uid,$imgUrl='',$imgSize='240',$rand=false){

	if(empty($imgUrl)){

		$str = avatar($uid, $imgSize);

		$rand && $str .= '?'.mktime();

	}else{

		$str = $imgUrl;

	}

	return $str;

}



function getSex($gender){

	switch($gender){

		case 0:

		$str = ""; break; // 未知

		case 1:

		$str = "帅哥"; break;

		case 2:

		$str = "美女"; break;

	}

	return $str;

}

 

function getRealImg($imgStr,$flag=1){

// $flag 1 获取缩例图  2 获取原图 3获取文件名 4获取文件后缀

$ret = "";

if($imgStr){

	$firstFlag = strripos($imgStr,"/");

	$lastFlag = strripos($imgStr,".");

	switch($flag){

		case 1: //1 获取缩例图

		$e_fix = substr($imgStr,$lastFlag,5); //后缀.jpg

		$s_fix = substr($imgStr,0,$lastFlag); //前缀

		$ret = $s_fix . "_thumb" . $e_fix; // 500*500小图

		break;

		case 2: //2 根据缩例图获取原图

		$ret = str_replace('_thumb','',$imgStr);

		break;

		case 3: //3获取文件名（不含后缀）

		$ret = substr($imgStr,$firstFlag+1,$lastFlag-$firstFlag-1);

		break;

		case 4: //4获取文件后缀

		$ret = substr($imgStr,$lastFlag+1);

		break;

		case 5: //获取宽、高信息

		$ScaleFlag = strripos($imgStr,"Scale");

		if($ScaleFlag<1) return false;

		$temp = substr($imgStr,$ScaleFlag+5,$lastFlag-$ScaleFlag-5);

		if($temp){

			$ret = explode("X",$temp);

		}

		break;

	}

}

return $ret;

}



function addslashes_deep($value) {

    $value = is_array($value) ? array_map('addslashes_deep', $value) : addslashes($value);

    return $value;

}



function stripslashes_deep($value) {

    if (is_array($value)) {

        $value = array_map('stripslashes_deep', $value);

    } elseif (is_object($value)) {

        $vars = get_object_vars($value);

        foreach ($vars as $key => $data) {

            $value->{$key} = stripslashes_deep($data);

        }

    } else {

        $value = stripslashes($value);

    }



    return $value;

}



function todaytime() {

    return mktime(0, 0, 0, date('m'), date('d'), date('Y'));

}



/**

 * 友好时间

 */

function fdate($time) {

    if (!$time)

        return false;

    $fdate = '';

    $d = time() - intval($time);

    $ld = $time - mktime(0, 0, 0, 0, 0, date('Y')); //年

    $md = $time - mktime(0, 0, 0, date('m'), 0, date('Y')); //月

    $byd = $time - mktime(0, 0, 0, date('m'), date('d') - 2, date('Y')); //前天

    $yd = $time - mktime(0, 0, 0, date('m'), date('d') - 1, date('Y')); //昨天

    $dd = $time - mktime(0, 0, 0, date('m'), date('d'), date('Y')); //今天

    $td = $time - mktime(0, 0, 0, date('m'), date('d') + 1, date('Y')); //明天

    $atd = $time - mktime(0, 0, 0, date('m'), date('d') + 2, date('Y')); //后天

    if ($d == 0) {

        $fdate = '刚刚';

    } else {

        switch ($d) {

            case $d < $atd:

                $fdate = date('Y年m月d日', $time);

                break;

            case $d < $td:

                $fdate = '后天' . date('H:i', $time);

                break;

            case $d < 0:

                $fdate = '明天' . date('H:i', $time);

                break;

            case $d < 60:

                $fdate = $d . '秒前';

                break;

            case $d < 3600:

                $fdate = floor($d / 60) . '分钟前';

                break;

            case $d < $dd:

                $fdate = floor($d / 3600) . '小时前';

                break;

            case $d < $yd:

                $fdate = '昨天' . date('H:i', $time);

                break;

            case $d < $byd:

                $fdate = '前天' . date('H:i', $time);

                break;

            case $d < $md:

                $fdate = date('m月d H:i', $time);

                break;

            case $d < $ld:

                $fdate = date('m月d', $time);

                break;

            default:

                $fdate = date('Y年m月d日', $time);

                break;

        }

    }

    return $fdate;

}



/**

 * 获取用户头像

 */

function avatar($uid, $size,$wximg= "") {

	if($wximg){ return  $wximg;}	//微信头像优先显示

	

    $avatar_size = explode(',', C('iqw_avatar_size'));

    $size = in_array($size, $avatar_size) ? $size : '120';

    $avatar_dir = avatar_dir($uid);

    $avatar_file = $avatar_dir . md5($uid) . "_{$size}.jpg";

    if (!is_file(C('iqw_attach_path') . 'avatar/' . $avatar_file)) {

        $avatar_file = "default_{$size}.jpg";

    }

    return __ROOT__ . '/' . C('iqw_attach_path') . 'avatar/' . $avatar_file;

}



function avatar_dir($uid) {

    $uid = abs(intval($uid));

	return "mem_".$uid."/";

}



function attach($imgSrc, $type) {

    if (false === strpos($imgSrc, 'http://')) {	//本地附件

		if(substr($imgSrc,0,1)=="/"){	//如果第一个以/开头,表明是绝对地址		

			return  $imgSrc;

		}        

        return  __ROOT__ . '/' . C('iqw_attach_path') . $type . '/' . $imgSrc;

       

    }else{ 	//远程附件

        return  $imgSrc;

    }

}





/**

 * 获取教师头像

 */

function avatar1($uid, $size) {

    $avatar_size = explode(',', C('iqw_avatar_size'));

    $size = in_array($size, $avatar_size) ? $size : '120';

    $avatar_dir = avatar_dir1($uid);

    $avatar_file = $avatar_dir . md5($uid) . "_{$size}.jpg";

    if (!is_file(C('iqw_attach_path') . 'teacher/' . $avatar_file)) {

        $avatar_file = "default_{$size}.jpg";

    }

    return __ROOT__ . '/' . C('iqw_attach_path') . 'teacher/' . $avatar_file;

}



function avatar_dir1($uid) {

    $uid = abs(intval($uid));

	return "mem_".$uid."/";

}



/**

 * 获取业务员头像

 */

function avatar2($uid, $size) {

    $avatar_size = explode(',', C('iqw_avatar_size'));

    $size = in_array($size, $avatar_size) ? $size : '120';

    $avatar_dir = avatar_dir2($uid);

    $avatar_file = $avatar_dir . md5($uid) . "_{$size}.jpg";

    if (!is_file(C('iqw_attach_path') . 'business/' . $avatar_file)) {

        $avatar_file = "default_{$size}.jpg";

    }

    return __ROOT__ . '/' . C('iqw_attach_path') . 'business/' . $avatar_file;

}



function avatar_dir2($uid) {

    $uid = abs(intval($uid));

	return "mem_".$uid."/";

}





/**

 * 获取会员等级图片

 */

function avatar3($uid, $size) {

    $avatar_size = explode(',', C('iqw_avatar_size'));

    $size = in_array($size, $avatar_size) ? $size : '120';

    $avatar_dir = avatar_dir3($uid);

    $avatar_file = $avatar_dir . md5($uid) . "_{$size}.jpg";

    if (!is_file(C('iqw_attach_path') . 'other_set/' . $avatar_file)) {

        $avatar_file = "default_{$size}.jpg";

    }

    return __ROOT__ . '/' . C('iqw_attach_path') . 'other_set/' . $avatar_file;

}



function avatar_dir3($uid) {

    $uid = abs(intval($uid));

	return "mem_".$uid."/";

}





/*

 * 获取缩略图

 */



function get_thumb($img, $suffix = '_thumb') {

	if(false == strpos($img, '.')){//图片为空

			return $img."nopic.gif";

	}

    if(false === strpos($img, 'http://')) {

			$ext = array_pop(explode('.', $img));

			if(strpos($img, '/upload/album/') && $suffix == "_b" ){//分享图片单独处理

				$suffix = "_m";

			}

			$thumb = str_replace('.' . $ext, $suffix . '.' . $ext, $img);

    }else {

        if (false !== strpos($img, 'taobaocdn.com') || false !== strpos($img, 'taobao.com')) {

            //淘宝图片 _s _m _b

            switch ($suffix) {

                case '_s':

                    $thumb = $img . '_100x100.jpg';

                    break;

                case '_m':

                    $thumb = $img . '_210x1000.jpg';

                    break;

                case '_b':

                    $thumb = $img . '_480x480.jpg';

                    break;

            }

        }else{

			return $img;//获取远程视频图片

		}

    }

    return $thumb;

}





/**

 * 字符串截取，支持中文和其他编码

 * static 

 * access public

 * @param string $str 需要转换的字符串

 * @param string $start 开始位置

 * @param string $length 截取长度

 * @param string $charset 编码格式

 * @param string $suffix 截断显示字符

 * return string

 */

function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true) {

    if(function_exists("mb_substr"))

        $slice = mb_substr($str, $start, $length, $charset);

    elseif(function_exists('iconv_substr')) {

        $slice = iconv_substr($str,$start,$length,$charset);

        if(false === $slice) {

            $slice = '';

        }

    }else{

        $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";

        $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";

        $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";

        $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";

        preg_match_all($re[$charset], $str, $match);

        $slice = join("",array_slice($match[0], $start, $length));

    }

    return $suffix ? $slice.'...' : $slice;

}

 

/**

 * 对象转换成数组

 */

function object_to_array($obj) {

    $_arr = is_object($obj) ? get_object_vars($obj) : $obj;

    foreach ($_arr as $key => $val) {

        $val = (is_array($val) || is_object($val)) ? object_to_array($val) : $val;

        $arr[$key] = $val;

    }

    return $arr;

}

 





//获取用户真实IP

function get_client_ip2() {

	if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))

		$ip = getenv("HTTP_CLIENT_IP");

	else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), 

"unknown"))

		$ip = getenv("HTTP_X_FORWARDED_FOR");

	else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))

		$ip = getenv("REMOTE_ADDR");

	else if (isset ($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] 

&& strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))

		$ip = $_SERVER['REMOTE_ADDR'];

	else

		$ip = "unknown";

	return ($ip);

}



function p($myarr){

	print_r($myarr);return;

}



//过滤数组元素两边空格



function trimArray($Input){

 

    if (!is_array($Input))

        return trim($Input);

 

    return array_map('trimArray', $Input);

}



// 从textArea中获取数组

function getTextArray($str){

	//处理数组

	if(!empty($str)){

		 $tmpArr = split(PHP_EOL,$str);//分离出来数组

		 $tmpArr = array_filter($tmpArr);//过滤空元素

		 $tmpArr = trimArray($tmpArr); //去除数据元素两边空格

	}

	return $tmpArr;

}



function goUrl($url){

	header("Location: $url");

	echo "<script language='javascript' type='text/javascript'>";

	echo "window.location.href='$url'";

	echo "</script>";

}



//获取汉语首字母

function getFirstChar($str){  

	if(empty($str)){return '';}

	$ret = "#";

	$fchar=ord($str{0});  

	if($fchar>=ord('A')&&$fchar<=ord('z')) return strtoupper($str{0});  

	$s1=iconv('UTF-8','gb2312',$str);  

	$s2=iconv('gb2312','UTF-8',$s1);  

	$s=$s2==$str?$s1:$str;  

	$asc=ord($s{0})*256+ord($s{1})-65536;  

	if($asc>=-20319&&$asc<=-20284) $ret = 'A';  

	if($asc>=-20283&&$asc<=-19776) $ret = 'B';  

	if($asc>=-19775&&$asc<=-19219) $ret = 'C';  

	if($asc>=-19218&&$asc<=-18711) $ret = 'D';  

	if($asc>=-18710&&$asc<=-18527) $ret = 'E';  

	if($asc>=-18526&&$asc<=-18240) $ret = 'F';  

	if($asc>=-18239&&$asc<=-17923) $ret = 'G';  

	if($asc>=-17922&&$asc<=-17418) $ret = 'H';  

	if($asc>=-17417&&$asc<=-16475) $ret = 'J';  

	if($asc>=-16474&&$asc<=-16213) $ret = 'K';  

	if($asc>=-16212&&$asc<=-15641) $ret = 'L';  

	if($asc>=-15640&&$asc<=-15166) $ret = 'M';  

	if($asc>=-15165&&$asc<=-14923) $ret = 'N';  

	if($asc>=-14922&&$asc<=-14915) $ret = 'O';  

	if($asc>=-14914&&$asc<=-14631) $ret = 'P';  

	if($asc>=-14630&&$asc<=-14150) $ret = 'Q';  

	if($asc>=-14149&&$asc<=-14091) $ret = 'R';  

	if($asc>=-14090&&$asc<=-13319) $ret = 'S';  

	if($asc>=-13318&&$asc<=-12839) $ret = 'T';  

	if($asc>=-12838&&$asc<=-12557) $ret = 'W';  

	if($asc>=-12556&&$asc<=-11848) $ret = 'X';  

	if($asc>=-11847&&$asc<=-11056) $ret = 'Y';  

	if($asc>=-11055&&$asc<=-10247) $ret = 'Z';

	return $ret;  

}



//获取当前完整URL

function getCurUrl() 

{

    $pageURL = 'http';



    if ($_SERVER["HTTPS"] == "on") 

    {

        $pageURL .= "s";

    }

    $pageURL .= "://";



    if ($_SERVER["SERVER_PORT"] != "80") 

    {

        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];

    } 

    else 

    {

        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];

    }

    return $pageURL;

}



//获取当前网址

function getWebsiteUrl(){

	$pageURL = 'http'; 

    if ($_SERVER["HTTPS"] == "on") {    // 如果是SSL加密则加上"s" 

        $pageURL .= "s"; 

    } 

    $pageURL .= "://"; 

    if ($_SERVER["SERVER_PORT"] != "80") { 

        $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"];

    } else { 

        $pageURL .= $_SERVER["SERVER_NAME"];

    } 

    return $pageURL; 

}



/* 获得当前页面完整URL */ 

function getBaseUrl() { 

    $pageURL = 'http'; 

    if ($_SERVER["HTTPS"] == "on") {    // 如果是SSL加密则加上"s" 

        $pageURL .= "s"; 

    } 

    $pageURL .= "://"; 

    if ($_SERVER["SERVER_PORT"] != "80") { 

        $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"]; 

    } else { 

        $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"]; 

    } 

    return $pageURL; 

} 



//获取积分描述



function getScoreName($say,$mname=''){



	switch($say){



	    case 'login' : $str =  '登陆' ; break;



		case 'register' : $str =  '注册'; break;  



		case 'qiandao'  : $str =  '签到'; break;



		case 'tuijian'  : $str =  '推荐注册'; break;



		case 'pubitem'  : $str =  '发布作品' ; break;



		case 'sharerwjifen'  : $str =  '分享推广任务'; break;



		case 'pubcmt'  : $str =  '发布评论'; break;



		case 'getdhjifen'  : $str =  '商品获取积分'; break;	



		case 'exchange' : $str =  '兑换商品'; break;



		case 'sysman' : $str =  '管理员'.$mname.'更改余额'; break;



	}



	return $str;



}


	//json 输出格式

   function tojson($code,$msg,$data = ''){
		//当data为空 
		$str = array(
				'code' => $code,
				'msg' => $msg,
				'data' => ""
		);
		//当$data  不为空
		$array = array(
				'code' => $code,
				'msg' => $msg,
				'data' => $data
		);
		$data = $data==''?$str:$array;
		echo json_encode($data);
		exit;

	}
	
	function strim($str){
		//trim() 函数移除字符串两侧的空白字符或其他预定义字符。
		//htmlspecialchars() 函数把预定义的字符转换为 HTML 实体(防xss攻击)。
		//预定义的字符是：
		//& （和号）成为 &amp;
		//" （双引号）成为 &quot;
		//' （单引号）成为 '
		//< （小于）成为 &lt;
		//> （大于）成为 &gt;
		return quotes(htmlspecialchars(trim($str)));
	}
	//防sql注入
	 function quotes($content){
		//if $content is an array
		if (is_array($content)){
			foreach ($content as $key=>$value){
				//$content[$key] = mysql_real_escape_string($value);
				/*addslashes() 函数返回在预定义字符之前添加反斜杠的字符串。
				预定义字符是：
				单引号（'）
				双引号（"）
				反斜杠（\）
				NULL */
				$content[$key] = addslashes($value);
			}
		}else{
			//if $content is not an array
			//$content=mysql_real_escape_string($content);
			$content=addslashes($content);
		}
		return $content;
	}
	



