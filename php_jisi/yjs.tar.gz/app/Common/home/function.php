<?php
	

function UWX($url='',$vars='',$suffix=true,$redirect=false,$domain=false) {
	$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $retUrl = "$protocol$_SERVER[HTTP_HOST]";
	return  $retUrl.U($url,$vars,$suffix,$redirect,$domain);
}

//获取广告 tom
	function Ad_base($adid,$typeid=0){
		$model = M('Ad');
		$ctime = mktime();
		$timeSql = " and $ctime >= start_time and $ctime <= end_time and status = 1";
		if($typeid==0){//按ID调取广告
			if(is_int($adid)){//调取一条
				return $model->where(" id= '$adid'".$timeSql)->find();
			}else{//in  id
				return $model->where(" id in ('$adid')".$timeSql)->order("ordid desc,id desc")->select();
			}
		}else{//调取一组广告
			return $model->where(" board_id = '$typeid' ".$timeSql)->order("ordid desc,id desc")->select();
		}
	}
	
	//显示消息提醒
	function showmsg($type,$num){
		if(empty($type)) return;
		switch($type){
			case 1:
				$tip = "你有一条新评论";break;
			case 2:
				$tip = "你有一条新的召集报名,报名".$num."人";break;
			case 3:
				$tip = "你有一条新的关注";break;
			case 4:
				$tip = "你收到一条新的赞";break;
			case 5:
				$tip = "你参加过的召集，可以去评分";break;
		}
		return $tip;
	}

	//多图上传
	function JS($str){
	return str_replace('./', '', str_replace('//', '/', $str));
	}
	function J($str){
	return str_replace('./', '', str_replace('//', '/', $str));
	}
	
	
	//------------------微信JSDK-------------------
	
	function https_requestwx($url, $data = null){
	  $curl = curl_init();
	  curl_setopt($curl, CURLOPT_URL, $url);
	  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	  if (!empty($data)){
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	  }
	  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	  $output = curl_exec($curl);
	  curl_close($curl);
	  return $output;
	}
	
	
	function get_php_file($filename) {
		  return trim(substr(file_get_contents($filename), 15));
	}
	
	
	function set_php_file($filename, $content) {
		  $fp = fopen($filename, "w");
		  fwrite($fp, "<?php exit();?>" . $content);
		  fclose($fp);
	}
	
	//设置Cooike，保存用户名和密码
	function setCookieUser($username,$password){
		cookie("ulogin",array("username"=>$username,"password"=>$password),3600*24*7*12);
	}
	
	//检测是否微信浏览器-全局（不严谨）
	function is_qjweixin(){ 
	if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ) {
				return true;
		}	
		return false;
	}
	
	
	
	//检测手机号

	function check_phone($phonenumber){

		if(preg_match("/^1[34578]{1}\d{9}$/",$phonenumber)){  

			return true; 	//"是手机号码";  

		}else{  

			return false;

		}  

	}
	
	
	
?>