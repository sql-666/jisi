<?php 

require_once "WxPay.Data.php";

class WxPayApi{

	public static $certPath,$keyPath;

	//下单

	public static function unifiedOrder	($inputObj){

		$url = "https://api.mch.weixin.qq.com/pay/unifiedorder";

		if(!$inputObj->issetData('out_trade_no')) {

			die('缺少统一支付接口必填参数out_trade_no！');

		}else if(!$inputObj->issetData('body')){

			die('缺少统一支付接口必填参数body！');

		}else if(!$inputObj->issetData('total_fee')) {

			die('缺少统一支付接口必填参数total_fee！');

		}else if(!$inputObj->issetData('openid')) {

			die('缺少统一支付接口必填参数openid！');

		}

		$inputObj->setData('spbill_create_ip',$_SERVER['REMOTE_ADDR']);

		$inputObj->setData('trade_type',"JSAPI");

		$inputObj->SetAppId();

		$inputObj->SetMchId();

		$inputObj->SetNonce_str();

		$inputObj->SetSign();

		$xml = $inputObj->ToXml();

		$response = self::postXmlCurl($xml, $url);

		$result = WxPayResults::Init($response);

		return $result;

	}

	// 查询订单

	public static function orderQuery($inputObj) {

		$url = "https://api.mch.weixin.qq.com/pay/orderquery";

		//检测必填参数

		if(!$inputObj->issetData('out_trade_no') && !$inputObj->issetData('transaction_id')) {

			die("订单查询接口中，out_trade_no、transaction_id至少填一个！");

		}

		$inputObj->SetAppId();

		$inputObj->SetMchId();

		$inputObj->SetNonce_str();

		$inputObj->SetSign();

		$xml = $inputObj->ToXml();	

		$response = self::postXmlCurl($xml, $url);

		$result = WxPayResults::Init($response);

		return $result;

	}

	// 退款

	public static function refund($inputObj){

//	    var_dump($inputObj);die();

		$url = "https://api.mch.weixin.qq.com/secapi/pay/refund";

		if(!$inputObj->issetData('out_trade_no') && !$inputObj->issetData('ransaction_id')) {

			throw new Exception("退款申请接口中，out_trade_no、transaction_id至少填一个！");

		}else if(!$inputObj->issetData('out_refund_no')){

			die("退款申请接口中，缺少必填参数out_refund_no！");

		}else if(!$inputObj->issetData('total_fee')){

			die("退款申请接口中，缺少必填参数total_fee！");

		}else if(!$inputObj->issetData('refund_fee')){

			die("退款申请接口中，缺少必填参数refund_fee！");

		}else if(!$inputObj->issetData('op_user_id')){

			die("退款申请接口中，缺少必填参数op_user_id！");

		}

		// 需要证书

		$wechat_id = \Yii::$app->session->get('wechat_id');

        self::$certPath = dirname(__FILE__)."/cert/".md5($wechat_id)."apiclient_cert.pem";

        self::$keyPath = dirname(__FILE__)."/cert/".md5($wechat_id)."apiclient_key.pem";

		if(!file_exists(self::$certPath) || !file_exists(self::$keyPath)){

            self::$certPath = dirname(__FILE__)."/cert/apiclient_cert.pem";

            self::$keyPath = dirname(__FILE__)."/cert/apiclient_key.pem";

//			throw new Exception('证书不存在', 1);

		}

		$inputObj->SetAppId();

		$inputObj->SetMchId();

		$inputObj->SetNonce_str();

		$inputObj->SetSign();

		$xml = $inputObj->ToXml();

//		$response = self::postXmlCurl($xml, $url,true);

		$response = self::postXmlCurl($xml, $url,true);

		$result = WxPayResults::Init($response);

		return $result;

	}

	// 下载对账单

	public static function downloadBill($inputObj) {

		$url = "https://api.mch.weixin.qq.com/pay/downloadbill";

		if(!$inputObj->issetData('bill_date')) {

			die("对账单接口中，缺少必填参数bill_date！");

		}

		$inputObj->SetAppId();

		$inputObj->SetMchId();

		$inputObj->SetNonce_str();

		$inputObj->SetSign();

		$xml = $inputObj->ToXml();

		$response = self::postXmlCurl($xml, $url);

		if(substr($response, 0 , 5) == "<xml>"){

			return "";

		}

		return $response;

	}



    /**

     * 以post方式提交xml到对应的接口url

     * @param string $xml  需要post的xml数据

     * @param string $url  url

     * @param bool $useCert 是否需要证书，默认不需要

     * @param int $second   url执行超时时间，默认30s

     * @throws WxPayException

     */

    private static function postXmlCurl($xml, $url, $useCert = false, $second = 30)

    {

        $ch = curl_init();

        // 设置超时

        curl_setopt($ch, CURLOPT_TIMEOUT, $second);



        curl_setopt($ch,CURLOPT_URL, $url);

        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);

        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);//严格校验

        //设置header

        curl_setopt($ch, CURLOPT_HEADER, FALSE);

        // 要求结果为字符串且输出到屏幕上

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);



        if($useCert == true){

            //设置证书

            //使用证书：cert 与 key 分别属于两个.pem文件

            curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');

            curl_setopt($ch,CURLOPT_SSLCERT, self::$certPath);

            curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');

            curl_setopt($ch,CURLOPT_SSLKEY, self::$keyPath);

        }

        //post提交方式

        curl_setopt($ch, CURLOPT_POST, TRUE);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);

        //运行curl

        $data = curl_exec($ch);

        //返回结果

        if($data){

            curl_close($ch);

            return $data;

        } else {

            $error = curl_errno($ch);

            curl_close($ch);

            return array(

                'code' => $error,

                'msg'  => 'curl 出错',

            );

//            throw new Exception("curl出错，错误码:$error");

        }

    }



}

?>