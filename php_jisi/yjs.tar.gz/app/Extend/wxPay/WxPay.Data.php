<?php 


class WxPayDataBase {

	protected $values = array();

	protected static $config;

	public function __construct(){

		if(isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input")){

		    $xml =isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");

		    // 验证xml

		    $res = $this->xml_parser($xml);

		    if ($res){

                $xmlObj = $this->FromXml(isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input"));


            }else{


            }



		}else{


		}

		self::$config['appid'] = 'wx125db524eb3601a6';//appid

		self::$config['mch_id'] = '1447715102';//账号

		self::$config['key'] = 'EnMei32klDSIkl32jDSKLj1309DSLj23';//key

	}



    /**

     * @param $str

     * @return bool|mixed

     * 验证是否是xml

     */

    private function xml_parser($str){

        $xml_parser = xml_parser_create();

        if(!xml_parse($xml_parser,$str,true)){

            xml_parser_free($xml_parser);

            return false;

        }else {

            return (json_decode(json_encode(simplexml_load_string($str)),true));

        }

    }



    public function getAppid () {

		return self::$config['appid'];

	}

	public function getMchid(){

		return self::$config['mch_id'];

	}

	public function clearValues(){

		$this->values = array();

	}

	public function setData($name,$value){

		$this->values[$name] = $value;

	}

	public function getData($name){

		return $this->values[$name];

	}

	public function issetData($name){

		return array_key_exists($name, $this->values);

	}

	public function SetSign() {

		$sign = $this->MakeSign();

		$this->values['sign'] = $sign;

		return $sign;

	}

	public function SetNonce_str(){

		$nonce_str = $this->getNonceStr();

		$this->values['nonce_str'] = $nonce_str;

		return $nonce_str;

	}

	public function SetAppId(){

		$this->values['appid'] = self::$config['appid'];

	}

	public function SetMchId(){

		$this->values['mch_id'] = self::$config['mch_id'];

	}

	public function ToXml() {

		if(!is_array($this->values) || count($this->values) <= 0) {

    		die('数组数据异常！');

    	}	

  	$xml = "<xml>";

  	foreach ($this->values as $key=>$val) {

    	if (is_numeric($val)){

    		$xml.="<".$key.">".$val."</".$key.">";

    	}else{

    		$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";

    	}

    }

    $xml.="</xml>";

    return $xml; 

	}

	public function FromXml($xml) {

		if(!$xml){

			die('xml数据异常！');

		}

//		var_dump($xml);die();

    libxml_disable_entity_loader(true);

    $this->values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		

		return $this->values;

	}

	public function ToUrlParams() {

		$buff = "";

		foreach ($this->values as $k => $v) {

			if($k != "sign" && $v != "" && !is_array($v)){

				$buff .= $k . "=" . $v . "&";

			}

		}

		$buff = trim($buff, "&");

		return $buff;

	}

	public function MakeSign() {

		//签名步骤一：按字典序排序参数

		ksort($this->values);

		$string = $this->ToUrlParams();

		//签名步骤二：在string后加入KEY

		$string = $string . "&key=".self::$config['key'];

		//签名步骤三：MD5加密

		$string = md5($string);

		//签名步骤四：所有字符转为大写

		$result = strtoupper($string);

		return $result;

	}

	public function getNonceStr($length = 32) {

		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  

		$str ="";

		for ( $i = 0; $i < $length; $i++ )  {  

			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  

		} 

		return $str;

	}

	public function GetValues() {

		return $this->values;

	}

}



class WxPayResults extends WxPayDataBase{

	public function CheckSign(){

		if(!$this->issetData('sign')){

			die("签名错误！1");

		}

		$sign = $this->MakeSign();

		if($this->getData('sign') == $sign){

			return true;

		}

		die("签名错误！2");

	}

	public static function Init($xml) {	

		$obj = new self();

		$obj->FromXml($xml);

		if($obj->values['return_code'] != 'SUCCESS'){

			 return $obj->GetValues();

		}

		$obj->CheckSign();

        return $obj->GetValues();

	}

}



class wxJsPay extends WxPayDataBase{

	public function SetAppId(){

		$this->values['appId'] = self::$config['appid'];

	}

	public function SetNonce_str(){

		$nonce_str = $this->getNonceStr();

		$this->values['nonceStr'] = $nonce_str;

		return $nonce_str;

	}

	public function SetSign() {

		$sign = $this->MakeSign();

		$this->values['paySign'] = $sign;

		return $sign;

	}

}

?>