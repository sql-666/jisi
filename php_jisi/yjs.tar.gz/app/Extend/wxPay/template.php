<?php 

class template {
	
	public static function getToken(){
		return $setting->accessToken;
	}
	public static function send($post){
		$access_token = self::getToken();
		$url = 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token='.$access_token;
        $post = json_encode($post,JSON_UNESCAPED_UNICODE);
//        var_dump($url);
//        var_dump($post);die();
        $res = self::LCurl($url,$post);

        return $res;
	}
	protected static function refresh_token(){
        $arrContextOptions=array(
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        );
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx414241fdbbadeecb&secret=e595574db6e5be1aa95ad1730ed136c2';
        $resoult = file_get_contents($url,false, stream_context_create($arrContextOptions));
//		$resault = file_get_contents($url);
        $res = json_decode($resoult,true);
//        $res = self::LCurl($url);
		if(!$res['access_token']) throw new Exception($res['errmsg'], 1);
		$expires_in = time()+$res['expires_in'];
		$setting->accessToken = $res['access_token'];
		$setting->expires_in = $expires_in;
		$setting->save();
		return $setting->accessToken;
	}
	protected static function LCurl($url,$post=null,$second=10){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if($post){
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		$data = curl_exec($ch);

		if($data){
			curl_close($ch);
			return json_decode($data,true);
		} else {
            $error = curl_errno($ch);
			curl_close($ch);
			throw new Exception("curl出错，错误码:$error");
		}
	}
}


?>