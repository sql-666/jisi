<?php
class article2Model extends RelationModel
{
    //自动完成
    protected $_auto = array(
        array('addtime', 'time', 1, 'function'),
    );
    //自动验证
    protected $_validate = array(
        array('title', 'require', '{%article_title_empty}'),
    );
	
    public function addtime()
    {
        return date("Y-m-d H:i:s",time());
    }
}