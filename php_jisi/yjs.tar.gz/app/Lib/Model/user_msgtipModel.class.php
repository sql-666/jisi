<?php

/**
 * 用户通知 
 */
class user_msgtipModel extends Model {

    private $_type = array(
        '1' => 'fans',
        '2' => 'atme',
        '3' => 'msg',
        '4' => 'system',
    );

    public function add_tip($uid, $type,$articleid=0,$num=1) {
        //$is_tip = $this->where(array('uid' => $uid, 'type' => $type,'fromid' => $fromid, 'articleid' =>$articleid))->count();
       // if ($is_tip) {
//            return $this->where(array('uid' => $uid, 'type' => $type,'fromid' => $fromid, 'articleid' =>$articleid))->setInc('num', $num);
//        } else {
            return $this->add(array(
                        'uid' => $uid,
                        'type' => $type,
                        'num' => $num,
						'articleid' => $articleid
                    ));
       // }
    }

    public function get_list($uid) {
        $tiplist = $this->field('type,num')->where(array('uid' => $uid))->select();
        $result = array();
        foreach ($tiplist as $val) {
            $result[$this->_type[$val['type']]] = $val['num'];
        }
        return $result;
    }

    public function clear_tip($uid, $type = '') {
        $map = array('uid' => $uid);
        $type && $map['type'] = $type;
        //return $this->where($map)->save(array('num'=>0));
		$this->where($map)->delete();
    }
	
	 public function read_tip($uid, $type = '', $articleid = '') {
        $map = array('uid' => $uid);
        $type && $map['type'] = $type;
		$articleid && $map['articleid'] = $articleid;
		$this->where($map)->setField("status",1);
    }
}