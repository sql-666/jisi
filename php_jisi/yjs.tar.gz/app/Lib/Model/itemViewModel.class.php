<?php
/***********************************************************

*************************************************************/
class itemViewModel extends ViewModel 
{
	protected $viewFields = array( 

		'item' => array("id,title,intro,hits,uid,qdinfo,uname,add_time,end_time,img,itemtype,sharetype",'_type'=>'LEFT'), 

		'item_add' => array('char4', '_on' => 'item.id=item_add.item_id'), 
	); 
}
?>