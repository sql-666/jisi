<?php
return array(
  'name' => '图片广告',
  'option' => true,
  //'allow_type' => array('text','image','code','flash'),
  'allow_type' => array('image'),
);