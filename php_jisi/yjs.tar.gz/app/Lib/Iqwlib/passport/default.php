<?php

/**

 * 内置用户中心连接接口

 * author: andery@foxmail.com

 */

class default_passport

{



    private $_error = 0;



    public function __construct() {

        $this->_user_mod = D('user');

    }



    public function get_info() {

        return array(

            'code' => 'default', //插件代码必须和文件名保持一致

            'name' => 'IQWPHP', //整合插件名称

            'desc' => '默认会员系统',

            'version' => '1.0', //整合插件的版本

            'author' => 'IQWPHP TEAM', //开发者

        );

    }



    /**

     * 注册新用户

     */

    public function register($phone, $password) {

        if (!$this->check_username($phone)) {

            $this->_error = L('mobile_register');

            return false;

        }

//        if (!$this->check_email($email)) {

//            $this->_error = L('email_exists');

//            return false;

//        }

        return array(

            'phone' => $phone,

            'password' => $password

        );

    }



    /**

     * 修改用户资料

     */

    public function edit($uid, $old_pwd, $password, $force = false) {

        if (!$force) {

            //先验证

            $info = $this->get($uid);
			
            if ($info['password'] != md5($old_pwd)) {
				
                $this->_error = L('auth_failed');

                return false;

            }

        }

        if (isset($password)) {

            $data['password'] = md5($password);

        }

        return $data;

    }



    /**

     * 删除用户

     */

    public function delete() {

        return true;

    }



    public function get($flag, $is_name = false) {

        if ($is_name) {

            $map = array('username' => $flag);

        } else {

            $map = array('id' => intval($flag));

        }

        return M('user')->where($map)->find();

    }



    /**

     * 登陆验证

     */

    public function auth($phone, $password) {

		

        $uid = M('user')->where(array('phone'=>$phone, 'password'=>md5($password)))->getField('id');

        if ($uid) {

            return $uid;

        } else {

            $this->_error = L('auth_failed');

            return false;

        }

    }



    /**

     * 同步登陆

     */

    public function synlogin() {}



    /**

     * 同步退出

     */

    public function synlogout() {}



    /**

     * 检测用户邮箱唯一

     */

    public function check_email() {

        if ($this->_user_mod->where(array('email'=>$email))->count('id')) {

            return false;

        }

        return true;

    }



    /**

     * 检测用户名唯一

     */

    public function check_username() {

        if ($this->_user_mod->where(array('phone'=>$phone))->count('id')) {

            return false;

        }

        return true;

    }



    public function get_error() {

        return $this->_error;

    }

}