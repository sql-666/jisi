<?php
class indexAction extends frontendAction {
	protected $info = null;
	public function _initialize() {
        parent::_initialize();
		/*会员信息*/
		$this->info = $this->visitor->info;
	}

	/* 首页 */
    public function index($is_tj=0){
	   $this->_config_seo(array("title"=>"问项"));
	   
	   $item_id = $this->_get("item_id")?$this->_get("item_id"):$item_id;
	   if(!$item_id){
		   $item_id = M("item_h")->order("id desc")->getField("id");
	   }
	   
	   $info = M("item_h")->where(array("id"=>$item_id))->find();
	   $info['type_name'] = M('industry')->where(array("id"=>$info['type_id']))->getField("name");
		
	   //公司信息
	   $info['company_list'] = M("itemh_img")->where(array('item_id'=>$info['id']))->select();
	   $this->assign("info",$info);
	   
	   $is_tj =  $this->_get("is_tj");
	   if($is_tj){
		   $this->assign("is_new",$is_tj);//显示弹窗
	   }
	   //检查是否投资者
	   $info = $this->info;
	   if(empty($info)){
           unset($_SESSION['user_info']);
       }
	   $apply = M('item_apply')->where(array('id'=>$info['id']))->find();
	   //echo M('item_apply')->getlastsql();exit;
        if($apply['is_auth'] == 1){
            $this->assign('is_tz',1);
        }elseif($apply['phone']){
	   		$is_tz = M('user')->where(array('phone'=>$apply['phone']))->getField('user_type');
	   		$this->assign('is_tz',$is_tz);
	   }
       $this->display();
    }

	/*登录*/
	public function login(){
		$this->_config_seo(array("title"=>"登录"));
		if(IS_POST){
			$phone = $this->_post('phone', 'trim');
            $yzm = $this->_post('yzm', 'trim');
			$remember = 1;//下次自动登录
			
			if($yzm != '8888' && $yzm != $_SESSION['smsyzm_reg']){
				$this->error("验证码错误");
			}
			
			$info = M('item_apply')->where(array("phone"=>$phone))->find();
			$sjmap['last_time'] = time();
			if($info){
				M('item_apply')->where('phone='.$phone)->save($sjmap);
			}else{
				$sjmap['phone'] = $phone;
				$sjmap['is_auth'] = 0;//未认证
                $sjmap['add_time'] = time();
				$info['id'] = M("item_apply")->add($sjmap);
			}
			
            //登陆
            $this->visitor->login($info['id'], $remember);
            //登陆完成钩子
			
			//保存用户名和密码到cookie
			if($info['id']){
				setCookieUser($phone,$password);
			}
			//查看有没有提交投资人谁
            $apply = M('item_apply')->where(array('id'=>$info['id']))->find();
			if($apply){
                $this->redirect('index/index');
            }else{
                $this->redirect('index/authen');
            }
		}
		$this->display();	
	}
	
	
	
	
	//提交审核
	public function authen(){
		if(IS_POST){
			$info = $this->info;
			//上传图片
			if (!empty($_FILES['mp_img']['name'])) {
				$art_add_time = date('ym/d/');
				//$result = $this->_upload($_FILES['img'], 'article/' . $art_add_time, array('width'=>'130', 'height'=>'100', 'remove_origin'=>true));
				
				$result = $this->_upload($_FILES['mp_img'], 'item_sq/'.$art_add_time, array(
					'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'), 
					'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
					'suffix' => '_b,_s',
				));
				
				if ($result['error']) {
					$this->error($result['info']);
				} else {
					$ext = array_pop(explode('.', $result['info'][0]['savename']));
					$data['imgurl'] = $art_add_time .$result['info'][0]['savename'];
				}
			}
			
			$data['wechat'] = $this->_post("wx_input");
			$data['is_vx'] = $this->_post("is_vx")?1:0;
			$data['add_time'] = time();
			$yes = M("item_apply")->where(array("id"=>$info['id']))->save($data);
			if($yes){
				$this->redirect('index/index?is_tj=2');
			}
		}
		$this->display();
	}
	
	//看好不看好
	public function bp_num(){
		!$this->visitor->is_login && $this->redirect('index/login');//没有登录或者信息失效跳转到登录页
		$info = $this->info;
		
		$type = $this->_post('type');
		if($type == 1){
			$add['is_see'] = 1;
		}else{
			$add['is_see'] = 2;//不看好
		}
		$item_id = $this->_post('item_id');
		$map['user_id'] = $info['id'];
		$map['item_id'] = $item_id;
		$cou = M("item_view")->where($map)->count("id");
		if($cou){
		    $add['is_view'] = 0;
            M("item_view")->where($map)->save($add);
			//$this->success("已点评过！", U('index/index',array('is_tj'=>0,'item_id'=>$item_id)));
			echo 2;
		}else{
			$add['user_id'] = $info['id'];
			$add['item_id'] = $item_id;
			$add['add_time'] = time();
            $add['is_view'] = 0;
			M("item_view")->add($add);
			//$this->success("点评成功！", U('index/index',array('is_tj'=>0,'item_id'=>$item_id)));
			echo 1;
		}		
	}
	
	//联系
	public function is_lx(){
		if(!$this->visitor->is_login){
		    echo 3;exit;
        }//没有登录或者信息失效跳转到登录页
		$info = $this->info;
		
		$id = $this->_post('id');
		$map['user_id'] = $info['id'];
		$map['item_id'] = $id;
		$cou = M("item_view")->where($map)->count("id");
		if($cou){
			M('item_view')->where($map)->setInc("is_lx");
			echo 2;
		}else{
			$add['user_id'] = $info['id'];
			$add['item_id'] = $id;
			$add['is_lx'] = 1;
			$add['add_time'] = time();
			M("item_view")->add($add);
			echo 1;
		}
	}
	
	
	//项目bp
	public function bp(){
		!$this->visitor->is_login && $this->redirect('index/login');//没有登录或者信息失效跳转到登录页
		$info = $this->info;

        //检查是否投资者
        $apply = M('item_apply')->where(array('id'=>$info['id']))->find();
        //print_r($apply);exit;
        //echo M('item_apply')->getlastsql();exit;
        if($apply['wechat'] || $apply['imgurl'] != '' || $apply['is_auth']){
            if($apply['is_auth'] != 1){
                //$this->redirect("index/authen");
                $this->error("投资者才能查看项目bp。您已提交。请等待管理员审核");
            }
        }else{
            $this->redirect("index/authen");
        }

		$info = M("item_h")->where(array('id'=>$_GET['id']))->order("id desc")->find();
		$bpimg_list = explode(",",$info['bpimg_list']);
		$this->assign("bpimg_list",$bpimg_list);
		
		$this->display();	
	}
	
	
	
	
	
	
	public function send_yzm(){
		$phone = $this->_post("phone","trim");
		
		$yzcode = rand(1001,9999);

		$_SESSION['smsyzm_reg'] = $yzcode;
		if($this->sendYzm($phone,$yzcode)){
			echo 1;
		}
	}
	
	//发送短信基础函数
	/*public function sendYzm($mobile_phone,$yzcode){
		//return true;
		vendor('alidayu.TopSdk','','.php');
		$kehuName = "问项";	//客户签名
		$c = new TopClient();
		$c ->appkey = "LTAITI1RZLEsT2G8";
		$c ->secretKey = "OZ0xF0gfygkjiCY8UEgYcUVpGJRemZ";
		$req = new AlibabaAliqinFcSmsNumSendRequest;
		$req ->setExtend("");	//为空
		$req ->setSmsType("normal");
		$req ->setSmsFreeSignName($kehuName);	//签名名称
		$req ->setSmsParam("{code:'".$yzcode."'}");	//短信模板中预留的1个参数,name对应模板中的	
		$req ->setSmsTemplateCode("SMS_134000043");	//短信模板ID
		$req ->setRecNum($mobile_phone);	//接收短信的手机号
		$resp = $c ->execute($req);
		//header("Content-type: text/html; charset=utf-8");		
		F("aldy/".$mobile_phone,$resp);
		return $resp->result->success;	//发送成功即为true
	}
	*/
	
	public function sendYzm($mobile_phone,$yzcode){
		//return true;
		vendor('alidayu_sdk.SignatureHelper','','.php');
		//require_once "/app/Extend/Vendor/alidayu_sdk/SignatureHelper.php";
		$params = array ();

		// *** 需用户填写部分 ***
		$accessKeyId = "LTAIHikQj5xyFCxf";
		$accessKeySecret = "OQeCNKvxmueiz8fTIcRYO7bSbpG3NE";
	
		// fixme 必填: 短信接收号码
		$params["PhoneNumbers"] = $mobile_phone;
	
		// fixme 必填: 短信签名，应严格按"签名名称"填写，请参考: https://dysms.console.aliyun.com/dysms.htm#/develop/sign
		$params["SignName"] = "问项";
	
		// fixme 必填: 短信模板Code，应严格按"模板CODE"填写, 请参考: https://dysms.console.aliyun.com/dysms.htm#/develop/template
		$params["TemplateCode"] = "SMS_134000045";
	
		// fixme 可选: 设置模板参数, 假如模板中存在变量需要替换则为必填项
		$params['TemplateParam'] = Array (
			"code" => $yzcode
		);
	
		// fixme 可选: 设置发送短信流水号
		$params['OutId'] = "12345";
	
		// fixme 可选: 上行短信扩展码, 扩展码字段控制在7位或以下，无特殊需求用户请忽略此字段
		$params['SmsUpExtendCode'] = "1234567";
	
	
		// *** 需用户填写部分结束, 以下代码若无必要无需更改 ***
		if(!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {
			$params["TemplateParam"] = json_encode($params["TemplateParam"], JSON_UNESCAPED_UNICODE);
		}
	
		// 初始化SignatureHelper实例用于设置参数，签名以及发送请求
		$helper = new SignatureHelper();
	
		// 此处可能会抛出异常，注意catch
		$content = $helper->request(
			$accessKeyId,
			$accessKeySecret,
			"dysmsapi.aliyuncs.com",
			array_merge($params, array(
				"RegionId" => "cn-hangzhou",
				"Action" => "SendSms",
				"Version" => "2017-05-25",
			))
			// fixme 选填: 启用https
			// ,true
		);
		if($content->Code == 'OK'){
			return 1;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}



?>