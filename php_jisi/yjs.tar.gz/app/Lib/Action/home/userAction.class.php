<?php
class userAction extends frontendAction {
	protected $info = null;
	public function _initialize() {
        parent::_initialize();
		/*会员信息*/
		$this->info = $this->visitor->info;
	}
	
	/*登录*/
	public function login(){
		$this->_config_seo(array("title"=>"登录"));
		if(IS_POST){
			$phone = $this->_post('tel', 'trim');
            $yzm = $this->_post('yzm', 'trim');
			$remember = 1;//下次自动登录
			
			if($yzm != '8888'){
				$this->error("验证码错误");
			}
			
			$cou = M('item_apply')->where('phone='.$phone)->count("id");
			if($cou == ''){
				$this->error("手机号不存在");
			}
			
			$sjmap['last_time']=time();
			M('item_apply')->where('phone='.$phone)->save($sjmap);
            
            //登陆
            $this->visitor->login($uid, $remember);
            //登陆完成钩子
			
            //同步登陆
            $synlogin = $passport->synlogin($uid);
			//保存用户名和密码到cookie
			if($uid){
				setCookieUser($phone,$password);
			}
            if (IS_AJAX) {
                $this->ajaxReturn(1, L('login_successe').$synlogin,$uid );
            } else {
                //跳转到登陆前页面（执行同步操作）
               $this->redirect('user/user');
            }
		}
		$this->display();	
	}
	
	
}
?>