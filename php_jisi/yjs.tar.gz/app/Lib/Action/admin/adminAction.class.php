<?php
class adminAction extends backendAction
{
    public function _initialize() {
        parent::_initialize();
        $this->_mod = D('admin');
    }

    public function _before_index() {
        $big_menu = array(
            'title' => '添加员工',
            'iframe' => U('admin/add'),
            'id' => 'add',
            'width' => '500',
            'height' => '210'
        );
        $this->assign('big_menu', $big_menu);
        $this->list_relation = true;
    }

    public function _before_add() {
        $role_list = M('admin_role')->where('status=1 and id != 1 ')->select(); //不显示爱企网管理组		
        $this->assign('role_list', $role_list);
    }

    public function _before_insert($data='') {
        if( ($data['password']=='')||(trim($data['password']=='')) ){
            unset($data['password']);
        }else{
            $data['password'] = md5($data['password']);
        }
        return $data;
    }

    public function _before_edit() {
        $this->_before_add();
    }

    public function _before_update($data=''){
        if( ($data['password']=='')||(trim($data['password']=='')) ){
            unset($data['password']);
        }else{
            $data['password'] = md5($data['password']);
        }
        return $data;
    }
	public function editinfo($data=''){
		$mod = D('Admin_info');
        if (IS_POST) {
			$id = $this->_post("id", 'intval');
			if (false === $data = $mod->create()) {
				IS_AJAX && $this->ajaxReturn(0, $mod->getError());
				$this->error($mod->getError());
			}
			if(empty($id)){
				$data['add_time'] = mktime();
				$data = $this->_info_insert($data);
				$return = $mod->add($data);
			}else{
				$data = $this->_info_update($data);
				$return = $mod->save($data);
			}
			//echo $mod->getLastSql();exit;
			if ($return!==false) {
            	$this->success(L('operation_success'));
			} else {
				 $this->error(L('operation_failure'));
			}
 
        } else {
			//编辑信息
            $uid = $this->_get("uid", 'intval');
            $info =$mod->where("uid=$uid")->find();
			if(empty($info))$info['uid'] = $uid;
            $this->assign('info', $info);
			//获取当前登录名
			$info2 =  $this->_mod->field("username")->find($uid);
            $this->assign('info2', $info2);
			//调用所有品牌
			$model =  D('item_cate');
			$brand = $model->field('id,name')->where("pid = 0")->select();
			$this->assign('brand', $brand);
            $this->display();
        }
 
    }
    
    protected function _info_insert($data) {
    
    	//上传图片
    	if (!empty($_FILES['img']['name'])) {
    		$art_add_time = date('ym/d/');
    		//$result = $this->_upload($_FILES['img'], 'article/' . $art_add_time, array('width'=>'130', 'height'=>'100', 'remove_origin'=>true));
    			
    		$result = $this->_upload($_FILES['img'], 'article/'.$art_add_time, array(
    				'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'),
    				'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
    				'suffix' => '_b,_s',
    				//'remove_origin'=>true
    		));
    			
    		if ($result['error']) {
    			$this->error($result['info']);
    		} else {
    			$ext = array_pop(explode('.', $result['info'][0]['savename']));
    			//$data['img'] = $art_add_time .'/'. str_replace('.' . $ext, '_thumb.' . $ext, $result['info'][0]['savename']);
    			$data['img'] = $art_add_time .$result['info'][0]['savename'];
    		}
    	}
    	return $data;
    }
    
    protected function _info_update($data) {
		$mod = D('Admin_info');
    	if (!empty($_FILES['img']['name'])) {
    		$art_add_time = date('ym/d/');

    		//上传新图
    		// $result = $this->_upload($_FILES['img'], 'article/' . $art_add_time, array('width'=>'130', 'height'=>'100', 'remove_origin'=>true));
    			
    		$result = $this->_upload($_FILES['img'], 'article/'.$art_add_time, array(
    				'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'),
    				'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
    				'suffix' => '_b,_s',
    				//'remove_origin'=>true
    		));
    			
    		if ($result['error']) {
    			$this->error($result['info']);
    		} else {
    			$ext = array_pop(explode('.', $result['info'][0]['savename']));
    			// $data['img'] = $art_add_time .'/'. str_replace('.' . $ext, '_thumb.' . $ext, $result['info'][0]['savename']);
    			$data['img'] = $art_add_time .$result['info'][0]['savename'];
    
    		}
    	} else {
    		unset($data['img']);
    	}
    
    	return $data;
    }
    
    public function ajax_check_name() {
        $name = $this->_get('username', 'trim');
        $id = $this->_get('id', 'intval');
        if ($this->_mod->name_exists($name, $id)) {
            echo 0;
        } else {
            echo 1;
        }
    }
}