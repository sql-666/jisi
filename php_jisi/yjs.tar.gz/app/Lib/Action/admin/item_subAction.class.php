<?php
class item_subAction extends backendAction {
   public function _initialize() {
        parent::_initialize();
        $this->_mod = D('item_sub');
    }

    protected function _search() {
        $map = array();//搜索条件
        if( $keyword = $this->_request('keyword', 'trim') ){
            //$map['_string'] = "title like '%".$keyword."%'";
            $hmap['title'] =  array("like","%".$keyword."%");
			$uarr = M("item")->where($hmap)->getField('id',true);
            if($uarr){
                $map['item_id'] = array("in",$uarr);
            }else{
                $map['item_id'] = 0;
            }

//			$umap['the_user|phone'] =  array("like","%".$keyword."%");
//			$uarr = M("user")->where($umap)->getField('id',true);
//            if($uarr){
//                $map['user_id'] = array("in",$uarr);
//            }else{
//                $map['user_id'] = 0;
//            }
        }
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));                                                                                                                                                                             
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
		
        $this->assign('search', array(//表单回选值
		    'time_start' => $time_start,
            'time_end' => $time_end,
            'keyword' => $keyword,
        ));
		$map['is_show'] = 1;
        return $map;
    }

    public function index(){
		$map = $this->_search();
		$count = $this->_mod->where($map)->count('id');
        $pager = new Page($count, 20);
        $select = $this->_mod->where($map)->order('id DESC');
        $select->limit($pager->firstRow.','.$pager->listRows);
        $page = $pager->show();
        $this->assign("page", $page);
        $list = $select->select();
		$user = M("user");
		$item = M("item");
        foreach ($list as $key=>$val) {
			if($val['user_id']){
				$list[$key]['t_username'] = $user->where("id = ".$val['user_id'])->getField("username");
				$cy_name = $item->where("id = ".$val['item_id'])->field("id,user_id,type_name,title")->find();
				if($cy_name['user_id']){
					$list[$key]['cyname'] = $user->where("id = ".$cy_name['user_id'])->getField("the_user");
				}
				$list[$key]['username'] = $user->where("id = ".$val['user_id'])->getField("username");
				$list[$key]['the_user'] = $user->where("id = ".$val['user_id'])->getField("the_user");
			}
			$list[$key]['title'] = $cy_name['title'];
			$list[$key]['type_name'] = $cy_name['type_name'];
        }
		
        $this->assign('list', $list);
		$this->display();	
    }



	public function edit(){
		
	 	$id = $this->_get('id','intval');
		
		$item_sub = $this->_mod->where("id = ".$id)->find();
		$uinfo = M("user")->where("id = ".$item_sub['user_id'])->find();
		$item_sub['tx_img'] = $uinfo['avatarUrl'];//头像
		$item_sub['username'] = $uinfo['username'];//名称
		$item_sub['address'] = $uinfo['address'];//地址
		$item_sub['con_name'] = $uinfo['con_name'];//机构名称
		$this->assign("item_sub",$item_sub);
		
		$wtarr = explode(",",$item_sub['wt_str']);
		$other = M("other_set");
		$wt_list = $other->where("pid = 22")->field("id,name")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
			foreach($wt_list[$k]['ptype'] as $key=>$val){
				if(in_array($val['id'],$wtarr)){
					$wt_list[$k]['ptype'][$key]['is_status'] = 1;
				}
			}
		}
		$this->assign("wt_list",$wt_list);
		
		$item = M("item")->where("id = ".$item_sub['item_id'])->find();
		$item['username'] = M("user")->where("id = ".$item['user_id'])->getField("username");
		$this->assign('item', $item);
		
		//相册
		$img_list = explode(',',$item['tp_img']);
		$this->assign('img_list', $img_list);
		
		$this->display();
    }

    /**
     * 删除
     */
    public function item_delete()
    {
        $ids = trim($this->_request('id'), ',');
        if ($ids) {
            if (false !== $this->_mod->delete($ids)) {
                IS_AJAX && $this->ajaxReturn(1, L('operation_success'));
            } else {
                IS_AJAX && $this->ajaxReturn(0, L('operation_failure'));
            }
        } else {
            IS_AJAX && $this->ajaxReturn(0, L('illegal_parameters'));
        }
    }
   
}