<?php
class item_applyAction extends backendAction {
   public function _initialize() {
        parent::_initialize();
        $this->_mod = D('item_apply');
    }

    protected function _search() {
        $map = array();//搜索条件
        if( $keyword = $this->_request('keyword', 'trim') ){
            //$map['_string'] = "name like '%".$keyword."%' OR intro like '%".$keyword."%'";
			
			$umap['the_user|phone'] =  array("like","%".$keyword."%");
			$uarr = M("item_apply")->where($umap)->getField('id',true);
			if($uarr){
                $map['id'] = array("in",$uarr);
            }else{
                $map['id'] = 0;
            }
        }
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));                                  ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
		
        $this->assign('search', array(//表单回选值
		    'time_start' => $time_start,
            'time_end' => $time_end,
            'keyword' => $keyword,
        ));
		$map['is_show'] = 1;
        return $map;
    }

	
    public function _after_index($list){
		
		$model = M("user");		
		$industry = M("industry");
		foreach($list as $k=>$v){
		    if($v['sq_type'] == 2){
                $list[$k]['phone'] = $model->where(array("id"=>$v['user_id']))->getField("phone");
            }else{
		        $list[$k]['phone'] = $v['phone'];
            }

			$type = explode(",",$v['type_id']);
			$map['id'] = array("in",$type);
			$type_name = $industry->where($map)->getField("name",true);
			$list[$k]['type_name'] = implode(",",$type_name);
		}
		return $list;
    }
	
	
	public function _before_edit($info){
		
		$type_id = intval($_GET['type_id']);
		$this->assign("type_id",$type_id);
		
		$type = M("industry")->where("status = 1")->select();
		$this->assign("type",$type);
		
		$type_id = $info['type_id'];
		$info['type_arr'] = explode(",",$type_id);
		return $info;
    }



    public function _before_update($data) {
      
		$data['type_id'] = implode(",",$_POST['type_id']);
		
        return $data;
    }




	//查看项目查看人
	public function record() {

		$map = array();
        $map['id'] =  $this->_get("id","intval");	
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
        $model = M('item_view');
		 
        $list = $model->where($map)->order("id DESC")->select();
		
		$user = M("item_apply");
		foreach($list as $k=>$v){
			$uinfo = $user->where(array("id"=>$v['user_id']))->find();
			$list[$k]['username'] = $uinfo['the_user']."(".$uinfo['phone'].")";
		}
		
        $this->assign('list', $list);
		$this->assign("item_id",$map['id']);
		$this->display();
	}
	
	
	
	//异步审核通过添加问项会员
	public function _before_ajaxEdit($id){
		$info = M("item_apply")->where(array("id"=>$id))->find();

        $field = $this->_get('field', 'trim');
        $val = $this->_get('val', 'trim');
		if($val == 0 && $field == "is_auth" && $info){//取消审核。改变会员状态
		    if($info['user_id']){//小程序提交
                M("user")->where(array("id"=>$info['user_id']))->save(array("user_type"=>1));
            }elseif($info['phone'] && $info['sq_type'] == 1){//h5提交
                M("user")->where(array("phone"=>$info['phone']))->save(array("status"=>0));
            }
            return;
        }

        if($info['sq_type'] == 2){
            $add['id'] = $info['user_id'];
            //如果会员存在不做处理
            $uinfo = M("user")->where($add)->find();
        }else{
            $add['phone'] = $info['phone'];
            //如果会员存在不做处理
            $uinfo = M("user")->where($add)->find();
        }

        //必须是加入问题的才能添加到user表里的投资者
        if(!$uinfo && $info['is_vx'] == 1){
            $add['status'] = 1;
            $add['reg_time'] = time();
            $add['last_time'] = time();
            $add['phone'] = $info['phone'];
            $add['user_type'] = 2;
            $add['username'] = $info['username'];
            $add['the_user'] = $info['the_user'];
            $add['position'] = $info['position'];
            $add['wechat'] = $info['wechat'];
            $add['con_name'] = $info['con_name'];
            $add['note'] = $info['note'];
            $add['address'] = $info['address'];
            $add['type_id'] = $info['type_id'];
            M("user")->add($add);
        }elseif($uinfo){
            if($uinfo['user_type'] == 1){
                $save['user_type'] = 2;
                M("user")->where(array("id"=>$uinfo['id']))->save($save);
            }
        }
		
	}
	
	
	
	/**
	* excel导出
	*/
	public function getPrint(){
		
        $map['id'] =  $this->_get("item_id","intval");	
		$model = M('item_view');
        $list = $model->where($map)->order("id DESC")->select();
		
       	if(empty($list)){
			$this->error('无数据信息，无法导出数据！');
		}
		$user = M("item_apply");
		foreach($list as $k => $v){
			$goods_list[$k]['id'] = $v['id'];
			$goods_list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);
			$goods_list[$k]['type'] = $v['is_see']==1?'看好':'一般';
			$uinfo = $user->where(array("id"=>$v['user_id']))->find();
			$goods_list[$k]['username'] = $uinfo['the_user']."(".$uinfo['phone'].")";
		}
		$miaoshu_arr= array(
			array("id","id"),array("type","点评类型"),array("username" ,"名称"),array("add_time","时间"),
		);
		$this->goods_export($goods_list,$miaoshu_arr);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}