<?php
class indexAction extends backendAction {

    public function _initialize() {
        parent::_initialize();
        $this->_mod = D('menu');
    }

    public function index() {
        $top_menus = $this->_mod->admin_menu(0);
		
		$priv_mod = D('admin_auth');
		
		//解决显示没有权限的菜单BUG - 顶部菜单
		if($_SESSION['admin']['role_id'] != 1){

			$qxids = $this->getMyMenu();
			foreach($top_menus as  $k=>$v){
				if(!in_array($v["id"],$qxids)){
					unset($top_menus[$k]);
				}
			}
		
		}
        $this->assign('top_menus', $top_menus);
		
        $my_admin = array('username'=>$_SESSION['admin']['username'], 'rolename'=>$_SESSION['admin']['role_id'], 

'nickname'=>$_SESSION['admin']['nickname']);
        $this->assign('my_admin', $my_admin);
 
        $this->display();
}
	
	//经销商登录
	/*public function qylogin() {
        if (IS_POST) {
            $username = $this->_post('username', 'trim');
            $password = $this->_post('password', 'trim');
            $verify_code = $this->_post('verify_code', 'trim');
            if(session('verify') != md5($verify_code)){
                $this->error(L('verify_code_error'));
            }
            $user = M('user')->where(array('username'=>$username ))->find();
            if (!$user) {
                $this->error("此企业会员用户不存在！");
            }
            if ($user['password'] != md5($password)) {
                $this->error("登录密码输入错误！");
            }
			if ($user['status'] != 1) {
                $this->error("此企业会员被禁用，联系管理员解锁！");
            }
			$cookie['role_id'] = 3;
            session('admin', array(
                'id' => $user['id'],
                'role_id' => 3,	//经销商角色ID定死为3
                'username' => $user['username'],
				'nickname' => $user['nickname'],
            ));
            M('user')->where(array('id'=>$user['id']))->save(array('last_time'=>time(), 'last_ip'=>get_client_ip()));
            $this->success(L('login_success'), U('index/index'));
        } else {
            $this->display("qylogin");
        }
    }*/
 

    public function panel() {
        $message = array();
        if (is_dir('./install')) {
            $message[] = array(
                'type' => 'error',
                'content' => "您还没有删除 install 文件夹，出于安全的考虑，我们建议您删除 install 文件夹。",
            );
        }
        if (APP_DEBUG == true) {
            $message[] = array(
                'type' => 'error',
                'content' => "您网站的 DEBUG 没有关闭，出于安全考虑，我们建议您关闭程序 DEBUG。",
            );
        }
        if (!function_exists("curl_getinfo")) {
            $message[] = array(
                'type' => 'error',
                'content' => "系统不支持 CURL ,将无法支持高级功能。",
            );
        }
        $this->assign('message', $message);
        $system_info = array(
            'iqwphp_version' => IQW_DATA_PATHVERSION . ' RELEASE '. IQW_DATA_PATHRELEASE .' [<a href="http://www.iqwweb.com/" class="blue" target="_blank">查看最新版本</a>]',
            'server_domain' => $_SERVER['SERVER_NAME'] . ' [ ' . gethostbyname($_SERVER['SERVER_NAME']) . ' ]',
            'server_os' => PHP_OS,
            'web_server' => $_SERVER["SERVER_SOFTWARE"],
            'php_version' => PHP_VERSION,
            'mysql_version' => mysql_get_server_info(),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'max_execution_time' => ini_get('max_execution_time') . '秒',
            'safe_mode' => (boolean) ini_get('safe_mode') ?  L('yes') : L('no'),
            'zlib' => function_exists('gzclose') ?  L('yes') : L('no'),
            'curl' => function_exists("curl_getinfo") ? L('yes') : L('no'),
            'timezone' => function_exists("date_default_timezone_get") ? date_default_timezone_get() : L('no')
        );
        $this->assign('system_info', $system_info);
		
        $this->display();
    }

    public function login() {
        if (IS_POST) {
            $username = $this->_post('username', 'trim');
            $password = $this->_post('password', 'trim');
            $verify_code = $this->_post('verify_code', 'trim');
			if(empty($username) || empty($password)){
				$this->error('登录用户名或密码不能为空！');
			}
            if(session('verify') != md5($verify_code)){
                $this->error(L('verify_code_error'));
            }
			$map['username|user_id'] = $username;
			$map['status'] = 1;
            $admin = M('admin')->where($map)->find();
            if (!$admin) {
                $this->error(L('admin_not_exist'));
            }
            if ($admin['password'] != md5($password)) {
                $this->error(L('password_error'));
            }
            session('admin', array(
                'id' => $admin['id'],
                'role_id' => $admin['role_id'],
                'username' => $admin['username'],
            ));
            M('admin')->where(array('id'=>$admin['id']))->save(array('last_time'=>time(), 'last_ip'=>get_client_ip()));
            $this->success(L('login_success'), U('index/index'));
        } else {
            $this->display();
        }
    }

    public function logout() {
        $admin =  session('admin');
		/*if($admin['role_id'] == 3){
			$ret = U('index/qylogin');
		}else{
			$ret = U('index/login');
		}*/
		$ret = U('index/login');
        session('admin', null);
        $this->success(L('logout_success'),$ret);
        exit;
    }

    public function verify_code() {
        Image::buildImageVerify(4,1,'gif','50','24');
    }
	
	//获取当前角色已授权数组带缓存功能
	private function getMyMenu(){
		$role_id = $_SESSION['admin']['role_id'];
		$qxids = F("qxids_".$role_id);
		if(empty($qxids)){
			$qxids = D('admin_auth')->where(array('role_id'=>$role_id))->getField("menu_id",true);
			F("qxids_".$role_id,$qxids);	//缓存一下
		}
		return $qxids;
	}

    public function left() {
		//解决显示没有权限的菜单BUG - 左侧菜单
		$role_id = $_SESSION['admin']['role_id'];	//3为经销商
        $menuid = $this->_request('menuid', 'intval');
        if ($menuid) {
			//点击了顶部菜单页
            $left_menu = $this->_mod->admin_menu($menuid);
			
			if($role_id != 1){   //超级管理员不受限制         
				$qxids = $this->getMyMenu(); 
				//过滤掉无权限菜单				
				foreach($left_menu as $k=>$v){
					if(!in_array($v["id"],$qxids)){
						unset($left_menu[$k]);
					}
				}
			}
 
            foreach ($left_menu as $key=>$val) {
                $temp = $this->_mod->admin_menu($val['id']);
				
				if($role_id != 1){   //超级管理员不受限制         
					//过滤掉无权限菜单				
					foreach($temp as $k=>$v){
						if(!in_array($v["id"],$qxids)){
							unset($temp[$k]);
						}
					}					 
				}				
				$left_menu[$key]['sub'] = $temp;
				
            }
        } else {
			//初始首页
            $left_menu[0] = array('id'=>0,'name'=>L('common_menu'));
            $left_menu[0]['sub'] = array();
            if ($r = $this->_mod->where(array('often'=>1))->select()) {
				if($role_id != 1){   //超级管理员不受限制         
					$qxids = $this->getMyMenu(); 
					//过滤掉无权限菜单				
					foreach($r as $k => $v){
						if(!in_array($v["id"],$qxids)){
							unset($r[$k]);
						}
					}
				}
				$left_menu[0]['sub'] = $r;
            }
            array_unshift($left_menu[0]['sub'], array('id'=>0,'name'=>L('common_menu_set'),'module_name'=>'index','action_name'=>'often_menu'));
        }
		//p($left_menu);
        $this->assign('left_menu', $left_menu);
        $this->display();
}

    public function often() {
        if (isset($_POST['do'])) {
            $id_arr = isset($_POST['id']) && is_array($_POST['id']) ? $_POST['id'] : '';
            $this->_mod->where(array('ofen'=>1))->save(array('often'=>0));
            $id_str = implode(',', $id_arr);
            $this->_mod->where('id IN('.$id_str.')')->save(array('often'=>1));
            $this->success(L('operation_success'));
        } else {
            $r = $this->_mod->admin_menu(0);
            $list = array();
            foreach ($r as $v) {
                $v['sub'] = $this->_mod->admin_menu($v['id']);
                foreach ($v['sub'] as $key=>$sv) {
                    $v['sub'][$key]['sub'] = $this->_mod->admin_menu($sv['id']);
                }
                $list[] = $v;
            }
            $this->assign('list', $list);
            $this->display();
        }
    }
	
	public function often_menu() {
			  if (isset($_POST['do'])) {
            $id_arr = isset($_POST['id']) && is_array($_POST['id']) ? $_POST['id'] : '';
            $this->_mod->where(array('ofen'=>1))->save(array('often'=>0));
            $id_str = implode(',', $id_arr);
            $this->_mod->where('id IN('.$id_str.')')->save(array('often'=>1));
            $this->success(L('operation_success'));
        } else {
            $r = $this->_mod->admin_menu(0);
            $list = array();
            foreach ($r as $v) {
                $v['sub'] = $this->_mod->admin_menu($v['id']);
                foreach ($v['sub'] as $key=>$sv) {
                    $v['sub'][$key]['sub'] = $this->_mod->admin_menu($sv['id']);
                }
                $list[] = $v;
            }
            $this->assign('list', $list);
            $this->display("often");
        }
		
	}
	
	public function mainshow() {
 
        $this->display();
    }

    public function map() {
        $r = $this->_mod->admin_menu(0);
        $list = array();
        foreach ($r as $v) {
            $v['sub'] = $this->_mod->admin_menu($v['id']);
            foreach ($v['sub'] as $key=>$sv) {
                $v['sub'][$key]['sub'] = $this->_mod->admin_menu($sv['id']);
            }
            $list[] = $v;
        }
        $this->assign('list', $list);
        $this->display();
    }
}