<?php
class item_hAction extends backendAction {
   public function _initialize() {
        parent::_initialize();
        $this->_mod = D('item_h');
    }
    protected function _search() {
        $map = array();//搜索条件
        if( $keyword = $this->_request('keyword', 'trim') ){
            $map['_string'] = "item_name like '%".$keyword."%' OR company_title like '%".$keyword."%'";
			//$umap['the_user|phone'] =  array("like","%".$keyword."%");
			//$uarr = M("user")->where($umap)->getField('id',true);
			//$map['user_id'] = array("in",$uarr);
        }
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));                                                                                                                                                                             
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
        $this->assign('search', array(//表单回选值
		    'time_start' => $time_start,
            'time_end' => $time_end,
            'keyword' => $keyword,
        ));
		$map['is_show'] = 1;
        return $map;
    }
    public function index(){
		$map = $this->_search();
		$count = $this->_mod->where($map)->count('id');
        $pager = new Page($count, 20);
        $select = $this->_mod->where($map)->order('id DESC');
        $select->limit($pager->firstRow.','.$pager->listRows);
        $page = $pager->show();
        $this->assign("page", $page);
        $list = $select->select();
		$industry = M("industry");
		$itemView = M("item_view");
		foreach($list as $k=>$v){
			$list[$k]['type_name'] = $industry->where(array("id"=>$v['type_id']))->getField("name");
			$list[$k]['url'] = $_SERVER['SERVER_NAME'].'/index.php/index-index?item_id='.$v['id'];
			$list[$k]['viewCou'] = $itemView->where(array("item_id"=>$v['id'],"is_view"=>0))->count("id");
		}
        $this->assign('list', $list);
		$this->display();	
    }
	public function _before_add(){
		$indu_list = M("industry")->where("status = 1")->field("id,name")->select();
		$this->assign("indu_list",$indu_list);
	}
 	protected function _before_insert($data) {

        //上传图片
        if (!empty($_FILES['imgurl']['name'])) {
            $art_add_time = date('ym/d/');
            //$result = $this->_upload($_FILES['img'], 'article/' . $art_add_time, array('width'=>'130', 'height'=>'100', 'remove_origin'=>true));

            $result = $this->_upload($_FILES['imgurl'], 'item_h/'.$art_add_time, array(
                'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'),
                'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
                'suffix' => '_b,_s',
                //'remove_origin'=>true
            ));

            if ($result['error']) {
                $this->error($result['info']);
            } else {
                $ext = array_pop(explode('.', $result['info'][0]['savename']));
                //$data['img'] = $art_add_time .'/'. str_replace('.' . $ext, '_thumb.' . $ext, $result['info'][0]['savename']);
                $data['imgurl'] = $art_add_time .$result['info'][0]['savename'];
            }
        }
		$data['add_time'] = time();
        return $data;
    }
	 protected function _after_insert($id) {
        //上传图片
		$date_dir = date('ym/d/'); //上传目录
		//上传相册
		$file_imgs = array();
		foreach($_FILES['imgs']['name'] as $key=>$val ){
			if($val){
				$file_imgs['name'][] = $val;
				$file_imgs['type'][] = $_FILES['imgs']['type'][$key];
				$file_imgs['tmp_name'][] = $_FILES['imgs']['tmp_name'][$key];
				$file_imgs['error'][] = $_FILES['imgs']['error'][$key];
				$file_imgs['size'][] = $_FILES['imgs']['size'][$key];
			}
		}
		if($file_imgs){
			$result = $this->_upload($file_imgs, 'item_h/'.$date_dir, array(
				'width'=>C('iqw_item_bimg.width').','.C('iqw_item_simg.width'),
				'height'=>C('iqw_item_bimg.height').','.C('iqw_item_simg.height'),
				'suffix' => '_b,_s',
			));
			if ($result['error']) {
				$this->error($result['info']);
			} else {
				foreach( $result['info'] as $key=>$val ){
					$item_imgs[] = array(
						'url'    => $date_dir . $val['savename'],
						'order'  => $key + 1,
					);
				}
			}
		}
		//名称
		$zy_name = $this->_post('zy_name');
		//职位
		$position = $this->_post('position');
		//职位描述
		$position_com = $this->_post('position_com');
		//团队处理
         if($zy_name){
             $shop_img_mod = D('itemh_img');
             foreach($zy_name as $k=>$v){
                 $imgAdd['zy_name'] = $v;
                 $imgAdd['position'] =  $position[$k];
                 $imgAdd['position_com'] =  $position_com[$k];
                 $imgAdd['item_id'] = $id;
                 $imgAdd['url'] = $file_imgs[$k] ? $file_imgs[$k] : '';
                 $shop_img_mod->add($imgAdd);
             }
         }
		
		//上传bp
		$bp_imgs = array();
		foreach($_FILES['bpimg']['name'] as $key=>$val ){
			if($val){
				$bp_imgs['name'][] = $val;
				$bp_imgs['type'][] = $_FILES['bpimg']['type'][$key];
				$bp_imgs['tmp_name'][] = $_FILES['bpimg']['tmp_name'][$key];
				$bp_imgs['error'][] = $_FILES['bpimg']['error'][$key];
				$bp_imgs['size'][] = $_FILES['bpimg']['size'][$key];
			}
		}
		if($bp_imgs){
			$result = $this->_upload($bp_imgs, 'item_h/'.$date_dir, array(
				'width'=>C('iqw_item_bimg.width').','.C('iqw_item_simg.width'),
				'height'=>C('iqw_item_bimg.height').','.C('iqw_item_simg.height'),
				'suffix' => '_b,_s',
			));
			if ($result['error']) {
				$this->error($result['info']);
			} else {
				foreach( $result['info'] as $key=>$val ){
					$implode_str .= $implode_str ? ",".$date_dir.$val['savename'] : $date_dir.$val['savename'];
				}
			}
			M('item_h')->where(array('id'=>$id))->save(array('bpimg_list'=>$implode_str));
		}
    }
	//项目编辑
	public function itemh_edit(){
		$id = $this->_get('id','intval');
		$info = $this->_mod->where(array('id'=>$id))->find();
		$this->assign('info', $info);
		$indu_list = M("industry")->where("status = 1")->field("id,name")->select();
		$this->assign("indu_list",$indu_list);
		//相册
		$img_list = M('itemh_img')->where(array('item_id'=>$id))->select();
		$this->assign('img_list', $img_list);
		
		
		//获取项目图片
		$bpimg = M("item_h")->where(array('id'=>$id))->getField('bpimg_list');
		$bpimg = explode(",",$bpimg);
		$this->assign('bpimg',$bpimg);
		
		$this->display("edit");
    }
	
	public function _before_update($data){
		if (!empty($_FILES['imgurl']['name'])) {
            $art_add_time = date('ym/d/');
			$result = $this->_upload($_FILES['imgurl'], 'item_h/'.$art_add_time, array(
                'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'), 
                'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
                'suffix' => '_b,_s',
            ));
			
            if ($result['error']) {
                $this->error($result['info']);
            } else {
               $ext = array_pop(explode('.', $result['info'][0]['savename']));
			   $data['imgurl'] = $art_add_time .$result['info'][0]['savename'];
            }
        }
		
		if (!empty($_FILES['bp_img']['name'])) {
            $art_add_time = date('ym/d/');
			$result = $this->_upload($_FILES['bp_img'], 'item_h/'.$art_add_time, array(
                'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'), 
                'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
                'suffix' => '_b,_s',
            ));
			
            if ($result['error']) {
                $this->error($result['info']);
            } else {
               $ext = array_pop(explode('.', $result['info'][0]['savename']));
			   $data['bp_img'] = $art_add_time .$result['info'][0]['savename'];
			   
            }
        }
		return $data;	
	}
	
	//编辑
	protected function _after_update($id) {
        //上传图片
		$date_dir = date('ym/d/'); //上传目录
		//上传相册
		$file_imgs = array();
		foreach($_FILES['imgs']['name'] as $key=>$val ){
			if($val){
				$file_imgs['name'][] = $val;
				$file_imgs['type'][] = $_FILES['imgs']['type'][$key];
				$file_imgs['tmp_name'][] = $_FILES['imgs']['tmp_name'][$key];
				$file_imgs['error'][] = $_FILES['imgs']['error'][$key];
				$file_imgs['size'][] = $_FILES['imgs']['size'][$key];
			}
		}
		if($file_imgs){
			$result = $this->_upload($file_imgs, 'item_h/'.$date_dir, array(
				'width'=>C('iqw_item_bimg.width').','.C('iqw_item_simg.width'),
				'height'=>C('iqw_item_bimg.height').','.C('iqw_item_simg.height'),
				'suffix' => '_b,_s',
			));
			if ($result['error']) {
				$this->error($result['info']);
			} else {
				foreach( $result['info'] as $key=>$val ){
					$item_imgs[] = array(
						'url'    => $date_dir . $val['savename'],
						'order'  => $key + 1,
					);
				}
			}
		}

		//id
		$id_arr = $this->_post('img_id');
        //图片
        $yimgArr = $this->_post('yimgs');
		//名称
		$yzy_name = $this->_post('yzy_name');
		//职位
		$yposition = $this->_post('yposition');
		//职位描述
		$yposition_com = $this->_post('yposition_com');

		if($id_arr){
		    M("itemh_img")->where(array("item_id"=>$id))->delete();
            $shop_img_mod = D('itemh_img');
            foreach($id_arr as $k=>$v){
                $_imgAdd['item_id'] = $id;
                $_imgAdd['zy_name'] = $yzy_name[$k];
                $_imgAdd['position'] =  $yposition[$k];
                $_imgAdd['position_com'] =  $yposition_com[$k];
                $_imgAdd['url'] = $yimgArr[$k];
                $shop_img_mod->add($_imgAdd);
            }
        }else{
            M("itemh_img")->where(array("item_id"=>$id))->delete();
        }


		//团队处理
        //名称
        $zy_name = $this->_post('zy_name');
        //职位
        $position = $this->_post('position');
        //职位描述
        $position_com = $this->_post('position_com');
        if($zy_name){
            $shop_img_mod = D('itemh_img');
            foreach($zy_name as $k=>$v){
                $imgAdd['zy_name'] = $v;
                $imgAdd['position'] =  $position[$k];
                $imgAdd['position_com'] =  $position_com[$k];
                $imgAdd['item_id'] = $id;
                $imgAdd['url'] = $item_imgs[$k] ? $item_imgs[$k] : '';
                $shop_img_mod->add($imgAdd);
            }
        }

		//bp图片编辑
		$bp_imgs = array();
		foreach($_FILES['bpimg']['name'] as $key=>$val ){
			if($val){
				$bp_imgs['name'][] = $val;
				$bp_imgs['type'][] = $_FILES['bpimg']['type'][$key];
				$bp_imgs['tmp_name'][] = $_FILES['bpimg']['tmp_name'][$key];
				$bp_imgs['error'][] = $_FILES['bpimg']['error'][$key];
				$bp_imgs['size'][] = $_FILES['bpimg']['size'][$key];
			}
		}
		if($bp_imgs){
		    $implode_str = M("item_h")->where(array('id'=>$id))->getField("bpimg_list");
			$result = $this->_upload($bp_imgs, 'item_h/'.$date_dir, array(
				'width'=>C('iqw_item_bimg.width').','.C('iqw_item_simg.width'),
				'height'=>C('iqw_item_bimg.height').','.C('iqw_item_simg.height'),
				'suffix' => '_b,_s',
			));
			if ($result['error']) {
				$this->error($result['info']);
			} else {
				foreach( $result['info'] as $key=>$val ){
					$implode_str .= $implode_str ? ",".$date_dir.$val['savename'] : $date_dir.$val['savename'];
				}
			}
			M('item_h')->where(array('id'=>$id))->save(array('bpimg_list'=>$implode_str));
		}
		
    }
	//异步删除图片
	function delete_album() {
        $album_mod = M('shop_img');
        $album_id = $this->_post('album_id','intval');
		$album_info = $album_mod->field('url,item_id')->where('id='.$album_id)->find();
        if($album_info['url']){
            $ext = array_pop(explode('.', $album_info['url']));
            $album_min_img = 'data/upload/item_h/' . str_replace('.' . $ext, '_s.' . $ext, $album_info['url']);
            is_file($album_min_img) && @unlink($album_min_img);
			 $album_big_img = 'data/upload/item_h/' . str_replace('.' . $ext, '_b.' . $ext, $album_info['url']);
            is_file($album_big_img) && @unlink($album_big_img);
            $album_info['url'] = 'data/upload/item_h/' . $album_info['url'];
            is_file($album_info['url']) && @unlink($album_info['url']);
            $album_mod->delete($album_id);
			$id_count=$album_mod->where('item_id='.$album_info['item_id'])->count('id');
        }
        echo '1';
        exit;
    }
	//删除信息,包括图片
	function delete_item() {
        $album_mod = M('itemh_img');
        $album_id = $this->_get('id','intval');
		$album_info = $album_mod->field('url,item_id')->where('item_id='.$album_id)->find();
        if($album_info['url']){
            $ext = array_pop(explode('.', $album_info['url']));
            $album_min_img = 'data/upload/item_h/' . str_replace('.' . $ext, '_s.' . $ext, $album_info['url']);
            is_file($album_min_img) && @unlink($album_min_img);
			 $album_big_img = 'data/upload/item_h/' . str_replace('.' . $ext, '_b.' . $ext, $album_info['url']);
            is_file($album_big_img) && @unlink($album_big_img);
            $album_info['url'] = 'data/upload/item_h/' . $album_info['url'];
            is_file($album_info['url']) && @unlink($album_info['url']);
            $album_mod->where('item_id='.$album_id.' and type = 0')->delete();
        }
		$result=M('item_h')->where('id='.$album_id)->delete();
		if($result){
			IS_AJAX && $this->ajaxReturn(1, "删除成功");	
		}else{
			IS_AJAX && $this->ajaxReturn(0, L('删除失败'));
		}
    }
	
	
	
	
	//查看项目查看人
	public function record() {

		$map = array();
        $map['item_id'] =  $this->_get("id","intval");	
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
        $model = M('item_view');

        $list = $model->where($map)->order("id DESC")->select();
		
		$user = M("item_apply");
		foreach($list as $k=>$v){
			$uinfo = $user->where(array("id"=>$v['user_id']))->find();
			$list[$k]['username'] = $uinfo['the_user']."(".$uinfo['phone'].")";
            $list[$k]['con_name'] = $uinfo['con_name'];
            $list[$k]['wechat'] = $uinfo['wechat'];
		}
		M("item_view")->where($map)->save(array('is_view'=>1));
        $this->assign('list', $list);
		$this->assign("item_id",$map['item_id']);
		$this->display();
	}
	
	
	
	/**
	* excel导出
	*/
	public function getPrint(){
		
        $map['item_id'] =  $this->_get("item_id","intval");	
		$model = M('item_view');
        $list = $model->where($map)->order("id DESC")->select();
        $model->where($map)->save(array('is_dc'=>1));//已导出
		
       	if(empty($list)){
			$this->error('无数据信息，无法导出数据！');
		}
		$user = M("item_apply");
		foreach($list as $k => $v){
			$goods_list[$k]['id'] = $v['id'];
			$goods_list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);
			$goods_list[$k]['type'] = $v['is_see']==1?'看好':'一般';
			$uinfo = $user->where(array("id"=>$v['user_id']))->find();
			$goods_list[$k]['username'] = $uinfo['the_user']."(".$uinfo['phone'].")";
		}
		$miaoshu_arr= array(
			array("id","id"),array("type","点评类型"),array("username" ,"名称"),array("add_time","时间"),
		);
		$this->goods_export($goods_list,$miaoshu_arr);
	}










    //后台编辑删除相册图片
    function delete_album_bp() {
        $indexId = $this->_get('indexId','intval');
        $bpid = $this->_get("bpid");
        $info = M("item_h")->where(array("id"=>$bpid))->find();
        $bpimg = explode(",",$info['bpimg_list']);
        if($bpimg){
            foreach($bpimg as $k=>$v){
                if($k != $indexId){
                    $str .= $str ? ",".$v : $v;
                }
            }
            M("item_h")->where(array("id"=>$bpid))->save(array('bpimg_list'=>$str));
        }

        echo '1';
        exit;
    }
	
	
	
	
	
	
	
	
	
	
}