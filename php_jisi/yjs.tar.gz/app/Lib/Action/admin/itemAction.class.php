<?php
class itemAction extends backendAction {
   public function _initialize() {
        parent::_initialize();
        $this->_mod = D('item');
    }

    protected function _search() {
        $map = array();//搜索条件
        if( $keyword = $this->_request('keyword', 'trim') ){
            $map['_string'] = " title like '%".$keyword."%' OR inaword like '%".$keyword."%'";
            //$umap['the_user|phone'] =  array("like","%".$keyword."%");
//            $uarr = M("user")->where($umap)->getField('id',true);
//            if($uarr){
//                $map['user_id'] = array("in",$uarr);
//            }else{
//                $map['user_id'] = 0;
//            }
        }
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));                                                                                                                                                                             
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
		
        $this->assign('search', array(//表单回选值
		    'time_start' => $time_start,
            'time_end' => $time_end,
            'keyword' => $keyword,
        ));
		$map['is_show'] = 1;
        return $map;
    }

    public function index(){
		$map = $this->_search();
		$count = $this->_mod->where($map)->count('id');
        $pager = new Page($count, 20);
        $select = $this->_mod->where($map)->order('id DESC');
        $select->limit($pager->firstRow.','.$pager->listRows);
        $page = $pager->show();
        $this->assign("page", $page);
        $list = $select->select();
		$user = M("user");
		$item_can = M("item_can");
        foreach ($list as $key=>$val) {
			$list[$key]['cou_tzr'] = $item_can->where("item_id = ".$val['id'])->count("id");
            $list[$key]['username'] = $user->where("id = ".$val['user_id'])->getField("username");
            $list[$key]['the_user'] = $user->where("id = ".$val['user_id'])->getField("the_user");
        }
		
        $this->assign('list', $list);
		$this->display();	
    }


	 public function item_edit() {
        if (IS_POST) {
			
        } else {
            $id = $this->_get('id','intval');
            $item = $this->_mod->where(array('id'=>$id))->find();
			
			$item['username'] = M("user")->where("id = ".$item['user_id'])->getField("username");
			$item['the_user'] = M("user")->where("id = ".$item['user_id'])->getField("the_user");
			
			$item_sub = M("item_sub");
			$other = M("other_set");
			$wt_list = $other->where("pid = 22")->field("id,name")->select();
			//问题
			foreach($wt_list as $k=>$v){
				$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
				foreach($wt_list[$k]['ptype'] as $val){
					$map['wt_str'] = array("LIKE","%".$val['id']."%");
					$cou += $item_sub->where($map)->count("id");
				}
				
				foreach($wt_list[$k]['ptype'] as $a=>$b){
					$map['wt_str'] = array("LIKE","%".$b['id']."%");
					$wt_cou = $item_sub->where($map)->count("id");
					$wt_list[$k]['ptype'][$a]['bl'] = intval($wt_cou/$cou * 100);
				}
				$cou = '';
			}
			$this->assign("wt_list",$wt_list);
			
			//其它建议
			$pj_list = $item_sub->where("item_id = ".$item['id'])->select();
			$user = M("user");
			foreach($pj_list as $k=>$v){
				$uinfo = $user->where("id = ".$v['user_id'])->find();
				$pj_arr[$k]['tx_img'] = $uinfo['avatarUrl'];//头像
				$pj_arr[$k]['username'] = $uinfo['username'];//名称
				$pj_arr[$k]['address'] = $uinfo['address'];//地址
				$pj_arr[$k]['con_name'] = $uinfo['con_name'];//机构名称
				$pj_arr[$k]['is_love'] = $v['is_love'];//兴趣
				$pj_arr[$k]['commtent'] = $v['commtent'];//建议
				$pj_arr[$k]['item_id'] = $v['id'];
			}
			$this->assign("pj_arr",$pj_arr);
			
            //相册
			$img_list = explode(',',$item['tp_img']);
            $this->assign('img_list', $img_list);
            $this->assign('info', $item);
			
            $item_can = M("item_can")->where("item_id = ".$id)->getField("user_id",true);
            if($item_can){
                $umap['id'] = array("in",$item_can);
                $can_arr = M("user")->where($umap)->field("id,the_user,username,phone,avatarUrl")->select();
                $this->assign("can_arr",$can_arr);
            }

            $this->display("edit");
        }
    }

    /**
     * 删除
     */
    public function item_delete()
    {
        $ids = trim($this->_request('id'), ',');
        if ($ids) {
            if (false !== $this->_mod->delete($ids)) {
                
                IS_AJAX && $this->ajaxReturn(1, L('operation_success'));
            } else {
                IS_AJAX && $this->ajaxReturn(0, L('operation_failure'));
            }
        } else {
            IS_AJAX && $this->ajaxReturn(0, L('illegal_parameters'));
        }
    }
   
}