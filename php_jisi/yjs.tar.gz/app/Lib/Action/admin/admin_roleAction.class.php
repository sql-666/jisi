<?php

class admin_roleAction extends backendAction

{

    public function _initialize()

    {

        parent::_initialize();

        $this->_mod = D('admin_role');

    }



    public function _before_index()

    {

        $this->list_relation = true;

        $big_menu = array(

            'title' => '添加角色',

            'iframe' => U('admin_role/add'),

            'id' => 'add',

            'width' => '450',

            'height' => '190',

        );

        $this->assign('big_menu', $big_menu);

    }



    public function auth()

    {

        $menu_mod = D('menu');

        $auth_mod = D('admin_auth');

        if (isset($_POST['dosubmit'])) {

            $id = intval($_POST['id']);

            //清空权限

            $auth_mod->where(array('role_id'=>$id))->delete();

            if (is_array($_POST['menu_id']) && count($_POST['menu_id']) > 0) {

                foreach ($_POST['menu_id'] as $menu_id) {

                    $auth_mod->add(array(

                        'role_id' => $id,

                        'menu_id' => $menu_id

                    ));

                }

            }

            $this->success(L('operation_success'));

        } else {

            $id = $this->_get('id', 'intval');

            $tree = new Tree();

            $tree->icon = array('│ ','├─ ','└─ ');

            $tree->nbsp = '&nbsp;&nbsp;&nbsp;';

            $result = $menu_mod->order('ordid')->select();

            //获取被操作角色权限

            $role_data = $this->_mod->relation('role_priv')->find($id);

            $priv_ids = array();

            foreach ($role_data['role_priv'] as $val) {

                $priv_ids[] = $val['id'];

            }

            foreach($result as $k=>$v) {

                $result[$k]['level'] = $menu_mod->get_level($v['id'],$result);

                $result[$k]['checked'] = (in_array($v['id'], $priv_ids))? ' checked' : '';

                $result[$k]['parentid_node'] = ($v['pid'])? ' class="child-of-node-'.$v['pid'].'"' : '';

            }

            $str  = "<tr id='node-\$id' \$parentid_node>" .

                        "<td style='padding-left:10px;'>\$spacer<input type='checkbox' name='menu_id[]' value='\$id' class='J_checkitem' level='\$level' \$checked> \$name</td>

                    </tr>";

            $tree->init($result);

            $menu_list = $tree->get_tree(0, $str);

            $this->assign('list', $menu_list);

            $this->assign('role', $role_data);

            $this->display();

        }

    }

	

	

	//员工工作量

	public function results(){

		$uid = $_SESSION['admin']['id'];//用户Id

		$adminlist = M('admin')->where('role_id = 3 and status = 1')->field('id,user_id,real_name')->order('id asc')->select();	

		foreach($adminlist as $k=>$v){

			$adminlist[$k]['today'] = $this->gz_fun($v['id']);

		}

		$this->assign('adminlist',$adminlist);

		$this->display();	

	}

	

	public function gz_fun($uid){

		//员工每日工作量

		$site = M('site');

		$shop = M('shop');

		$remarks = M('remarks');

		if(IS_POST){

			$start = strtotime($_POST['time_start']);

			$end = strtotime($_POST['time_end']);

			$this->assign('search',array('time_start'=>$_POST['time_start'],'time_end'=>$_POST['time_end']));

		}else{

			$t = time();

			$start = mktime(0,0,0,date("m",$t),date("d",$t),date("Y",$t));//当天开始时间

			$end = mktime(23,59,59,date("m",$t),date("d",$t),date("Y",$t));//当开结束时间

		}

		

		$rem_map['uid'] = $uid;

		$rem_map['addtime'] = array("between",$start.",".$end);

		$rem_map['ser_or_resu'] = 1;

		$today['remcou'] = $remarks->where($rem_map)->count('id');//电话量

		

		$t_map['cate_id'] = 1;

		$t_map['add_time'] = array("between",$start.",".$end);

		$t_map['admin_id'] = $uid;

		$today['t_cou'] = $shop->where($t_map)->count('id');//发布的转让数量

		

		$t_map['cate_id'] = 2;

		$today['r_cou'] = $shop->where($t_map)->count('id');//发布的出租数量

		

		$sitemap['admin_id'] = $uid;

		$sitemap['add_time'] = array('between',$start.",".$end);

		$today['s_cou'] = $site->where($sitemap)->count('id');//发布的找址数量

		

		$focusmap['focus'] = $uid;

		$focusmap['focus_time'] = array('between',$start.",".$end);

		$focus1 = $shop->where($focusmap)->count('id');//保护的重点数量

		$focus2 = $site->where($focusmap)->count('id');

		$today['focus'] = $focus1+$focus2;

		

		return $today;

	}

	

	

	

	//员工业绩

	public function performance(){

		$user_list = M('admin')->field('id,user_id,real_name')->select();

		

		$achiev = M('achiev');

		if(IS_POST){

			$start = strtotime($_POST['time_start']);

			$end = strtotime($_POST['time_end']);

			$this->assign('search',array('time_start'=>$_POST['time_start'],'time_end'=>$_POST['time_end']));

			$map['add_time'] = array("between",$start.",".$end);

		}

		foreach($user_list as $k=>$v){

			$map['ascription'] = $v['id'];

			$map['type'] = 3;

			$user_list[$k]['site_cou'] = $achiev->where($map)->sum('ss_amount');

			

			$map['type'] = 1;

			$user_list[$k]['zy_cou'] = $achiev->where($map)->sum('ss_amount');

			

			$map['type'] = 2;

			$user_list[$k]['cz_cou'] = $achiev->where($map)->sum('ss_amount');;

		}

		$this->assign('user_list',$user_list);

		$this->display();

	}

	

	

	

	

}