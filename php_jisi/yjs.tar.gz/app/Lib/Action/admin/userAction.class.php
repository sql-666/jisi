<?php
/**
 * 用户信息管理
 */
class userAction extends backendAction
{

    public function _initialize() {
        parent::_initialize();
        $this->_mod = D('user');
    }

    protected function _search() {
        $map = array();
        if( $keyword = $this->_request('keyword', 'trim') ){
            $map['_string'] = "the_user like '%".$keyword."%' OR phone like '%".$keyword."%'";
        }
        $this->assign('search', array(
            'keyword' => $keyword,
        ));
		
		$type_id = intval($_GET['type_id']);
		$map["user_type"] = $type_id;
        return $map;
    }

    public function _before_index() {
		
		$type_id = intval($_GET['type_id']);
		$this->assign("type_id",$type_id);
		
        $big_menu = array(
            'title' => L('添加会员'),
            'iframe' => U('user/add',array("type_id"=>$type_id)),
            'id' => 'add',
            'width' => '500',
            'height' => '330'
        );
        $this->assign('big_menu', $big_menu);
    }
	
	public function _after_index($list){
		$industry = M("industry");
		foreach($list as $k=>$v){
			$type = explode(",",$v['type_id']);
			$map['id'] = array("in",$type);
			$type_name = $industry->where($map)->getField("name",true);
			$list[$k]['type_name'] = implode(",",$type_name);
		}
		return $list;
	}

    public function _before_insert($data) {
        if( ($data['password']!='')&&(trim($data['password'])!='') ){
            $data['password'] = $data['password'];
        }else{
            unset($data['password']);
        }
        $birthday = $this->_post('birthday', 'trim');
        if ($birthday) {
            $birthday = explode('-', $birthday);
            $data['byear'] = $birthday[0];
            $data['bmonth'] = $birthday[1];
            $data['bday'] = $birthday[2];
        }
        return $data;
    }

    public function _after_insert($id) {
        $img = $this->_post('img','trim');
        $this->user_thumb($id,$img);
		$type_id = implode(",",$_POST['type_id']);
		M("user")->where("id = ".$id)->save(array("type_id"=>$type_id));
		
    }

    public function _before_update($data) {
        if( ($data['password']!='')&&(trim($data['password'])!='') ){
            $data['password'] = md5($data['password']);
        }else{
            unset($data['password']);
        }
        $birthday = $this->_post('birthday', 'trim');
        if ($birthday) {
            $birthday = explode('-', $birthday);
            $data['byear'] = $birthday[0];
            $data['bmonth'] = $birthday[1];
            $data['bday'] = $birthday[2];
        }
		
		$data['type_id'] = implode(",",$_POST['type_id']);
		
        return $data;
    }
	
	public function _before_add( ){
		$type = M("industry")->where("status = 1")->select();
		$this->assign("type",$type);
		$this->assign("type_id",$_GET['type_id']);
    }
	
	public function _before_edit($info){
		
		$type_id = intval($_GET['type_id']);
		$this->assign("type_id",$type_id);
		
		$type = M("industry")->where("status = 1")->select();
		$this->assign("type",$type);
		
		$type_id = $info['type_id'];
		$info['type_arr'] = explode(",",$type_id);
		return $info;
    }

    public function _after_update($id){
        $img = $this->_post('img','trim');
        if($img){
            $this->user_thumb($id,$img);
        }
    }

    public function user_thumb($id,$img){
        $img_path= avatar_dir($id);
        //会员头像规格
        $avatar_size = explode(',', C('iqw_avatar_size'));
        $paths =C('iqw_attach_path');

        foreach ($avatar_size as $size) {
            if($paths.'avatar/'.$img_path.'/' . md5($id).'_'.$size.'.jpg'){
                @unlink($paths.'avatar/'.$img_path.'/' . md5($id).'_'.$size.'.jpg');
            }
            !is_dir($paths.'avatar/'.$img_path) && mkdir($paths.'avatar/'.$img_path, 0777, true);
            Image::thumb($paths.'avatar/temp/'.$img, $paths.'avatar/'.$img_path.'/' . md5($id).'_'.$size.'.jpg', '', $size, $size, true);
        }

        @unlink($paths.'avatar/temp/'.$img);
    }
	
	//企业扩展信息
 	public function userinfo(){
		$model = D("user_info");
        if (IS_POST) {						
			$data = $model->create();
			if($data['id']){
				$model->where(array("id"=>$data["id"]))->save($data);
			}else{
				$model->add($data);
			}
            $this->success(L('operation_success'));
        } else {
			$uid = $this->_get('id', 'intval');
			
			if(empty($uid) && $this->qyid){
				$uid = $this->qyid;
			}else{
				$this->error("此菜单项为企业用户申请窗口！",U("index/panel"));
			}
			$info = $model->where(array("uid"=>$uid))->find();
			$info["base"] = M("user")->field("id,nickname")->find($uid);
			$this->assign("info",$info);
            $this->display();
        }
    }
    public function add_users(){
        if (IS_POST) {
            $users = $this->_post('username', 'trim');
            $users = explode(',', $users);
            $password = $this->_post('password', 'trim');
            $gender = $this->_post('gender', 'intavl');
			
			$type = $this->_post('type', 'intavl',2);
			$utype = $this->_post('utype', 'intavl',0);
			
            $reg_time= time();
            $data=array();
            foreach($users as $val){
                $data['password']=$password;
                $data['gender']=$gender;
				$data['type']=$type;
				$data['utype']=$utype;
                $data['reg_time']=$reg_time;
                if($gender==3){
                    $data['gender']=rand(0,1);
                }
                $data['username']=$val;
				$data['nickname']=$val;
                $this->_mod->create($data);
                $this->_mod->add();
            }
            $this->success(L('operation_success'));
        } else {
			$ulist = $this->getUserType();
			$this->assign("ulist",$ulist);
            $this->display();
        }
    }




	 /**

     * 修改会员余额

     */
    public function edit_balance(){
        $mod = D($this->_name);
        $pk = $mod->getPk();//获取主键名称
        if (IS_POST) {
			$money = $this->_post("balance","intval");
			$uid = $this->_post("id","intval");
			if(!empty($money)){
				$uinfo = $mod->where(array("id"=>$uid))->field("username,phone,money")->find();
				$balance_new = $uinfo['money'] + ($money);
				$type = $balance_new < $uinfo['money'] ? 0 : 1;//如果小于我的余额。则为支出。否则为收入
				$title = $balance_new < $uinfo['money'] ? '('.$uinfo['money'].')消费' : '('.$uinfo['phone'].')会员充值';//如果小于我的余额。则为支出。否则为收入
				if($balance_new >= 0 ){
					$ret_act = $mod->where(array("id"=>$uid))->save(array("money"=>$balance_new));
				}else{
					$ret_act = false;
					$this->ajaxReturn(0,L('operation_failure').",会员余额不能为负数！");
				}
			}
	
			if (false !== $ret_act) {
				//写日志
				$role_id=$_SESSION['admin']['role_id'];
				$name=M('admin_role')->where('id='.$role_id)->getField('name');//记录管理员名称
				$ldata['uid'] = $uid;
				$ldata['mname'] = $name;	//当前登录管理员名称
				$ldata['uname'] = $uinfo['phone'];
				$ldata['action'] = "sysman";
				$ldata['score'] = $money;
				$ldata['add_time'] = time();
				$ldata['balance'] = $balance_new;
				M("balance_log")->add($ldata);
				
                IS_AJAX && $this->ajaxReturn(1, L('operation_success'), '', 'edit');
                $this->success(L('operation_success'));
            } else {
                IS_AJAX && $this->ajaxReturn(0, L('operation_failure'));
                $this->error(L('operation_failure'));
            }
        } else {
            $id = $this->_get($pk, 'intval');
            $info = $mod->find($id);
            $this->assign('info', $info);
            $this->assign('open_validator', true);
            if(IS_AJAX) {
                $response = $this->fetch();
                $this->ajaxReturn(1, '', $response);
            } else {
                $this->display();
            }
        }
    }

	//查看会员的消费记录

	public function record() {

		$map = array();
        $map['uid'] =  $this->_get("id","intval");	
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
        $model = M('balance_log');
		 //如果需要分页
		$pagesize = 100 ;
        $count = $model->where($map)->count('id');

        $pager = new Page($count, $pagesize);
        $select = $model->where($map)->order("id DESC");
        $this->list_relation && $select->relation(true);
        $select->limit($pager->firstRow.','.$pager->listRows);
		$page = $pager->show();
		$this->assign("page", $page);
        $list = $select->select();
        $this->assign('list', $list);
		$this->display();
	}




















    public function ajax_upload_imgs() {
        //上传图片
        if (!empty($_FILES['img']['name'])) {
            $result = $this->_upload($_FILES['img'], 'avatar/temp/' );
            if ($result['error']) {
                $this->error($result['info']);
            }else {
                $data['img'] =  $result['info'][0]['savename'];
                $this->ajaxReturn(1, L('operation_success'), $data['img']);
            }


        } else {
            $this->ajaxReturn(0, L('illegal_parameters'));
        }
    }

    /**
     * ajax检测会员是否存在
     */
    public function ajax_check_name() {
        $name = $this->_get('username', 'trim');
        $id = $this->_get('id', 'intval');
        if ($this->_mod->name_exists($name,  $id)) {
            $this->ajaxReturn(0, '该会员已经存在');
        } else {
            $this->ajaxReturn();
        }
    }

    /**
     * ajax检测邮箱是否存在
     */
    public function ajax_check_email() {
        $name = $this->_get('email', 'trim');
        $id = $this->_get('id', 'intval');
        if ($this->_mod->email_exists($name,  $id)) {
            $this->ajaxReturn(0, '该邮箱已经存在');
        } else {
            $this->ajaxReturn();
        }
    }
	
	
	
	/**
	* excel导出
	*/
	public function getPrint(){
		//只导出本栏目下未使用的
		$user_list = M("user")->field("id,username,phone,type,sex,email,reg_time,last_time")->order("id asc")->limit(2000)->select();
       	if(empty($user_list)){
			$this->error('无数据信息，无法导出数据！');
		}
		foreach($user_list as $k => $v){
			$user_list[$k]['reg_time'] = date("Y-m-d H:i:s",$v['reg_time']);
			$user_list[$k]['last_time'] = date("Y-m-d H:i:s",$v['last_time']);
			$user_list[$k]['type'] = $v['type']==1?'注册会员':'收费会员';
		}
		$miaoshu_arr= array(
			array("id","id"),array("username","会员名称"),array("phone" ,"会员手机号"),array("type","注册类型"),array("sex","性别"),array("email","电子邮箱"),array("reg_time","注册时间"),array("last_time","最后登录时间"),
		);
		$this->goods_export($user_list,$miaoshu_arr);
		//$this->display();	//如果是直接输出Excel文件，则不能加载模板
	}
	
	

}