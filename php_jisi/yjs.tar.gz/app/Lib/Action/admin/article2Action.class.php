<?php
class article2Action extends backendAction
{
    public function _initialize() {
        parent::_initialize();
    }

    public function _before_index() {
		
    }
	
	protected function _search() {
		$map['type'] = $this->_get('type');
        return $map;
    }
	
	
	public function _before_add(){
        $type = $this->_get('type');
        $this->assign('type',$type);
    }
	
	public function art_view(){
		$aid = $this->_get('aid');	
		$info = M('article2')->where("id = $aid")->find();
		$this->assign('info',$info);
		$this->display();
	}
	
	
	
	
   
}