<?php
class serviceAction extends backendAction {
   public function _initialize() {
        parent::_initialize();
        $this->_mod = D('service');
    }
    protected function _search() {
        $map = array();//搜索条件
        if( $keyword = $this->_request('keyword', 'trim') ){
            //$map['_string'] = "name like '%".$keyword."%' OR intro like '%".$keyword."%'";
			$umap['the_user|phone'] =  array("like","%".$keyword."%");
			$uarr = M("user")->where($umap)->getField('id',true);
			$map['user_id'] = array("in",$uarr);
        }
		($time_start = $this->_request('time_start', 'trim')) && $map['add_time'][] = array('egt', strtotime($time_start));                                                                                                                                                                             
        ($time_end = $this->_request('time_end', 'trim')) && $map['add_time'][] = array('elt', strtotime($time_end)+(24*60*60-1));
        $this->assign('search', array(//表单回选值
		    'time_start' => $time_start,
            'time_end' => $time_end,
            'keyword' => $keyword,
        ));
		$map['is_show'] = 1;
        return $map;
    }
	
  
	public function _before_add(){
		$indu_list = M("industry")->where("status = 1")->field("id,name")->select();
		$this->assign("indu_list",$indu_list);
	}
	
 	protected function _before_insert($data) {
        //上传图片
        if (!empty($_FILES['service_img']['name'])) {
            $art_add_time = date('ym/d/');
			$result = $this->_upload($_FILES['service_img'], 'service_img/'.$art_add_time, array(
                'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'), 
                'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
                'suffix' => '_b,_s',
            ));
            if ($result['error']) {
                $this->error($result['info']);
            } else {
                $ext = array_pop(explode('.', $result['info'][0]['savename']));
				$data['img'] = $art_add_time .$result['info'][0]['savename'];
            }
        }
		$data['add_time'] = time();
        return $data;
    }
	
	public function _before_update($data){
		if (!empty($_FILES['service_img']['name'])) {
            $art_add_time = date('ym/d/');
			$result = $this->_upload($_FILES['service_img'], 'service_img/'.$art_add_time, array(
                'width'=>C('iqw_score_article_img.bwidth').','.C('iqw_score_article_img.swidth'), 
                'height'=>C('iqw_score_article_img.bheight').','.C('iqw_score_article_img.sheight'),
                'suffix' => '_b,_s',
            ));
			
            if ($result['error']) {
                $this->error($result['info']);
            } else {
               $ext = array_pop(explode('.', $result['info'][0]['savename']));
			   $data['img'] = $art_add_time .$result['info'][0]['savename'];
			   
            }
        }
		return $data;	
	}
	
	
	
	
	
	
	
	
	
	
}