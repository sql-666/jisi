<?php
/**
 * 接口控制器基类
 */
class apibaseAction extends baseAction{
	public $url = 'https://yjs.anei10.con/';
//	public $url = 'http://yjs.com/';
    public function _initialize(){
        $this->url = 'https://'.$_SERVER['SERVER_NAME'].'/';
    }

    //json 输出格式
   public function _tojson($code,$msg,$data = ''){
		//当data为空 
		$str = array(
				'code' => $code,
				'msg' => $msg,
				'data' => ""
		);
		//当$data  不为空
		$array = array(
				'code' => $code,
				'msg' => $msg,
				'data' => $data
		);
		$data = $data==''?$str:$array;
		echo json_encode($data);
		exit;
	}
	
	
	public function number($k){
		$arr = explode(".",$k);
		$a = substr($arr[1],0,2);
		$number = empty($a) ? '00' :  $a;
		$ok = $arr[0].'.'.$number;
		return $ok;
	}
	
	/**
	*	获取用户余额
	*/
	public function user_money(){
		$user_id = $this->is_login();	
		$money = M("user")->where("id = ".$user_id)->getField("money");
		tojson("1","success",$money);
	}	
	
	/**
	*	检查是否登录
	*/
	public function is_login(){
		$user_id = $_GET['user_id'];
		$user_id = M('user')->where("id = '".$user_id."'")->getField('id');
		if($user_id){
			 return $user_id;
	    }else{
			tojson('-1','请先登录');
		}
	}



    public function getAccessToken () {
        $appid = "wx125db524eb3601a6";
        $appsecret = "135b8efde526dce270309f36244eaa97";
        $url='https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
        $html = file_get_contents($url);
        $output = json_decode($html, true);
        $access_token = $output['access_token'];
        return $access_token;
    }

    //发送微信模板消息
    public function sendtpl($openid,$mbid,$title,$content,$userName,$url){
        $accessToken = $this->getAccessToken();
        $formId = $_REQUEST['formId'];
        $time = date("Y-m-d H:i:s",time());
        $postData = array(
            "touser"        =>$openid,      //用户openid
            "template_id"   =>$mbid,  //模板消息ID
            "page"          =>$url,
            "form_id"       =>$formId,      //表单提交场景下，事件带上的 formId；支付场景下，为本次支付的 prepay_id
            "data"          =>array(
                'keyword1'  => array('value'=>$title),
                'keyword2'  => array('value'=>$userName),
                'keyword3'  => array('value'=>$content),
                'keyword4'  => array('value'=>$time)
            ),
            'emphasis_keyword'=>''
        );
        $postData =  json_encode($postData,JSON_UNESCAPED_UNICODE);
        $url = "https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token={$accessToken}";
        $rtn = $this->LCurl($url,$postData);
        return $rtn;
    }

    protected function LCurl($url,$post=null,$second=10){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        if($post){
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }

        $data = curl_exec($ch);
        if($data){
            curl_close($ch);
            return json_decode($data,true);
        } else {
            $error = curl_errno($ch);
            curl_close($ch);
            throw new Exception("curl出错，错误码:$error");
        }
    }













}