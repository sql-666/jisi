<?php
/**
 * 前台控制器基类
 * @author andery
 */
class frontendAction extends baseAction {
    protected $visitor = null;
    public function _initialize() {
        parent::_initialize();
        //网站状态
        if (!C('iqw_site_status')) {
            header('Content-Type:text/html; charset=utf-8');
            exit(C('iqw_closed_reason'));
        }
        //初始化访问者
        $this->_init_visitor();
		$this->setNav();//栏目高亮
		$this->userNav();//用户中心高亮
        //第三方登陆模块
        $this->_assign_oauth();
		$this->assign("staticVerson",1);
		
		/*
		//推荐友情链接-50条
		$frlink = M("flink")->where(array("status"=>1))->limit(50)->field("name,url")->order("ordid asc,id asc")->select();
		$this->assign("frlink", $frlink);
		//内页广告
	    $ads = M("ad")->where(array("board_id"=>17,"status"=>1))->order("id asc")->field("content,url")->find();
	    $this->assign("leftadimg",$ads);
		*/
    }
    /**
    * 初始化访问者
    */
    private function _init_visitor() {
        $this->visitor = new user_visitor();
        $this->assign('visitor', $this->visitor->info);
    }
    /**
     * 第三方登陆模块
     */
    private function _assign_oauth() {
        if (false === $oauth_list = F('oauth_list')) {
            $oauth_list = D('oauth')->oauth_cache();
        }
        $this->assign('oauth_list', $oauth_list);
    }
	private function setNav(){
		$curNavIndex = 1;
		$CurIndexUrl=$_SERVER["REQUEST_URI"];
		if($CurIndexUrl =='/'){
			$curNavIndex = 1;
		} else if(strpos($CurIndexUrl,"finds") ){
			$curNavIndex = 2;
		} else if(strpos($CurIndexUrl,"transfer") ){
			$curNavIndex = 3;
		} else if(strpos($CurIndexUrl,"rent") ){
			$curNavIndex = 4;
		} else if(strpos($CurIndexUrl,"article") ){
			$curNavIndex = 5;
		} 
		$this->assign('curNav',$curNavIndex);
		unset($curNavIndex);
	}
	/*会员中心高亮*/
	private function userNav(){
		$userNavIndex = 1;
		$CurIndexUrl=$_SERVER["REQUEST_URI"];
		if(strpos($CurIndexUrl,"user_fav")){
			$userNavIndex = 1;
		} else if(strpos($CurIndexUrl,"user_demand") ){
			$userNavIndex = 2;
		} else if(strpos($CurIndexUrl,"user_goods") ){
			$userNavIndex = 3;
		} else if(strpos($CurIndexUrl,"account") ){
			$userNavIndex = 4;
		}
		$this->assign('userNav',$userNavIndex);
		unset($userNavIndex);
	}
	
	 //获取多条广告
	protected function getAdList($board_id=1,$limit=10){
		//图片广告
		$row=M("ad")->where("status = 1 and board_id='$board_id'")->field("id")->limit($limit)->order("ordid asc")->select();
		$ret_ads = array();
		foreach($row as $v){
			$ret_ads[] = $this->getOneAd($v['id']);
		}
		return $ret_ads;
	}
	
	//获取单条广告
	protected function getOneAd($adid){		
		$row = D("ad")->field("type1,shop_type,shop_id,name,url,start_time,end_time,content")->where("status=1")->find($adid);		
		if($row){
			//先判断是否过期
			$ntime = strtotime(date("Y-m-d"));
			if($row['start_time'] < $ntime || $row['start_time'] < $ntime){	//表明还未开始或已过期
				$ret_ad = array("link"=>"javascript:void(0)","blank"=>0,"src"=>"/data/upload/nopic.jpg","title"=>"广告未开启或过期");
			}
			if($row['type1'] == 2){	//产品ID类型广告
				$img = "";$title = "";
				switch($row['shop_type']){					
					case 1:
						$url=U("shops/rent_item",array('id'=>$row['shop_id']) );
						$iinfo = M("shop")->where(array("id"=>$row['shop_id']))->field("title,img");
						$img = $iinfo["img"];$title = $iinfo["title"];
					break;
					case 2:
						$url=U("shops/transfer_item",array('id'=>$row['shop_id']) );
						$iinfo = M("shop")->where(array("id"=>$row['shop_id']))->field("title,img");
						$img = $iinfo["img"];$title = $iinfo["title"];
					break;
					case 3:
						$url=U("index/finds_item",array('id'=>$row['shop_id']) );
						$title = M("site")->where(array("id"=>$row['shop_id']))->getField("title");
						$img = $row["content"];
						
					break;
				}
				//URL 和自定义图片权限较高
				if(!empty($row['url']) && $row['url']!="#"){ $url=$row['url']; }	//自定义链接优先
				if(empty($url) || $url=="#"){$blank = 0;}else{ $blank = 1;}
				
				if(!empty($row['content'])){	//自定义图片优先
					$img = attach($row['content'], 'ad_bran');
				}else{
					if(empty($img)){
						$img = "/data/upload/nopic.jpg";
					}else{
						$img = attach($img, 'shop');
					}
				}
				
				$ret_ad = array("link"=>$url,"blank"=>$blank,"src"=>$img,"title"=>$title);
				
			}else{	//自定义常规广告
				if(empty($row['url']) || $row['url']=="#"){$blank = 0;}else{ $blank = 1;}
				$ret_ad = array("link"=>$row['url'],"blank"=>$blank,"src"=>attach($row['content'], 'ad_bran'),"title"=>"");
			}
			return $ret_ad;
		}
	}
	 
	 
	//详细页面的面包导航专用，解决那个最上层链接问题
	protected function getNav_view($model,$modelstr,$cate_id,$level=5,$flag=" &gt; "){
		$level--;
		$row = $model->field("id,name,pid")->find($cate_id);
		if($row['pid'] == 0){ 
			$linkstr = "<a href='".U($modelstr)."'>".$row['name']."</a>";
		}else{
			$linkstr = "<a href='".U($modelstr."?cid=".$row[id])."'>".$row['name']."</a>";
		}
		if($level>0){
			if($row['pid'] ==0){
				return $linkstr;
			}else{
				return $this->getNav_view($model,$modelstr,$row['pid'],$flag).$flag.$linkstr;
			}
		}else{
			return $linkstr;
		}
	}
	//获取下一级的子栏目
	protected function getSonids($bigId,$modelstr="article_cate",$orderstr = 'ordid asc,id asc') {
		$model = D($modelstr);
		$map['pid'] = $bigId;
		$map['status'] = 1;
        return $model->order($orderstr)->where($map)->getField('id',true);
    }
	protected function showpage($count, $pagesize) {
		$pager = new Page($count, $pagesize);
        $pager->rollPage = 5;
        $pager->setConfig('prev', '<');
        $pager->setConfig('theme', '%upPage% %first% %linkPage% %end% %downPage%');
        return $pager;
	}
    /**
     * SEO设置
     */
    protected function _config_seo($seo_info = array(), $data = array()) {
        $page_seo = array(
            'title' => C('iqw_site_title'),
            'keywords' => C('iqw_site_keyword'),
            'description' => C('iqw_site_description')
        );
        $page_seo = array_merge($page_seo, $seo_info);
        //开始替换
        $searchs = array('{site_name}', '{site_title}', '{site_keywords}', '{site_description}');
        $replaces = array(C('iqw_site_name'), C('iqw_site_title'), C('iqw_site_keyword'), C('iqw_site_description'));
        preg_match_all("/\{([a-z0-9_-]+?)\}/", implode(' ', array_values($page_seo)), $pageparams);
        if ($pageparams) {
            foreach ($pageparams[1] as $var) {
                $searchs[] = '{' . $var . '}';
                $replaces[] = $data[$var] ? strip_tags($data[$var]) : '';
            }
            //符号
            $searchspace = array('((\s*\-\s*)+)', '((\s*\,\s*)+)', '((\s*\|\s*)+)', '((\s*\t\s*)+)', '((\s*_\s*)+)');
            $replacespace = array('-', ',', '|', ' ', '_');
            foreach ($page_seo as $key => $val) {
                $page_seo[$key] = trim(preg_replace($searchspace, $replacespace, str_replace($searchs, $replaces, $val)), ' ,-|_');
            }
        }
		if($page_seo["title"] != C('iqw_site_title')){
			$page_seo["title"] .= "_".C('iqw_site_title');
		}
        $this->assign('page_seo', $page_seo);
    }
    /**
    * 连接用户中心
    */
    protected function _user_server() {
        $passport = new passport(C('iqw_integrate_code'));
        return $passport;
    }
    /**
     * 前台分页统一
     */
    protected function _pager($count, $pagesize) {
        $pager = new Page($count, $pagesize);
        $pager->rollPage = 5;
        $pager->setConfig('prev', '<');
        $pager->setConfig('theme', '%upPage% %first% %linkPage% %end% %downPage%');
        return $pager;
    }
    
	 //调用 $this->mail("测试邮件标111题","邮件测试222正文");	
    protected function mail($title_to,$content_to,$sjrEmail="",$send_type='0') {
		import('@.ORG.mail.PHPMailer');
		global $error_msg;
		$mail = new PHPMailer();
		if($send_type > 0){
			$mail->IsSendmail();							// send via Sendmail
		}else{	
			$mail->IsSMTP(); 								// send via SMTP
		}
		if(empty($sjrEmail)){
			$mail_to = C('MAIL_TO');
		}else{
			$mail_to = $sjrEmail;
		}
		$mail->SMTPAuth = true;         					// turn on SMTP authentication
		$mail->IsHTML(true);  								// 是不支持html
		$mail->AltBody ="text/html";
		$mail->Host = C('SMTP_LOCALHOST'); 						// SMTP servers
		$mail->Username = C('SMTP_EMAIL');   					// SMTP username  注意：普通邮件认证不需要加 @域名
		$mail->Password = C('SMTP_EMAIL_PASS');       					// SMTP password
		$mail->CharSet = "utf-8";            				// 这里指定字符集！
		$mail->Encoding = "base64";
		$name_to = C('SMTP_NAME');  
		if(is_array($mail_to)){								// 多个地址时
			$num = count($mail_to);
			for($i=0;$i<$num;$i++){
				$mail->AddAddress($mail_to[$i],$name_to);
			}
		}else{
			$mail->AddAddress($mail_to,$name_to);  				// 收件人邮箱和姓名
		}
		$mail->Subject = $title_to;							// 邮件主题
		$mail->Body = $content_to;							// 邮件内容
		$mail->From = C('SMTP_EMAIL');     						// 发件人邮箱
		$mail->FromName = C('SMTP_NAME');  				// 发件人
		$mail->AddReplyTo($mail_from,C('SMTP_NAME'));		// 回复人邮箱和姓名
		//$mail->WordWrap = 50; // set word wrap
		//$mail->AddAttachment("/var/tmp/file.tar.gz"); 	// attachment
		//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");
		if(!$mail->Send()){
			//echo "Sent mail error!\n";
			//echo "<br/>Error: " . $mail->ErrorInfo;
			echo $error_msg .="<br/>Error: ".$mail->ErrorInfo;
			return false;
		}
		else {
			//echo "sent successfully!\n";
			$mail->ClearAddresses();							// 删除地址和附件
			$mail->ClearAttachments();
			return true;
		}
	}
	/**
	* 筛选获取 行业 区域 面积
	*/
	public function screen_an(){
		$industry = M('industry')->where('pid = 0')->field('id,name')->select();
		$address = M('address_set')->where('pid = 0')->field('id,name')->select();
		$acreagen = C('acreagen');
		$this->assign('acreagen',$acreagen);
		$this->assign('address',$address);
	    $this->assign('industry',$industry);
	}
	/**
	* 获取筛选条件
	*/
	public function screen_an_tj(){		
		$ass['a'] = $this->_request('A');//行业
		$ass['b'] = $this->_request('B');//区域
		if(!empty($ass['a'])){
			$ass['a_zl'] = $this->_request('a_zl');//行业子类
		}
		if(!empty($ass['b'])){
			$ass['b_zl'] = $this->_request('b_zl');//区域子类
		}
		$ass['c'] = $this->_request('C');//面积
		$ass['d'] = $this->_request('D');//租金
		//行业 区域 面积 租金
		$industry = M('industry')->where('pid = 0')->order('ordid desc')->field('id,name')->select();
		$address = M('address_set')->where('pid = 0')->order('ordid desc')->field('id,name')->select();
		$acreagen = C('acreagen');
		$rent = C('rent');
		/* 获取所选分类的子类 */
		if(!empty($ass['a'])){
	    	$industry['zl'] = M('industry')->where('pid = '.$ass['a'])->field('id,name')->select();
		}
		if(!empty($ass['b'])){
			$address['zl'] = M('address_set')->where('pid = '.$ass['b'])->field('id,name')->select();
		}
		/*返回筛选值*/
		if(!empty($ass['a'])){
			$map['s.industry_pid'] = $ass['a'];
		}
		if(!empty($ass['a_zl'])){
			$map['s.industry_id'] = $ass['a_zl'];
		}
		if(!empty($ass['b'])){
			$map['s.district_id'] = $ass['b'];
		}
		if(!empty($ass['b_zl'])){
			$map['s.vicinity_id'] = $ass['b_zl'];
		}
		if(!empty($ass['c'])){
			$area_sele = explode('e',$ass['c']);//面积表单回选值
			if($area_sele[0]!="00" && $area_sele[1]!="00"){
				$ass['c'] = $area_sele[0]."e".$area_sele[1];
				$map['s.area']=array(array('egt',$area_sele[0]),array('elt',$area_sele[1]));
			}else if($area_sele[0]!="00" || $area_sele[1]!="00"){
				if($area_sele[0]=="00"){
					$ass['c'] = "00e".$area_sele[1];
					$map['s.area']=array(array('egt',0),array('elt',$area_sele[1]));
				}else{
					$ass['c'] = $area_sele[0]."e00";
					$map['s.area']=array('egt',$area_sele[0]);
				}
			}
		}else{
			$ass['c'] = '';	
		}
		if(!empty($ass['d'])){
			if($ass['d'] == 10){
				$map['s.rent'] = '';
				$ass['d'] = $ass['d'];//面议
			}else{
				$rent_sele = explode('e',$ass['d']);//租金表单回选值
				if($rent_sele[0]!="00" && $rent_sele[1]!="00"){
					$ass['d'] = $rent_sele[0].'e'.$rent_sele[1];
					$map['s.rent']=array(array('egt',$rent_sele[0]),array('elt',$rent_sele[1]));
				}else if($rent_sele[0]!="00" || $rent_sele[1]!="00"){
					if($rent_sele[0]=="00"){
						$ass['d'] = '00e'.$rent_sele[1];
						$map['s.rent']=array(array('egt',0),array('elt',$rent_sele[1]));
					}else{
						$ass['d'] = $rent_sele[0]."e00";
						$map['s.rent']=array('egt',$rent_sele[0]);
					}
				}
			}
		}else{
			$ass['d'] = '';	
		}
		//print_r($ass);exit;
		$this->assign('ass',$ass);//用于判断高亮
		$this->assign('acreagen',$acreagen);//面积
		$this->assign('address',$address);//区域
	    $this->assign('industry',$industry);//分类
		$this->assign('rent',$rent);//租金值
		$this->assign('area_sele',$area_sele);//面积表单回选值
		$this->assign('rent_sele',$rent_sele);//租金表单回选值	
		return $map;	
	}
	/*
	* 排序
	*/
	public function asc_desc(){
	   $order=$this->_get('order','trim');//排序
	   $by=$this->_get('by','trim');//排序是升还是降
	   if($by == 'asc'){
		   $asc_desc[] = '';
	   }else{
		   $asc_desc[$order] = 1;   
	   }
	   $this->assign('asc_desc',$asc_desc);//排序
	}
	/**
     * 依据类型获取店铺
	 * type  店铺类型 1是转让 2是出租
	 * str   筛选类型
	 * limit 获取条数
     */
	 public function type_shop_list($type,$str,$limit=4){
	    $shop = M('shop');
		$map['s.cate_id'] = $type; // 店铺类型
		if($str == "isindex"){
			$map['s.isindex'] = 1; //是否推荐
		}
		if($str == "isselect"){
			$map['s.isselect'] = 1; //是否精选
		}
		if($str == "isurgent"){     //紧急
		 	$map['s.isurgent'] = 1;
		}
		if($str == "ishot"){     //热销
		 	$map['s.ishot'] = 1;
		}  
		if($str == "isnew"){     //最新
		 	$map['s.isnew'] = 1;
		}
	    $shop_list = $shop
				   ->where($map)
				   ->alias('s')
				   ->field("CONCAT(a.name,b.name) as name,
				   			s.id,s.title,s.img,s.rent,s.area,s.mobile,s.address,s.contacts,s.refresh_time")
				   ->join("iqw_address_set a on s.district_id = a.id")
				   ->join("iqw_address_set b on s.vicinity_id = b.id")
				   ->limit(0,$limit)
				   ->order("s.ordid desc,s.refresh_time desc,s.id desc")
				   ->select();
	    return $shop_list;
	 }
	/**
	 *	找店选址 获取店铺函数
	 *
	 */
	 public function finds_info($str,$limit=10){
		$site = M('site');
		if($str == "isindex"){
			$map['isindex'] = 1;
		}
		if($str == "isnew"){
			$map['isnew'] = 1;
		}
		$tj_site = $site->where($map)->field('id,title,area_min,area_max,rent_min,rent_max,contacts,mobile,refresh_time,district_id')->order('ordid desc,refresh_time desc,id desc')->limit(0,$limit)->select();
		$address_set = M('address_set');
		foreach($tj_site as $k=>$v){
			$tj_site[$k]['qw_qy'] = $address_set->where('id = '.$v['district_id'])->getField('name');
		}
		return $tj_site;
	 }
	 
	 //获取广告位信息
	public function getAd($where,$type=1){
		$admode=M('ad');
		$where=$where." and status=1 and ".time()." <=end_time and ".time()." >=start_time";
		$field="id,type1,shop_id,shop_type,name,url,content";
		$order="ordid desc";
		if($type==1){
			//返回单条数据
			$result=$admode->field($field)->where($where)->order($order)->find();
		}else{
			//返回多条数据
			$result=$admode->field($field)->where($where)->order($order)->select();
		}

		for($i=0;$i<count($result);$i++){
			if($result[$i]['url']!=""){
				//如果广告链接路径不为空
				if($result[$i]['type1']==2){
					if($result[$i]['shop_id']!=0){
						switch($result[$i]['shop_type']){
							case "1":
								$result[$i]['url']=U("shops/rent_item',array('id'=>$result[$i]['shop_id'])");
							break;
							case "2":
								$result[$i]['url']=U("shops/transfer_item',array('id'=>$result[$i]['shop_id'])");
							break;
							case "3":
								$result[$i]['url']=U("shops/finds_item',array('id'=>$result[$i]['shop_id'])");
							break;
						}
					}
				}	
			}
		}
		
		return $result;
		
	}
}