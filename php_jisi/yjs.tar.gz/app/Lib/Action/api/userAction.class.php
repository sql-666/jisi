<?php

/**

 * BP项目接口文件

 */

class userAction extends apibaseAction{

    public function _initialize() {
		parent::_initialize();
    }

	
	
	public function login(){
		if(empty($_POST)){
            $this->_tojson('-1','非法请求');
        }

        $param = array(
            'appid' => 'wxa51ca69a7239d16c',
            'secret' => '2e068d1d9e6a01a39cdd96abaa310fc7',
            'js_code'=> $_POST['code'],
            'grant_type'=>'authorization_code'
        );

        $url = 'https://api.weixin.qq.com/sns/jscode2session?'.http_build_query($param);
        $resoult = file_get_contents($url);
        $res = json_decode($resoult,true);
        if(isset($res['errcode']) || empty($res['openid'])){
            $this->_tojson('-3','openID获取失败');
        }

        $useradd['openid'] = $res['openid'];

        $info = M('user')->where($useradd)->find();
        if($info){
//            $save['avatarUrl'] = $_GET['avatarUrl'];
//            M('user')->where("id = ".$info['id'])->save($save);
            $this->_tojson("1","success",$info['id']);
        }else{
//            $useradd['avatarUrl'] = $_POST['avatarUrl'] ? $_POST['avatarUrl'] : $this->url."statics/images/header.png";
//            $useradd['username'] = preg_replace('/[\xf0-\xf7].{3}/', '', $_POST['nickName']);
            $useradd['reg_time'] = time();
            $insert_id = M('user')->add($useradd);
            $this->_tojson('1','success',$insert_id);
        }
	}

    /**
     * 完善用户资料
     */
    public function update_user_info(){
        $user_id = $this->_request('user_id');
        if(empty($user_id)){
            $this->_tojson('-1','参数缺失！');
        }
        $save['avatarUrl'] = $this->_request('avatarUrl') ? $this->_request('avatarUrl') : $this->url."statics/images/header.png";
        $save['username'] = preg_replace('/[\xf0-\xf7].{3}/', '', $this->_request('nickname'));
        $save['sex'] = $this->_request('sex');
        $save['cityname'] = $this->_request('city');

        M('user')->where("id = ".$user_id)->save($save);
        $this->_tojson('1','success',1);
    }
	
	//上传图片
	public function tpupload_file(){
        $file_imgs = array();
        $file_imgs['name'][] = $_FILES['file']['name'];
        $file_imgs['type'][] = $_FILES['file']['type'];
        $file_imgs['tmp_name'][] = $_FILES['file']['tmp_name'];
        $file_imgs['error'][] = $_FILES['file']['error'];
        $file_imgs['size'][] = $_FILES['file']['size'];

        $date_dir = date('ym/d/'); //上传目录
        $result = $this->_upload($file_imgs, 'data/upload/item_sq/'.$date_dir, array(
            'width'=>800,350,
            'height'=>800,350,
            'suffix' => '_b,_s',
        ));
        
        foreach( $result['info'] as $key=>$val ){
            $item_imgs[] = array(
                'url'    => 'data/upload/item_sq/'.$date_dir . $val['savename'],
            );
        }
        $img = $item_imgs[0]['url'];//图片路径
        echo $img;
	}
	
	//获得上传图片类型，JPG.PNG。。
	public function getExtName($namexx){
		$arr=pathinfo($namexx);
		$ext=$arr["extension"];
		return $ext;
	}
	
	//根据日期加密方式来给图片命名
	public function getnewName(){
		$newName=date("YmdHis");
		return $newName;
	}
}