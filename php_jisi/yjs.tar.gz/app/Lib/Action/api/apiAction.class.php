<?php

/**

 * BP项目接口文件

 */

class apiAction extends Action

{

	
	public $url = 'https://bp.iqweb.net/';

    public function _initialize() {



    }
	
	
	
	public function login(){
		if(empty($_POST)){
            $this->_tojson('-1','非法请求');
        }

        $param = array(
            'appid' => 'wx125db524eb3601a6',
            'secret' => '135b8efde526dce270309f36244eaa97',
            'js_code'=> $_POST['code'],
            'grant_type'=>'authorization_code'
        );

        $url = 'https://api.weixin.qq.com/sns/jscode2session?'.http_build_query($param);
        $resoult = file_get_contents($url);
        $res = json_decode($resoult,true);
        if(isset($res['errcode']) || empty($res['openid'])){
            tojson('-3','openID获取失败');
        }

        $useradd['openid'] = $res['openid'];
        $useradd['avatarUrl'] = $_POST['avatarUrl'] ? $_POST['avatarUrl'] : $this->url."statics/images/header.png";
        $useradd['country'] = $_POST['country'] ? $_POST['country'] : '';
        $useradd['nickName'] = preg_replace('/[\xf0-\xf7].{3}/', '', $_POST['nickName']);
        $useradd['username'] = preg_replace('/[\xf0-\xf7].{3}/', '', $_POST['nickName']);
		$useradd['reg_time'] = time();
		
		
		tojson('1','success',$res['openid']);
	}
	
	
	/**
	*	登录
	*/
	public function user_login(){
		//print_r($_POST);
		$user = M("user");
		$phone = intval($_POST['phone']);
		$yqm = $_POST['yqm'];
		$code = $_POST['code'];
		$result = $user->where("phone = '$phone'")->field('id,phone,username,user_type,tj_phone')->find();
		
		if($yqm){
			$ycou = $user->where("phone = '$yqm'")->count("id");
		}
		if(empty($ycou)){
			tojson("-1","邀请人不存在");
		}
		
		if($result['phone']){
			
			if($result['tj_phone'] != $yqm){
				tojson("-1","账号或邀请人手机号不正确");
			}
			$openid = $_GET['code'];
			$isreg = $user->where("openid = '$openid'")->count("id");
			if($isreg){
				tojson("1","success",$result);
			}else{
				$save['openid'] = $openid;
				$save['avatarUrl'] = $_POST['avatarUrl'];
				$user->where("id = ".$result['id'])->save($save);	
				tojson("1","success",$result);
			}
		}else{
			$add['openid'] = $_GET['code'];
			$add['phone'] = $_POST['phone'];
			$add['avatarUrl'] = $_POST['avatarUrl'];
			$add['username'] = $_POST['nickName'];
			$add['user_type'] = 1;
			$add['tj_phone'] = $yqm;
			$add['reg_time'] = time();
			$insert = $user->add($add);	
			file_put_contents("a_reg.txt",M("user")->getlastsql(),FILE_APPEND);
			if(!$insert){
				tojson("-1","登录失败");
			}
			$retu['id'] = $insert;
			$retu['username'] = $add['username'];
			$retu['user_type'] = 1;
			tojson("1","success",$retu);
		}
	}
	
	/**
	*	获取项目行业,红包金额
	*/
	public function industry_list(){
		$arr['indu_list'] = M("industry")->where("status = 1")->field("id,name")->select();
		$otherModel = M("other_set");
		$arr['hb_price'] = $otherModel->where("id = 19")->getField("name");//红包金额
		$arr['sm_price'] = $otherModel->where("id = 21")->getField("name");//私密金额
		tojson("1","success",$arr);
	}
	
	/**
	*	提交项目
	*/
	public function moments_add(){
		$user_id = $this->is_login();	
		$checked = $_POST['checked'];
		if($checked == 'true'){
			$issm = 1;
		}else{
			$issm = 0;
		}
		
		$uinfo = M("user")->where("id = ".$user_id)->find();
		$add['user_id'] = $user_id;	
		$add['order_sn'] = date('ymd').mt_rand(10000000,99999999);
		$add['type_name'] = strim($_POST['sta_name']);//行业名称
		$add['type_id'] = intval($_POST['type_id']);//行业id
		$add['title'] = strim($_POST['title_input']);//项目名称
		$add['inaword'] = strim($_POST['ygh_input']);//一句话总结
		$add['contents'] = strim($_POST['text_info']);//描述
		$add['hb_num'] = intval($_POST['hb_num']);//红包数量
		$add['money'] = intval($_POST['money']);//红包价格
		$add['hb_private'] = $issm;//是否私密
		$add['tp_img'] = $_POST['str_tp'];//项目图片
		$add['add_time'] = time();

		//是否用余额抵扣
		$retu['is_wxpay'] = 1;
		if($_POST['is_amount']){
			//用余额抵扣  如果余额足够
			if($uinfo['money'] >= $add['money']){
				$add['amount'] = $add['money'];
				$add['pay_money'] = 0 ;
				$add['pay_status'] = 1;
				$add['pay_time'] = time();
				$retu['is_wxpay'] = 0;
				M("user")->where("id = ".$user_id)->setDec("money",$add['money']);
				
				//写日志
				$ldata['uid'] = $user_id;
				$ldata['mname'] = "创业者发红包";	
				$ldata['uname'] = $uinfo['phone'];
				$ldata['action'] = "sysman";
				$ldata['score'] = -$add['money'];
				$ldata['add_time'] = time();
				$ldata['balance'] = $uinfo['money'] - $add['money'];
				$ldata['content'] = $add['type_name']."问项发红包".$add['money']."元";
				M("balance_log")->add($ldata);
				
			}else if($uinfo['money'] > 0 && $uinfo['money'] < $add['money']){//如果余额不足够
				$add['amount'] = $uinfo['money'];
				$add['pay_money'] = $add['money'] - $uinfo['money'];	
			}else{//如果没有余额
				$add['pay_money'] = $add['money'];	
			}
		}else{
			$add['pay_money'] = $add['money'];	
		}
		$yes = M("item")->add($add);
		
		//获得可以看到此项目的随机5个用户
		$itemcan = M("item_can");
		$sjarr = M("user")->query("select id from iqw_user where type_id like '%".$add['type_id']."%' order by rand() limit 5");
		
		foreach($sjarr as $k=>$v){
			$can['user_id'] = $v['id'];
			$can['item_id'] = $yes;
			$itemcan->add($can);
		}
		
		$retu['oid'] = $yes;
		if($yes){
			tojson("1","success",$retu);
		}else{
			tojson("-1","提交失败");	
		}
	}
		
	/**
     * 微信支付
     *
     **/
    public function wxpay(){
		$user_id = $this->is_login();
		$code = $_GET['code'];
		include_once EXTEND_PATH."WechatAppPay.php";
		include_once EXTEND_PATH."wxPay/WxPay.Api.php";
		$order = M('item')->where('id = '.$_GET['oid'])->find();
		if(!$order) tojson('-1','订单不存在,已支付或已取消');
		
		$bname = 'BP支付';	
		$notify_url = $this->url.'notify_wx.php';
		//$notify_url = 'https://yz.iqweb.net/index.php?g=admin&m=notify&a=notfun';
		
		$input = new \WxPayDataBase();
		$total_fee = $order['pay_money']*100;
		
		$body = mb_substr($bname,0,32,"UTF-8");
		
		$input->setData('notify_url',$notify_url);
		
		$input->setData('body',$body); //长度128
		
		$input->setData('out_trade_no',$order['order_sn']);
		
		$input->setData('total_fee',$total_fee);
		
		$input->setData('openid',$code);
		
		$wxData = \WxPayApi::unifiedOrder($input);
		
		if($wxData['return_code']=='FAIL' || !$wxData['prepay_id']) $this->_tojson('-200','fail',$wxData);
		
		unset($input);
		
		$jsPay = new \wxJsPay();
		
		$timeStamp = time();
		
		$jsPay->setData('timeStamp',"$timeStamp");
		
		$jsPay->setData('package',"prepay_id=".$wxData['prepay_id']);
		
		$jsPay->setData('signType','MD5');
		
		$jsPay->SetAppId();
		
		$jsPay->SetNonce_str();
		
		$jsPay->SetSign();
		
		tojson('1','success',$jsPay->GetValues());
		
    }
	
	/**
	*	问卷记录
	*/
	public function wj_log(){
		$user_id = $this->is_login();	
		$item_list = M("item")->where("user_id = ".$user_id." and status = 1 and pay_status = 1")->order("id desc")->select();
		foreach($item_list as $k=>$v){
			$item_list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);	
		}
		tojson("1","success",$item_list);
	}
	
	/**
	*	问卷详情
	*/
	public function item_info(){
		$user_id = $this->is_login();
		$item_id = $_GET['item_id'];
		$item_list = M("item")->where("id = ".$item_id)->find();
		$img = explode(",",$item_list['tp_img']);
		foreach($img as $k=>$v){
			$item_list["img"][$k] = $this->url.$v;	
		}
		
		$item_sub = M("item_sub");
		$pj_list = $item_sub->where("item_id = ".$item_list['id'])->select();
		$user = M("user");
		foreach($pj_list as $k=>$v){
			$uinfo = $user->where("id = ".$v['user_id'])->find();
			$pj_arr[$k]['tx_img'] = $uinfo['avatarUrl'];//头像
			$pj_arr[$k]['username'] = $uinfo['username'];//名称
			$pj_arr[$k]['address'] = $uinfo['address'];//地址
			$pj_arr[$k]['con_name'] = $uinfo['con_name'];//机构名称
			$pj_arr[$k]['is_love'] = $v['is_love'];//兴趣
			$pj_arr[$k]['commtent'] = $v['commtent'];//建议
			$pj_arr[$k]['item_id'] = $v['id'];
		}
		
		$itemwt = M("item_wt");
		$wtcou = $itemwt->where("item_id = ".$item_id)->count("id");
		//如果项目有评论了。就调取存表的问题
		if($wtcou){
			$wt_list = $itemwt->where("item_id = ".$item_id." and pid = 0")->field("wt_id,wt_name as name")->select();
			foreach($wt_list as $k=>$v){
				$wt_list[$k]['ptype'] = $itemwt->where("pid = ".$v['wt_id']." and item_id = ".$item_id)->field("wt_id as id,wt_name as name")->select();
				foreach($wt_list[$k]['ptype'] as $key=>$val){
					$map['wt_str'] = array("LIKE","%".$val['id']."%");
					$map['item_id'] = $item_id;
					$cou += $item_sub->where($map)->count("id");
				}
				foreach($wt_list[$k]['ptype'] as $a=>$b){
					$map['wt_str'] = array("LIKE","%".$b['id']."%");
					$wt_cou = $item_sub->where($map)->count("id");
					$wt_list[$k]['ptype'][$a]['bl'] =  $this->number(intval($wt_cou/$cou * 100));
					$wt_list[$k]['ptype'][$a]['bl_cou'] = $wt_cou ? $wt_cou : 0;
				}
				$cou = '';
			}
		}else{
			$other = M("other_set");
			$wt_list = $other->where("pid = 22")->field("id,name")->select();
			foreach($wt_list as $k=>$v){
				$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
				foreach($wt_list[$k]['ptype'] as $val){
					$map['wt_str'] = array("LIKE","%".$val['id']."%");
					$map['item_id'] = $item_id;
					$cou += $item_sub->where($map)->count("id");
				}
				foreach($wt_list[$k]['ptype'] as $a=>$b){
					$map['wt_str'] = array("LIKE","%".$b['id']."%");
					$wt_cou = $item_sub->where($map)->count("id");
					$wt_list[$k]['ptype'][$a]['bl'] =  $this->number(intval($wt_cou/$cou * 100));
					$wt_list[$k]['ptype'][$a]['bl_cou'] = $wt_cou ? $wt_cou : 0;
				}
				$cou = '';
			}
		}
		$retu['item_list'] = $item_list;
		$retu['pj_arr'] = $pj_arr;
		$retu['wt_list'] = $wt_list;
		
		tojson("1","success",$retu);
	}
	
	
	/**
	*	投资者问卷列表
	*/
	public function throw_list(){
		$user_id = $this->is_login();
		$user_type = M("user")->where("id = ".$user_id)->field("money,type_id")->find();//会员类型
		//查找和投资者匹配的项目
		
		$itemarr = M("item_can")->where(array("user_id"=>$user_id))->getField("item_id",true);
		$map['id'] = array("in",$itemarr);
		$map['status']= 1;
		$map['pay_status'] = 1;
		$list = M("item")->where($map)->order("id desc")->select();	
		
		$item_sub = M("item_sub");
		foreach($list as $k=>$v){
			$list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);
			$list[$k]['is_lq'] = $item_sub->where("item_id = ".$v['id']." and user_id = ".$user_id)->count("id");
		}
		$retu['list'] = $list;
		$retu['money'] = $user_type['money'];
		tojson("1","success",$retu);
	}
	
	/**
	*	创业者问卷详情
	*/
	public function questionnaire(){
		$user_id = $this->is_login();
		$map['id'] = $_GET['item_id'];
		$iteminfo = M("item")->where($map)->find();
		$iteminfo['add_time'] = date("Y-m-d H:i:s",$iteminfo['add_time']);
		$img = explode(",",$iteminfo['tp_img']);
		foreach($img as $k=>$v){
			$iteminfo["img"][$k] = $this->url.$v;	
		}
		
		$other = M("other_set");
		$wt_list = $other->where("pid = 22")->field("id,name")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
		}
		$retu['iteminfo'] = $iteminfo;
		$retu['wt_list'] = $wt_list;
		tojson("1","success",$retu);
	}
	
	/**
	*	自己评论详情
	*/
	public function uitem(){
		$user_id = $this->is_login();
		$item_id = $_GET['item_id'];
		$uinfo = M("item_sub")->where("user_id = ".$user_id." and item_id = ".$item_id)->find();
		
		$wtmodel = M("item_wt");
		$wtarr = explode(",",$uinfo['wt_str']);
		$wt_list = $wtmodel->where("item_id = ".$item_id." and pid = 0")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $wtmodel->where("pid = ".$v['wt_id']." and item_id = ".$item_id)->field("wt_id,wt_name")->select();
			foreach($wt_list[$k]['ptype'] as $key=>$val){
				if(in_array($val['wt_id'],$wtarr)){
					$wt_list[$k]['ptype'][$key]['is_status'] = 1;
				}
			}
		}
		
		$pj_list = M("item_sub")->where("item_id = ".$item_id)->select();
		$user = M("user");
		foreach($pj_list as $k=>$v){
			$userinfo = $user->where("id = ".$v['user_id'])->find();
			$pj_arr[$k]['tx_img'] = $userinfo['avatarUrl'];//头像
			$pj_arr[$k]['username'] = $userinfo['username'];//名称
			$pj_arr[$k]['address'] = $userinfo['address'];//地址
			$pj_arr[$k]['con_name'] = $userinfo['con_name'];//机构名称
			$pj_arr[$k]['is_love'] = $v['is_love'];//兴趣
			$pj_arr[$k]['commtent'] = $v['commtent'];//建议
			$pj_arr[$k]['item_id'] = $v['id'];
		}
		
		$retu['pj_arr'] = $pj_arr;
		$retu['wtlist'] = $wt_list;
		$retu['uinfo'] = $uinfo;
		tojson("1","success",$retu);
	}
	
	
		
	/**
	*	投资者评论详情
	*/
	public function details_item(){
		$item_id = $_GET['tzid'];
		$info = M("item_sub")->where("id = ".$item_id)->find();
		
		$uinfo = M("user")->where("id = ".$info['user_id'])->find();
		$info['tx_img'] = $uinfo['avatarUrl'];//头像
		$info['username'] = $uinfo['username'];//名称
		$info['address'] = $uinfo['address'];//地址
		$info['con_name'] = $uinfo['con_name'];//机构名称
		
		$wtarr = explode(",",$info['wt_str']);
		$other = M("other_set");
		$wt_list = $other->where("pid = 22")->field("id,name")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
			foreach($wt_list[$k]['ptype'] as $key=>$val){
				if(in_array($val['id'],$wtarr)){
					$wt_list[$k]['ptype'][$key]['is_status'] = 1;
				}
			}
		}
		$retu['info'] = $info;
		$retu['wt_list'] = $wt_list;
		tojson("1","success",$retu);
	}
	
	
	/**
	*	投资者评论
	*/
	public function item_comments(){
		$add['user_id'] = $this->is_login();
		
		$item = M("item")->where("id = ".$_GET['item_id'])->find();
		
		if($item['yl_num']+1 > $item['hb_num']){
			tojson("-1","红包已领完");
		}
		$wtstr = $_GET['str'];
		$money = 20;//$this->number($item['money'] / $item['hb_num']);
		$add['item_id'] = intval($_GET['item_id']);
		$add['is_love'] = $_GET['is_love'];
		$add['commtent'] = $_GET['text_info'];
		$add['wt_str'] = $wtstr;
		$add['money'] = $money;
		$add['add_time'] = time();
		
		$wtarr = explode(",",$wtstr);
		$other = M("other_set");
		
		//问题保留。一二级另外存表		
		$sjid = $other->where("id = ".$wtarr[0])->getField("pid");
		$yjid = $other->where("id = ".$sjid)->getField("pid");
		
		//所有一级问题
		$yjarr = $other->where("pid = ".$yjid)->select();
		$item_wt = M("item_wt");
		
		$wt_cou = $item_wt->where("item_id = ".$item['id'])->count("id");
		if(empty($wt_cou)){
			foreach($yjarr as $k=>$v){
				$wtadd['item_id'] = $item['id'];
				$wtadd['wt_id'] = $v['id'];
				$wtadd['wt_name'] = $v['name'];
				$yes = $item_wt->add($wtadd);
				if($yes){
					//添加二级问题
					$ejarr = $other->where("pid = ".$v['id'])->select();
					foreach($ejarr as $a=>$b){
						$wtadd['wt_id'] = $b['id'];
						$wtadd['wt_name'] = $b['name'];
						$wtadd['pid'] = $v['id'];
						$item_wt->add($wtadd);
					}
				}
				$wtadd = array();
			}
		}
		
		$yes = M("item_sub")->add($add);
		if($yes){
			M("item")->where("id = ".$item['id'])->setInc("yl_num",1);
			M("user")->where("id = ".$add['user_id'])->setInc("money",$money);
			
			$uinfo = M("user")->where("id = ".$add['user_id'])->find();
			//写日志
			$ldata['uid'] = $uinfo['id'];
			$ldata['mname'] = "投资者领红包";	
			$ldata['uname'] = $uinfo['phone'];
			$ldata['action'] = "sysman";
			$ldata['score'] = $money;
			$ldata['add_time'] = time();
			$ldata['balance'] = $uinfo['money'] + $money;
			$ldata['content'] = $item['type_name']."问项领红包".$money."元";
			M("balance_log")->add($ldata);
			
			$retu['item_name'] = $item['title'];
			$retu['money'] = $money;
			tojson("1","success",$retu);
		}else{
			tojson("-1","提交失败");	
		}	
	}
	
	
	
	//上传图片
	public function tpupload_file(){
		//取得上传文件信息
		$fileName = $_FILES['file']['name'];
		$fileType = $_FILES['file']['type'];
		$fileError = $_FILES['file']['error'];
		$fileSize = $_FILES['file']['size'];
		$tempName = $_FILES['file']['tmp_name'];//临时文件名
		
		//定义上传文件类型
		$typeList = array("image/jpeg","image/jpg","image/png","image/gif"); //定义允许的类型
		
		if($fileError>0){
			//上传文件错误编号判断
			switch ($fileError) {
				case 1:
					$message="上传的文件超过了php.ini 中 upload_max_filesize 选项限制的值。"; 
					break;
				case 2:
					$message="上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值。"; 
					break;
				case 3:
					$message="文件只有部分被上传。"; 
					break;
				case 4:
					$message="没有文件被上传。";
					break;
				case 6:
					$message="找不到临时文件夹。"; 
					break;
				case 7:
					$message="文件写入失败"; 
					break;
				case 8:
					$message="由于PHP的扩展程序中断了文件上传";
					break;
			}
		
			exit("文件上传失败：".$message);
		
		}
		if(!is_uploaded_file($tempName)){
			//判断是否是POST上传过来的文件
			exit("不是通过HTTP POST方式上传上来的");
		}else{
			if(!in_array($fileType, $typeList)){
				exit("上传的文件不是指定类型");
			}else{
				if(!getimagesize($tempName)){
					//避免用户上传恶意文件,如把病毒文件扩展名改为图片格式
					exit("上传的文件不是图片");
				}
			}
			if($fileSize>1000000){
				//对特定表单的上传文件限制大小
				exit("上传文件超出限制大小");
			}else{
				//避免上传文件的中文名乱码
				$fileName=iconv("UTF-8", "GBK", $fileName);//把iconv抓取到的字符编码从utf-8转为gbk输出
				$fileName=str_replace(".", time().".", $fileName);//在图片名称后加入时间戳，避免重名文件覆盖
				
				$ext = $this->getExtName($fileName);//获取后缀名
				$newName = $this->getnewName();//生成文件名
				
				$sjs = rand(1000,9999);//避免多图上传文件同名
				$filepath = "data/upload/item/".$newName.$sjs.".".$ext;
				
				if(move_uploaded_file($tempName, $filepath)){
					$file_name = $filepath;
				}
			}
		}
		echo $file_name;exit;
		
	}
	
	//获得上传图片类型，JPG.PNG。。
	public function getExtName($namexx){
		$arr=pathinfo($namexx);
		$ext=$arr["extension"];
		return $ext;
	}
	
	//根据日期加密方式来给图片命名
	public function getnewName(){
		$newName=date("YmdHis");
		return $newName;
	}
	
	
	
	protected function number($k){
		$arr = explode(".",$k);
		$a = substr($arr[1],0,2);
		$number = empty($a) ? '00' :  $a;
		$ok = $arr[0].'.'.$number;
		return $ok;
	}
	
	/**
	*	获取用户余额
	*/
	public function user_money(){
		$user_id = $this->is_login();	
		$money = M("user")->where("id = ".$user_id)->getField("money");
		tojson("1","success",$money);
	}	
	
	/**
	*	检查是否登录
	*/
	public function is_login(){
		$user_id = $_GET['user_id'];
		$user_id = M('user')->where("id = '".$user_id."'")->getField('id');
		if($user_id){
			 return $user_id;
	    }else{
			tojson('-1','请先登录');
		}
	}
	

}