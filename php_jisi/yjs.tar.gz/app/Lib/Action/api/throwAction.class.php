<?php

/**

 * BP项目接口文件

 */

class throwAction extends apibaseAction{

    public function _initialize() {
		parent::_initialize();
    }
	
	
	
	/**
	*	投资者问卷列表
	*/
	public function throw_list(){
		$user_id = $this->is_login();
		$user_type = M("user")->where("id = ".$user_id)->field("money,type_id")->find();//会员类型
		//查找和投资者匹配的项目

        //行业下所有可看
        if($user_type['type_id']){
            $is_view = explode(",",$user_type['type_id']);
            foreach($is_view as $k=>$v){
                $where .= $where ? " or type_id like '%".$v."%'" : " type_id like '%".$v."%'";
            }
        }else{
            $where .= " type_id = 0";
        }
        $where .= " and status = 1 and pay_status = 1";
        $list = M()->query("select * from iqw_item where ".$where);

        //echo M()->getLastSql();exit;
        //只能看随机的
//		$itemarr = M("item_can")->where(array("user_id"=>$user_id))->getField("item_id",true);
//		if(empty($itemarr)){
//			$this->_tojson("-1","暂无可看项目");
//		}
//		$map['id'] = array("in",$itemarr);
//		$map['status']= 1;
//		$map['pay_status'] = 1;
//		$list = M("item")->where($map)->order("id desc")->select();
		
		$item_sub = M("item_sub");
		$red = M("item_red");
		foreach($list as $k=>$v){
			$list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);
			$list[$k]['is_lq'] = $item_sub->where("item_id = ".$v['id']." and user_id = ".$user_id)->count("id");
			$list[$k]['red_num'] = $red->where(array('user_id'=>$user_id,'item_id'=>$v['id']))->getField('num');
		}
		$retu['list'] = $list;
		$retu['money'] = $user_type['money'];
		$this->_tojson("1","success",$retu);
	}
	
	/**
	*	创业者问卷详情
	*/
	public function questionnaire(){
		//$user_id = $this->is_login();
		$map['id'] = $_GET['item_id'];
		$iteminfo = M("item")->where($map)->find();
		$iteminfo['add_time'] = date("Y-m-d H:i:s",$iteminfo['add_time']);
		$img = explode(",",$iteminfo['tp_img']);
		foreach($img as $k=>$v){
			$iteminfo["img"][$k] = $this->url.$v;	
		}
		
		$other = M("other_set");
		$wt_list = $other->where("pid = 22")->field("id,name")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $other->where("pid = ".$v['id'])->field("id,name")->select();
		}
		
		
		//清除红点
		M('item_red')->where(array('user_id'=>$user_id,'item_id'=>$map['id']))->save(array('num'=>0));
		
		$retu['iteminfo'] = $iteminfo;
		$retu['wt_list'] = $wt_list;

        //添加查看的项目  并且不是自己发布的
        if($_GET['user_id']){
            $cou = M("item_seen")->where(array('user_id'=>$_GET['user_id'],'item_id'=>$map['id']))->count('id');
            if(empty($cou) && $iteminfo['user_id'] != $_GET['user_id']) {
                $add['user_id'] = $_GET['user_id'];
                $add['item_id'] = $map['id'];
                $add['add_time'] = time();
                M("item_seen")->add($add);
            }
        }



        $this->_tojson("1","success",$retu);
	}
	
	
	
	
	/**
	*	投资者评论
	*/
	public function item_comments(){
		$add['user_id'] = $this->is_login();

		$uinfo = M('user')->where(array('id'=>$add['user_id']))->find();
		if($uinfo['user_type'] != 2){
            $this->_tojson("-1","投资者才可领取");
        }


		$item = M("item")->where("id = ".$_GET['item_id'])->find();
		
		$is_yl = M("item_sub")->where(array('user_id'=>$add['user_id'],'item_id'=>$_GET['item_id']))->count('id');
		if($is_yl){
		    $this->_tojson("-1","已领过红包了");
        }
		if($item['yl_num']+1 > $item['hb_num']){
			$out_hb = 1;
            $money = 0;
		}else{
            $money = 20;//$this->number($item['money'] / $item['hb_num']);
        }
		$wtstr = $_GET['str'];
		$add['item_id'] = intval($_GET['item_id']);
		$add['is_love'] = $_GET['is_love'];
		$add['commtent'] = $_GET['text_info'];
		$add['wt_str'] = $wtstr ? $wtstr : '';
		$add['money'] = $money;
		$add['add_time'] = time();
		
		$wtarr = explode(",",$wtstr);
		$other = M("other_set");
		
		/*//问题保留。一二级另外存表		
		$sjid = $other->where("id = ".$wtarr[0])->getField("pid");
		$yjid = $other->where("id = ".$sjid)->getField("pid");
		
		//所有一级问题
		$yjarr = $other->where("pid = ".$yjid)->select();
		$item_wt = M("item_wt");
		
		$wt_cou = $item_wt->where("item_id = ".$item['id'])->count("id");
		if(empty($wt_cou)){
			foreach($yjarr as $k=>$v){
				$wtadd['item_id'] = $item['id'];
				$wtadd['wt_id'] = $v['id'];
				$wtadd['wt_name'] = $v['name'];
				$yes = $item_wt->add($wtadd);
				if($yes){
					//添加二级问题
					$ejarr = $other->where("pid = ".$v['id'])->select();
					foreach($ejarr as $a=>$b){
						$wtadd['wt_id'] = $b['id'];
						$wtadd['wt_name'] = $b['name'];
						$wtadd['pid'] = $v['id'];
						$item_wt->add($wtadd);
					}
				}
				$wtadd = array();
			}
		}*/
		
		$yes = M("item_sub")->add($add);


		//如果红包没领完
		if($out_hb != 1){
			M("item")->where("id = ".$item['id'])->setInc("yl_num",1);
			M("user")->where("id = ".$add['user_id'])->setInc("money",$money);
			
			$uinfo = M("user")->where("id = ".$add['user_id'])->find();
			//写日志
			$ldata['uid'] = $uinfo['id'];
			$ldata['mname'] = "投资者领红包";	
			$ldata['uname'] = $uinfo['phone'];
			$ldata['action'] = "sysman";
			$ldata['score'] = $money;
			$ldata['add_time'] = time();
			$ldata['balance'] = $uinfo['money'] + $money;
			$ldata['content'] = $item['type_name']."问项领红包".$money."元";
			M("balance_log")->add($ldata);
		}
		
		//添加评论
		$pl_add['item_id'] = $add['item_id'];
		$pl_add['user_id'] = $add['user_id'];
		$pl_add['content'] = $add['commtent'];
		$pl_add['add_time'] = time();
		$pl_add['is_love'] = $_GET['is_love'];
		M("item_pl")->add($pl_add);
		
		$item_red = M('item_red');
		$item_red->where(array('item_id'=>$add['item_id']))->setInc('num');//添加红点数量
		$red_cou = $item_red->where(array('item_id'=>$add['item_id'],'user_id'=>$add['user_id']))->count('id');//检查有没红点记录
		if(empty($red_cou)){
			$red_add = array(
						'item_id'=>$add['item_id'],
						'user_id'=>$add['user_id']
					   );
			$item_red->add($red_add);//添加红点记录
		}
		
		/*//其他问题
		$wt_json = json_decode($_GET['wt_json'],true);
		if($wt_json){
			$wt_add['sub_id'] = $yes;
			$wt_add['item_id'] = $add['item_id'];
			$other = M("item_other");
			foreach($wt_json as $k=>$v){
				$wt_add['wt_id'] = substr($k,3);
				$wt_add['content'] = $v;
				$wt_add['add_time'] = time();
				$other->add($wt_add);
			}
		}*/
		
		if($yes){
            $itemInfo = M("item")->where(array("id"=>$_GET['item_id']))->find();
            $title = $item['title'];//评论主题
            $content = msubstr($pl_add['content'],0,20);//评论内容
            $mbid = "Ysg35hIdpj5xyMfERZ7aD0kE57mTzE1Ucn3csL3qI2E";//模板id
            $plInfo = M("user")->where(array("id"=>$add['user_id']))->find();
            $userName = $plInfo['the_user']."(".$plInfo['con_name'].")";//评论者

            $openid = M("user")->where(array("id"=>$item['user_id']))->getField("openid");//获取openid
            $url = "pages/asked-detail/asked-detail?item_id=".$add['item_id'];//跳转路径  创业者路径
            if($openid){
                $this->sendtpl($openid,$mbid,$title,$content,$userName,$url);
            }

            //添加可看项目
            $is_cou = M("item_can")->where(array('item_id'=>$_GET['item_id'],"user_id"=>$add['user_id']))->count("id");
            if(empty($is_cou)){
                $canAdd['item_id'] = $_GET['item_id'];
                $canAdd['user_id'] = $add['user_id'];
                M('item_can')->add($canAdd);
            }

			$retu['item_name'] = $item['title'];
			$retu['money'] = $money;
			$this->_tojson("1","success",$retu);
		}else{
			$this->_tojson("-1","提交失败");	
		}	
	}
	
	
	/**
	*	自己评论详情
	*/
	public function uitem(){
		$user_id = $this->is_login();
		$item_id = $_GET['item_id'];
		$uinfo = M("item_sub")->where("user_id = ".$user_id." and item_id = ".$item_id)->find();
		
		$wtmodel = M("item_wt");
		$other = M("item_other");
		$wtarr = explode(",",$uinfo['wt_str']);
		$wt_list = $wtmodel->where("item_id = ".$item_id." and pid = 0")->select();
		foreach($wt_list as $k=>$v){
			$wt_list[$k]['ptype'] = $wtmodel->where("pid = ".$v['wt_id']." and item_id = ".$item_id)->field("wt_id,wt_name")->select();
			foreach($wt_list[$k]['ptype'] as $key=>$val){
				if(in_array($val['wt_id'],$wtarr)){
					$wt_list[$k]['ptype'][$key]['is_status'] = 1;
				}
			}
			
			$wtinfo = $other->where(array("item_id"=>$item_id,"user_id"=>$user_id,"wt_id"=>$v['wt_id']))->find();
			if($wtinfo){
				$wt_list[$k]['other'] = $wtinfo['content'];
			}
		}
		
		$pj_list = M("item_sub")->where("item_id = ".$item_id)->select();
		$user = M("user");
		foreach($pj_list as $k=>$v){
			$userinfo = $user->where("id = ".$v['user_id'])->find();
			$pj_arr[$k]['tx_img'] = $userinfo['avatarUrl'];//头像
			$pj_arr[$k]['username'] = $userinfo['username'];//名称
			$pj_arr[$k]['address'] = $userinfo['address'];//地址
			$pj_arr[$k]['con_name'] = $userinfo['con_name'];//机构名称
			$pj_arr[$k]['is_love'] = $v['is_love'];//兴趣
			$pj_arr[$k]['commtent'] = $v['commtent'];//建议
			$pj_arr[$k]['item_id'] = $v['id'];
		}
		
		$retu['pj_arr'] = $pj_arr;
		$retu['wtlist'] = $wt_list;
		$retu['uinfo'] = $uinfo;
		$this->_tojson("1","success",$retu);
	}
	
	
	//评论详情
	public function pl_item(){
		$item_id = $_GET['item_id'];
		$item_pl = M("item_pl");
		
		//所有评论
		$list = $item_pl->where(array("item_id"=>$item_id))->select();
		$user = M("user");
		foreach($list as $k=>$v){
			$list[$k]['username'] = $user->where(array("id"=>$v['user_id']))->getField("the_user");
			if($v['parent_id']){
				$pid = $item_pl->where(array("id"=>$v['parent_id']))->find();
				$ppl = $user->where(array("id"=>$pid['user_id']))->getField("the_user");
				if($ppl){
					$list[$k]['reply_name'] .= " 回复 ".$ppl;
				}
			}
			if($v['is_love'] == 1){
				$kh_arr[$k]['username'] = $list[$k]['username'];
			}
		}
		$retu['lists'] = $list;
		$retu['kh_arr'] = $kh_arr;
		$this->_tojson("1","success",$retu);
	}


    //评论详情--不可看全部
    public function pl_item_sub(){
        $item_id = $_GET['item_id'];
        $item_pl = M("item_pl");

        //所有评论
        $list = $item_pl->where(array("item_id"=>$item_id))->select();
        $user = M("user");
        foreach($list as $k=>$v){
            $list[$k]['username'] = $user->where(array("id"=>$v['user_id']))->getField("the_user");
            if($v['parent_id']){
                $pid = $item_pl->where(array("id"=>$v['parent_id']))->find();
                $ppl = $user->where(array("id"=>$pid['user_id']))->getField("the_user");
                if($ppl){
                    $list[$k]['reply_name'] .= " 回复 ".$ppl;
                }
            }
            if($v['is_love'] == 1){
                $kh_arr[$k]['username'] = $list[$k]['username'];
            }
            $list[$k]['content'] = msubstr($v['content'],0,15);//substr($v['content'],0,15);
        }
        $retu['lists'] = $list;
        $retu['kh_arr'] = $kh_arr;
        $this->_tojson("1","success",$retu);
    }
	
	
	
	
	
}