<?php

/**

 * 云祭祀项目接口文件

 */

class indexAction extends apibaseAction
{


    public function _initialize()
    {
        parent::_initialize();
    }


    //首页幻灯
    public function home_banner()
    {
        $list = M("ad")->where(array("status" => 1))->field("content")->select();
        foreach ($list as $k => $v) {
            $list[$k]['imgurl'] = $this->url . "image/" . $v['content'];
        }
        $this->_tojson("1", "success", $list);
    }

    /**
     * 首页祭祀列表
     */
    public function jsg_list()
    {
        $jisiguan = M('jisiguan')
            ->alias('g')
            ->where('g.status=1')
            ->join('iqw_jisiguan_list as l on g.id = l.g_id')
            ->join('iqw_user as u on g.user_id = u.id')
            ->field('g.*,u.username,sum(l.lazhu) lazhu,sum(l.zhiqian) zhiqian,sum(l.shangxiang) shangxiang,sum(l.xianhua) xianhua')
            ->group('g.id')
            ->order('g.ordid desc,g.id desc')
            ->select();
        if ($jisiguan) {
            $data = array();
            $coll = M('jisiguan_coll');
            foreach ($jisiguan as $k => $v) {
                $coll_cou = $coll->where(array('g_id' => $v['id']))->count('id');
                $data[$k] = array(
                    'id' => $v['id'],
                    'user_id' => $v['user_id'],
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'add_time' => $v['add_time'],
                    'lazhu' => $v['lazhu'] ? $v['lazhu'] : 0,
                    'zhiqian' => $v['zhiqian'] ? $v['zhiqian'] : 0,
                    'shangxiang' => $v['shangxiang'] ? $v['shangxiang'] : 0,
                    'xianhua' => $v['xianhua'] ? $v['xianhua'] : 0,
                    'img_url' => $v['img_url'] ? $this->url . $v['img_url'] : $this->url . 'data/upload/a.jpg',
                    'username' => $v['username'],
                    'is_open' => $v['is_open'],
                    'code' => $v['code'],
                    'coll_cou' => $coll_cou
                );
            }
            $this->_tojson('1', 'success', $data);
        } else {
            $this->_tojson('-1', '暂无信息');
        }
    }


    /**
     * 列表
     */
    public function js_list()
    {
        $g_id = $this->_request('g_id');
        $code = $this->_request('code');
        if (empty($g_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $js_list = M('jisiguan_list')
            ->alias('l')
            ->where('g_id=' . $g_id)
            ->join('iqw_jisiguan_list_img i on l.id = i.list_id')
            ->field('l.*,i.img_url')
            ->group('l.id')
            ->order('ordid desc,id desc')
            ->select();

        if ($js_list) {
            $data = array();
            foreach ($js_list as $k => $v) {
                $data[$k] = array(
                    'id' => $v['id'],
                    'user_id' => $v['user_id'],
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'add_time' => $v['add_time'],
                    'lazhu' => $v['lazhu'],
                    'zhiqian' => $v['zhiqian'],
                    'shangxiang' => $v['shangxiang'],
                    'xianhua' => $v['xianhua'],
                    'img_url' => $v['img_url'] ? $this->url . $v['img_url'] : $this->url . 'data/upload/a.jpg',
                    'ss_time' => $v['ss_time'],
                    'age' => $v['age']
                );
            }
            $this->_tojson('1', 'success', $data);
        } else {
            $data = array();
            $this->_tojson('1', 'success',$data);
        }
    }

    /**
     * 生平简介
     */
    public function shangping()
    {
        $l_id = $this->_request('l_id');
        if (empty($l_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $info = M('jisiguan_list')->where(array('id' => $l_id))->find();
        if ($info) {
            $img_list = M('jisiguan_list_img')->where(array('list_id' => $l_id))->getField('img_url', true);
            $info['liuyan'] = M('jisiguan_liuyan')->where(array('list_id' => $l_id))->select();
            $img_arr = array();
            foreach ($img_list as $k => $v) {
                if(!empty($v)){
                    $img_arr[$k] = $this->url . $v;//拼接域名地址
                }
            }
            $info['img_arr'] = $img_arr;
            $info['view_img_arr'] = $img_arr;
            $info['tp_img_arr'] = $img_list;
            $this->_tojson('1', 'success', $info);
        } else {
            $this->_tojson('-1', '暂无信息');
        }
    }

    /**
     * 发布留言
     */
    public function liuyan_add()
    {
        $add['list_id'] = $this->_request('list_id');
        $add['user_id'] = $this->_request('user_id');
        $add['status'] = 1;

        $uinfo = M('user')->where(array('id' => $add['user_id']))->find();
        $add['user_name'] = $uinfo['username'];
        $add['user_img'] = $uinfo['avatarUrl'];
        $add['content'] = $this->_request('content');
        $add['add_time'] = time();
        if (empty($add['list_id']) || empty($add['user_id']) || empty($add['content'])) {
            $this->_tojson('-1', '参数缺失！');
        }
        M('jisiguan_liuyan')->add($add);
        $this->_tojson('1', 'success', 1);
    }

    /**
     * 留言列表
     */
    public function liuyan_list()
    {
        $list_id = $this->_request('l_id');
        if (empty($list_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $list = M('jisiguan_liuyan')
            ->alias('l')
            ->where('l.list_id = ' . $list_id . ' and l.status = 1')
            ->join('iqw_user u on l.user_id = u.id')
            ->field('l.*,u.username,u.avatarUrl')
            ->order('l.id desc')
            ->select();
        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date("Y-m-d H:i:s", $v['add_time']);
        }
        $this->_tojson('1', 'success', $list);
    }


    /**
     * 祭祀行为
     */
    public function xw_add()
    {
        $add['list_id'] = $this->_request('l_id');
        $add['user_id'] = $this->_request('user_id');
        $add['xw_type'] = $this->_request('xw_type');
        $add['add_time'] = time();

        if (empty($add['list_id']) || empty($add['user_id']) || empty($add['xw_type'])) {
            $this->_tojson('-1', '参数缺失！');
        }

        $start_time = strtotime(date("Y-m-d"));
        $end_time = strtotime(date("Y-m-d")) + 60 * 60 * 24;
        $map['add_time'][] = array('egt', $start_time);
        $map['add_time'][] = array('elt', $end_time);
        $map['list_id'] = $add['list_id'];
        $map['user_id'] = $add['user_id'];
        $map['xw_type'] = $add['xw_type'];
        $cou = M('jisiguan_xw')->where($map)->count('id');

        switch ($add['xw_type']) {
            case 1:
                $xw = 'lazhu';
                break;
            case 2:
                $xw = 'zhiqian';
                break;
            case 3:
                $xw = 'shangxiang';
                break;
            case 4:
                $xw = 'xianhua';
                break;
        }
        M('jisiguan_list')->where(array('id' => $add['list_id']))->setInc($xw);

        if ($cou >= 3) {
            $this->_tojson('-1', '今日已达上限，试试其他吧');
        }
        M('jisiguan_xw')->add($add);
        $this->_tojson('1', 'success', 1);
    }

    /**
     * 创建馆
     */
    public function guan_add()
    {
        $add['user_id'] = $this->_request('user_id');
        $add['title'] = $this->_request('title');
        $add['content'] = $this->_request('content');
        $add['is_open'] = $this->_request('is_open') ? 1 : 0;
        $add['code'] = $this->_request('code') ? $this->_request('code') : '';
        $add['add_time'] = time();
        $add['img_url'] = $this->_request('img_url') ? $this->_request('img_url') : '';
        $add['status'] = 1;

        if (empty($add['user_id']) || empty($add['title']) || empty($add['content'])) {
            $this->_tojson('-1', '参数缺失！');
        }
        //私有
        if ($add['is_open'] == 1 && empty($add['code'])) {
            $this->_tojson('-1', '私有馆邀请码不可为空！');
        }

        $insert_id = M('jisiguan')->add($add);
        $this->_tojson('1', 'success', $insert_id);
    }

    /**
     * 创建英烈
     */
    public function guan_list_add()
    {
        $add['g_id'] = $this->_request('g_id');
        $add['user_id'] = $this->_request('user_id');
        $add['title'] = $this->_request('title');
        $add['content'] = $this->_request('content');
        $add['cs_time'] = $this->_request('ss_time');
        $add['ss_time'] = $this->_request('ss_time');
        $add['age'] = $this->_request('age');
        $add['sex'] = $this->_request('sex');
        $add['add_time'] = time();
        $add['status'] = 1;
        $img_arr = $this->_request('img_arr');

        if (empty($add['g_id']) || empty($add['user_id']) || empty($add['title']) || empty($add['content'])) {
            $this->_tojson('-1', '参数缺失！');
        }

        $insertId = M('jisiguan_list')->add($add);

        //添加图片
        $imgModel = M('jisiguan_list_img');
        $img_arr = explode(',', $img_arr);
        foreach ($img_arr as $k => $v) {
            $img_add = array();
            $img_add['list_id'] = $insertId;
            $img_add['img_url'] = $v;
            $img_add['add_time'] = time();
            $imgModel->add($img_add);
        }
        $this->_tojson('1', 'success', $insertId);
    }

    /**
     * 添加收藏
     */
    public function guan_coll()
    {
        $add['g_id'] = $this->_request('g_id');
        $add['user_id'] = $this->_request('user_id');
        $add['add_time'] = time();
        if (empty($add['g_id']) || empty($add['user_id'])) {
            $this->_tojson('-1', '参数缺失！');
        }

        M('jisiguan_coll')->add($add);
        $this->_tojson('1', 'success', 1);
    }

    /**
     * 查看是否已收藏
     */
    public function is_coll()
    {
        $user_id = $this->_request('user_id');
        $g_id = $this->_request('g_id');
        if (empty($user_id) || empty($g_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $cou = M('jisiguan_coll')->where(array('g_id' => $g_id, 'user_id' => $user_id))->count('id');

        $this->_tojson('1', 'success', $cou);
    }

    /**
     * 取消收藏
     */
    public function delete_coll()
    {
        $user_id = $this->_request('user_id');
        $g_id = $this->_request('g_id');
        if (empty($user_id) || empty($g_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        M('jisiguan_coll')->where(array('g_id' => $g_id, 'user_id' => $user_id))->delete();
        $this->_tojson('1', 'success', 1);
    }

    /**
     * 我的收藏
     */
    public function guan_coll_list()
    {
        $user_id = $this->_request('user_id');
        if (empty($user_id)) {
            $this->_tojson('-1', '参数缺失！');
        }

        $jisiguan = M('jisiguan_coll')
            ->alias('c')
            ->where('g.status=1 and c.user_id = ' . $user_id)
            ->join('iqw_jisiguan as g on g.id = c.g_id')
            ->join('iqw_jisiguan_list as l on g.id = c.g_id')
            ->join('iqw_user as u on g.user_id = u.id')
            ->field('u.username,g.title,g.img_url,sum(l.lazhu) lazhu,sum(l.zhiqian) zhiqian,sum(l.shangxiang) shangxiang,sum(l.xianhua) xianhua,c.g_id,c.id')
            ->group('g.id')
            ->order('c.id desc')
            ->select();
        if ($jisiguan) {
            $data = array();
            $coll = M('jisiguan_coll');
            foreach ($jisiguan as $k => $v) {
                $coll_cou = $coll->where(array('g_id' => $v['g_id']))->count('id');
                $data[$k] = array(
                    'id' => $v['id'],
                    'g_id' => $v['g_id'],
                    'user_id' => $v['user_id'],
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'img_url' => $v['img_url'] ? $this->url . $v['img_url'] : $this->url . 'data/upload/a.jpg',
                    'add_time' => $v['add_time'],
                    'lazhu' => $v['lazhu'],
                    'zhiqian' => $v['zhiqian'],
                    'shangxiang' => $v['shangxiang'],
                    'xianhua' => $v['xianhua'],
                    'coll_cou' => $coll_cou,
                    'username' => $v['username']
                );
            }
            $this->_tojson('1', 'success', $data);
        } else {
            $this->_tojson('-1', '暂无信息');
        }
        M('jisiguan_coll')->where()->getField('g_id', true);

    }


    /**
     * 搜索祭祀列表
     */
    public function search_jsg_list()
    {
        $search = $this->_request('search');
        if ($search) {
            $map['g.title'] = array('like', '%' . $search . '%');
        }
        $map['g.status'] = 1;
        $jisiguan = M('jisiguan')
            ->alias('g')
            ->where($map)
            ->join('iqw_jisiguan_list as l on g.id = l.g_id')
            ->join('iqw_user as u on g.user_id = u.id')
            ->field('g.*,u.username,sum(l.lazhu) lazhu,sum(l.zhiqian) zhiqian,sum(l.shangxiang) shangxiang,sum(l.xianhua) xianhua')
            ->group('g.id')
            ->order('g.ordid desc,g.id desc')
            ->select();
        if ($jisiguan) {
            $data = array();
            $coll = M('jisiguan_coll');
            foreach ($jisiguan as $k => $v) {
                $coll_cou = $coll->where(array('g_id' => $v['id']))->count('id');
                $data[$k] = array(
                    'id' => $v['id'],
                    'user_id' => $v['user_id'],
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'add_time' => $v['add_time'],
                    'lazhu' => $v['lazhu'] ? $v['lazhu'] : 0,
                    'zhiqian' => $v['zhiqian'] ? $v['zhiqian'] : 0,
                    'shangxiang' => $v['shangxiang'] ? $v['shangxiang'] : 0,
                    'xianhua' => $v['xianhua'] ? $v['xianhua'] : 0,
                    'img_url' => $v['img_url'] ? $this->url . $v['img_url'] : $this->url . 'data/upload/a.jpg',
                    'username' => $v['username'],
                    'is_open' => $v['is_open'],
                    'code' => $v['code'],
                    'coll_cou' => $coll_cou
                );
            }
            $this->_tojson('1', 'success', $data);
        } else {
            $this->_tojson('-1', '暂无信息');
        }
    }


    /**
     * 我发布的祭祀列表
     */
    public function user_jsg_list()
    {
        $user_id = $this->_request('user_id');
        if (empty($user_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $map['g.user_id'] = $user_id;
        $map['g.status'] = 1;
        $jisiguan = M('jisiguan')
            ->alias('g')
            ->where($map)
            ->join('iqw_jisiguan_list as l on g.id = l.g_id')
            ->join('iqw_user as u on g.user_id = u.id')
            ->field('g.*,u.username,sum(l.lazhu) lazhu,sum(l.zhiqian) zhiqian,sum(l.shangxiang) shangxiang,sum(l.xianhua) xianhua')
            ->group('g.id')
            ->order('g.ordid desc,g.id desc')
            ->select();
        if ($jisiguan) {
            $data = array();
            $coll = M('jisiguan_coll');
            foreach ($jisiguan as $k => $v) {
                $coll_cou = $coll->where(array('g_id' => $v['id']))->count('id');
                $data[$k] = array(
                    'id' => $v['id'],
                    'user_id' => $v['user_id'],
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'add_time' => $v['add_time'],
                    'lazhu' => $v['lazhu'] ? $v['lazhu'] : 0,
                    'zhiqian' => $v['zhiqian'] ? $v['zhiqian'] : 0,
                    'shangxiang' => $v['shangxiang'] ? $v['shangxiang'] : 0,
                    'xianhua' => $v['xianhua'] ? $v['xianhua'] : 0,
                    'img_url' => $v['img_url'] ? $this->url . $v['img_url'] : $this->url . 'data/upload/a.jpg',
                    'username' => $v['username'],
                    'is_open' => $v['is_open'],
                    'code' => $v['code'],
                    'coll_cou' => $coll_cou
                );
            }
            $this->_tojson('1', 'success', $data);
        } else {
            $data = array();
            $this->_tojson('1', 'success',$data);
        }
    }


    /**
     * ss删除
     */
    public function ss_delete()
    {
        $user_id = $this->_request('user_id');
        $l_id = $this->_request('l_id');
        if (empty($user_id) || empty($l_id)) {
            $this->_tojson('-1', '参数缺失！');
        }

        $info = M('jisiguan_list')->where(array('id' => $l_id))->find();
        if ($info['user_id'] != $user_id) {
            $this->_tojson('-1', '非法删除！');
        }

        M('jisiguan_list')->where(array('id' => $l_id))->delete();
        $this->_tojson('1', 'success', 1);
    }

    /**
     * 编辑
     */
    public function ss_update()
    {
        $l_id = $this->_request('l_id');
        $user_id = $this->_request('user_id');
        $save['title'] = $this->_request('title');
        $save['content'] = $this->_request('content');
        $save['cs_time'] = $this->_request('ss_time');
        $save['ss_time'] = $this->_request('ss_time');
        $save['age'] = $this->_request('age');
        $save['sex'] = $this->_request('sex');
        $save['add_time'] = time();
        $img_arr = $this->_request('img_arr');

        if (empty($l_id) || empty($user_id) || empty($save['title']) || empty($save['content'])) {
            $this->_tojson('-1', '参数缺失！');
        }

        $info = M('jisiguan_list')->where(array('id' => $l_id))->find();
        if ($info['user_id'] != $user_id) {
            $this->_tojson('-1', '不可修改他人数据！');
        }

        M('jisiguan_list')->where(array('id' => $l_id))->save($save);

        //修改图片
        $imgModel = M('jisiguan_list_img');
        $img_arr = explode(',', $img_arr);
        $imgModel->where(array('list_id' => $l_id))->delete();
        foreach ($img_arr as $k => $v) {
            $img_add = array();
            $img_add['list_id'] = $l_id;
            $img_add['img_url'] = $v;
            $img_add['add_time'] = time();
            $imgModel->add($img_add);
        }
        $this->_tojson('1', 'success', $l_id);
    }


    /**
     * 行为滚动
     */
    public function xw_list()
    {
        $l_id = $this->_request('l_id');
        if (empty($l_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $list = M('jisiguan_xw')->where(array('list_id' => $l_id))->order('id desc')->select();
        $xwarr = array('蜡烛', '纸钱', '上香', '鲜花');
        $user = M('user');
        foreach ($list as $k => $v) {
            $list[$k]['xw'] = $xwarr[$v['xw_type']];
            $list[$k]['add_time'] = date("Y-m-d H:i:s", $v['add_time']);
            $uinfo = $user->where(array('id' => $v['user_id']))->find();
            $list[$k]['username'] = $uinfo['username'];
            $list[$k]['avatarUrl'] = $uinfo['avatarUrl'];
        }
        $this->_tojson('1', 'success', $list);
    }

    /**
     * 删除馆子
     */
    public function g_delete()
    {
        $user_id = $this->_request('user_id');
        $g_id = $this->_request('g_id');
        if (empty($user_id) || empty($g_id)) {
            $this->_tojson('-1', '参数缺失！');
        }

        $info = M('jisiguan')->where(array('id' => $g_id))->find();
        if ($info['user_id'] != $user_id) {
            $this->_tojson('-1', '非法删除！');
        }

        $cou = M('jisiguan_list')->where(array('g_id' => $g_id, 'status' => 1))->count('id');
        if ($cou) {
            $this->_tojson('-1', '请先删除逝者');
        }
        M('jisiguan')->where(array('id' => $g_id))->delete();
        $this->_tojson('1', 'success', 1);
    }


    /**
     * 馆子信息
     */
    public function g_info()
    {
        $g_id = $this->_request('g_id');
        if (empty($g_id)) {
            $this->_tojson('-1', '参数缺失！');
        }
        $info = M('jisiguan')->where(array('id' => $g_id))->find();
        $info['img_urlp'] = $info['img_url'] ? $this->url . $info['img_url'] : $this->url . 'data/upload/a.jpg';

        $this->_tojson('1', 'success', $info);
    }

    /**
     * 编辑馆子
     */
    public function g_update()
    {
        $g_id = $this->_request('g_id');
        $user_id = $this->_request('user_id');
        $save['title'] = $this->_request('title');
        $save['content'] = $this->_request('content');
        $save['is_open'] = $this->_request('is_open') ? $this->_request('is_open') : '';
        $save['code'] = $this->_request('code') ? $this->_request('code') : '';
        $save['add_time'] = time();
        $save['img_url'] = $this->_request('img_url');

        if (empty($user_id) || empty($save['title']) || empty($save['content'])) {
            $this->_tojson('-1', '参数缺失！');
        }

        //私有
        if ($save['is_open'] == 1 && empty($save['code'])) {
            $this->_tojson('-1', '私有馆邀请码不可为空！');
        }
        M('jisiguan')->where(array('id' => $g_id))->save($save);
        $this->_tojson('1', 'success', $g_id);
    }

}