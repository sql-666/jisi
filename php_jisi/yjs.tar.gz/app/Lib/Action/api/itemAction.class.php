<?php

/**

 * BP项目接口文件

 */

class itemAction extends apibaseAction{

    public function _initialize() {
		parent::_initialize();
    }
	
	
	
	/**
	*	获取项目行业,红包金额
	*/
	public function industry_list(){
		$arr['indu_list'] = M("industry")->where("status = 1")->field("id,name")->select();
		$otherModel = M("other_set");
		$arr['hb_price'] = $otherModel->where("id = 19")->getField("name");//红包金额
		$arr['sm_price'] = $otherModel->where("id = 21")->getField("name");//私密金额
		$this->_tojson("1","success",$arr);
	}
	
	
	
	
	/**
	*	提交项目
	*/
	public function moments_add(){
		$user_id = $this->is_login();	
		$checked = $_POST['checked'];
		if($checked == 'true'){
			$issm = 1;
		}else{
			$issm = 0;
		}
		
		
		$otherModel = M("other_set");
		$hb_price = $otherModel->where("id = 19")->getField("name");//红包金额
		$sm_price = $otherModel->where("id = 21")->getField("name");//私密金额
		
		$uinfo = M("user")->where("id = ".$user_id)->find();
		$add['user_id'] = $user_id;	
		$add['order_sn'] = date('ymd').mt_rand(10000000,99999999);
		$add['type_name'] = $_POST['sta_name'];//行业名称
		$add['type_id'] = $_POST['type_id'];//行业id
		$add['title'] = strim($_POST['title_input']);//项目名称
		$add['contents'] = strim($_POST['text_info']);//描述
		$add['hb_num'] = 5;//红包数量
		
		//计算价格
		if($issm == 1){
			$money = ($hb_price * 5) + ($sm_price * 5);
		}else{
			$money = $hb_price * 5;
		}
		
		$add['money'] = $money;//红包价格
		$add['hb_private'] = $issm;//是否私密
		$add['tp_img'] = $_POST['str_tp'];//项目图片
		$add['add_time'] = time();

		//是否用余额抵扣
		$retu['is_wxpay'] = 1;
		if($_POST['is_amount']){
			//用余额抵扣  如果余额足够
			if($uinfo['money'] >= $add['money']){
				$add['amount'] = $add['money'];
				$add['pay_money'] = 0 ;
				$add['pay_status'] = 1;
				$add['pay_time'] = time();
				$retu['is_wxpay'] = 0;
				M("user")->where("id = ".$user_id)->setDec("money",$add['money']);
				
				//写日志
				$ldata['uid'] = $user_id;
				$ldata['mname'] = "创业者发红包";	
				$ldata['uname'] = $uinfo['phone'];
				$ldata['action'] = "sysman";
				$ldata['score'] = -$add['money'];
				$ldata['add_time'] = time();
				$ldata['balance'] = $uinfo['money'] - $add['money'];
				$ldata['content'] = $add['type_name']."问项发红包".$add['money']."元";
				M("balance_log")->add($ldata);
				
			}else if($uinfo['money'] > 0 && $uinfo['money'] < $add['money']){//如果余额不足够
				$add['amount'] = $uinfo['money'];
				$add['pay_money'] = $add['money'] - $uinfo['money'];	
			}else{//如果没有余额
				$add['pay_money'] = $add['money'];	
			}
		}else{
			$add['pay_money'] = $add['money'];	
		}
        $userArr = array(267,297);
        if(in_array($user_id,$userArr)){
            $add['hb_num'] = 0;//红包数量
            $add['money'] = 0;//红包金额
            $retu['is_wxpay'] = 0;
            $add['pay_status'] = 1;
            $add['pay_time'] = time();
        }
		$yes = M("item")->add($add);
		
		//获得可以看到此项目的随机5个用户
		$itemcan = M("item_can");
		$red = M('item_red');
		$is_view = explode(",",$add['type_id']);
		foreach($is_view as $k=>$v){
			$where .= $where ? " or type_id like '%".$v."%'" : " type_id like '%".$v."%'";
		}
		$sjarr = M("user")->query("select id from iqw_user where ".$where." order by rand() limit 20");
		foreach($sjarr as $k=>$v){
			$can['user_id'] = $v['id'];
			$can['item_id'] = $yes;
			$itemcan->add($can);//可看项目者
			$red->add($can);//投资者添加红点记录
		}
		$retu['oid'] = $yes;
		if($yes){
			$red_add = array(
						'item_id'=>$yes,
						'user_id'=>$user_id
					   );
			$red->add($red_add);//发布者添加红点记录
			
			$this->_tojson("1","success",$retu);
		}else{
			$this->tojson("-1","提交失败");	
		}
	}
		
	/**
     * 微信支付
     *
     **/
    public function wxpay(){
		$user_id = $this->is_login();
		$code = $_GET['code'];
		include_once EXTEND_PATH."WechatAppPay.php";
		include_once EXTEND_PATH."wxPay/WxPay.Api.php";
		$order = M('item')->where('id = '.$_GET['oid'])->find();
		if(!$order) tojson('-1','订单不存在,已支付或已取消');
		
		$bname = 'BP支付';	
		$notify_url = $this->url.'notify_wx.php';
		
		$input = new \WxPayDataBase();
		$total_fee = $order['pay_money']*100;
		
		$body = mb_substr($bname,0,32,"UTF-8");
		
		$input->setData('notify_url',$notify_url);
		
		$input->setData('body',$body); //长度128
		
		$input->setData('out_trade_no',$order['order_sn']);
		
		$input->setData('total_fee',$total_fee);
		
		$input->setData('openid',$code);
		
		$wxData = \WxPayApi::unifiedOrder($input);
		
		if($wxData['return_code']=='FAIL' || !$wxData['prepay_id']) $this->_tojson('-200','fail',$wxData);
		
		unset($input);
		
		$jsPay = new \wxJsPay();
		
		$timeStamp = time();
		
		$jsPay->setData('timeStamp',"$timeStamp");
		
		$jsPay->setData('package',"prepay_id=".$wxData['prepay_id']);
		
		$jsPay->setData('signType','MD5');
		
		$jsPay->SetAppId();
		
		$jsPay->SetNonce_str();
		
		$jsPay->SetSign();
		
		tojson('1','success',$jsPay->GetValues());
		
    }
	
	
	
	
	
	
	
	/**
	*	问卷记录
	*/
	public function wj_log(){
		$user_id = $this->is_login();	
		$item_list = M("item")->where("user_id = ".$user_id." and status = 1 and pay_status = 1")->order("id desc")->select();
		$red = M('item_red');
		foreach($item_list as $k=>$v){
			$item_list[$k]['add_time'] = date("Y-m-d H:i:s",$v['add_time']);	
			$item_list[$k]['red_num'] = $red->where(array('user_id'=>$user_id,'item_id'=>$v['id']))->getField('num');
		}
		$this->_tojson("1","success",$item_list);
	}
	
	/**
	*	问卷详情
	*/
	public function item_info(){
		$user_id = $this->is_login();
		$item_id = $_GET['item_id'];
		$item_list = M("item")->where("id = ".$item_id)->find();
		$img = explode(",",$item_list['tp_img']);
		foreach($img as $k=>$v){
			$item_list["img"][$k] = $this->url.$v;	
		}
		
		//添加查看的项目  并且不是自己发布的
		$cou = M("item_seen")->where(array('user_id'=>$user_id,'item_id'=>$item_id))->count('id');
		if(empty($cou) && $item_list['user_id'] != $user_id){
			$add['user_id'] = $user_id;
			$add['item_id'] = $item_id;
			$add['add_time'] = time();
			M("item_seen")->add($add);
			
			//添加红点
			$red_cou = M("item_red")->where(array('user_id'=>$user_id,'item_id'=>$item_id))->count('id');
			if(empty($red_cou)){
				$red_add['user_id'] = $user_id;
				$red_add['item_id'] = $item_id;
				M("item_red")->add($red_add);
			}
		}
		
		$retu['item_list'] = $item_list;
		$cou = M('item_pl')->where(array('item_id'=>$item_id,'user_id'=>array('neq',$item_list['user_id'])))->group('user_id')->order('id desc')->select();
		$retu['pj_cou'] =  count($cou);//M("item_pl")->where(array("item_id"=>$item_id))->distinct('user_id')->count('id');
		
		//清除红点
		M('item_red')->where(array('user_id'=>$user_id,'item_id'=>$item_id))->save(array('num'=>0));
		
		$this->_tojson("1","success",$retu);
	}
	
	
	//添加评论
	public function addPingLun(){
		$user_id = $this->is_login();	 
		$pl_id = $_POST['pl_id'];
		$item_id = $_POST['item_id'];
		$content = $_POST['content'];
		
		$add['content'] = $this->badword(preg_replace('/(\d{5})\d{4}(\d{2})/', '$1****$2',$content));
		$add['user_id'] = $user_id;
		$add['add_time'] = time();
		if($pl_id == 1){
			$add['item_id'] = $item_id;
			$yes = M("item_pl")->add($add);
		}else{
			$info = M("item_pl")->where(array("id"=>$pl_id))->find();	
			if($info){
				$add['item_id'] = $info['item_id'];
				$add['parent_id'] = $pl_id;
				$yes = M("item_pl")->add($add);
			}
		}	
		
		if($yes){
		    if($pl_id != 1){
                $itemInfo = M("item")->where(array("id"=>$add['item_id']))->find();
                $title = $itemInfo['title'];//评论主题
                $content = msubstr($add['content'],0,20);//评论内容
                $mbid = "Ysg35hIdpj5xyMfERZ7aDwU6JEBroTo9Q02bSVVI9vU";//模板id
                $plInfo = M("user")->where(array("id"=>$user_id))->find();
                $userName = $plInfo['the_user']."(".$plInfo['con_name'].")";//回复者
                $plUserId = M("item_pl")->where(array('id'=>$pl_id))->getField("user_id");
                $openid = M("user")->where(array("id"=>$plUserId))->getField("openid");//获取openid
                if($itemInfo['user_id'] == $user_id){//如果是自己回复他人。就给他人发微信模板消息
                    $url = "pages/cast/look-proform?item_id=".$add['item_id'];//跳转路径  投资者路径
                }elseif($pl_id != 1){//如果是他人回复自己。就给自己发微信模板信息
                    $url = "pages/asked-detail/asked-detail?item_id=".$add['item_id'];//跳转路径  创业者路径
                }
                if($openid){
                    $this->sendtpl($openid,$mbid,$title,$content,$userName,$url);
                }
            }

			M('item_red')->where(array('item_id'=>$add['item_id']))->setInc('num');//添加红点数量
			M('item_red')->where(array('item_id'=>$add['item_id'],'user_id'=>$user_id))->setField(array('num'=>0));
			$this->_tojson("1","success",$yes);
		}else{
			$this->_tojosn("-1","评论失败");	
		}
	}


    //敏感词过滤
	public function badword($str){
		include "app/Extend/Vendor/badword/badword.php";
		$badword1 =array_combine($badword,array_fill(0,count($badword),'*'));
		$str = strtr($str,$badword1);
		return $str;
	}
	

	
	//上传图片
	public function tpupload_file(){
		//取得上传文件信息
		$fileName = $_FILES['file']['name'];
		$fileType = $_FILES['file']['type'];
		$fileError = $_FILES['file']['error'];
		$fileSize = $_FILES['file']['size'];
		$tempName = $_FILES['file']['tmp_name'];//临时文件名
		
		//定义上传文件类型
		$typeList = array("image/jpeg","image/jpg","image/png","image/gif"); //定义允许的类型
		
		if($fileError>0){
			//上传文件错误编号判断
			switch ($fileError) {
				case 1:
					$message="上传的文件超过了php.ini 中 upload_max_filesize 选项限制的值。"; 
					break;
				case 2:
					$message="上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值。"; 
					break;
				case 3:
					$message="文件只有部分被上传。"; 
					break;
				case 4:
					$message="没有文件被上传。";
					break;
				case 6:
					$message="找不到临时文件夹。"; 
					break;
				case 7:
					$message="文件写入失败"; 
					break;
				case 8:
					$message="由于PHP的扩展程序中断了文件上传";
					break;
			}
		
			exit("文件上传失败：".$message);
		
		}
		if(!is_uploaded_file($tempName)){
			//判断是否是POST上传过来的文件
			exit("不是通过HTTP POST方式上传上来的");
		}else{
			if(!in_array($fileType, $typeList)){
				exit("上传的文件不是指定类型");
			}else{
				if(!getimagesize($tempName)){
					//避免用户上传恶意文件,如把病毒文件扩展名改为图片格式
					exit("上传的文件不是图片");
				}
			}
			if($fileSize>1000000){
				//对特定表单的上传文件限制大小
				exit("上传文件超出限制大小");
			}else{
				//避免上传文件的中文名乱码
				$fileName=iconv("UTF-8", "GBK", $fileName);//把iconv抓取到的字符编码从utf-8转为gbk输出
				$fileName=str_replace(".", time().".", $fileName);//在图片名称后加入时间戳，避免重名文件覆盖
				
				$ext = $this->getExtName($fileName);//获取后缀名
				$newName = $this->getnewName();//生成文件名
				
				$sjs = rand(1000,9999);//避免多图上传文件同名
				$filepath = "data/upload/item/".$newName.$sjs.".".$ext;
				
				if(move_uploaded_file($tempName, $filepath)){
					$file_name = $filepath;
				}
			}
		}
		echo $file_name;exit;
		
	}
	
	//获得上传图片类型，JPG.PNG。。
	public function getExtName($namexx){
		$arr=pathinfo($namexx);
		$ext=$arr["extension"];
		return $ext;
	}
	
	//根据日期加密方式来给图片命名
	public function getnewName(){
		$newName=date("YmdHis");
		return $newName;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}