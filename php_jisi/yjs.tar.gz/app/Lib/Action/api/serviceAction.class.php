<?php

/**

 * BP项目接口文件

 */

class serviceAction extends apibaseAction{

	
    public function _initialize() {
		parent::_initialize();
    }
	
	//服务列表
	public function service_list(){
		$list = M("service")->where(array("status"=>1))->select();	
		foreach($list as $k=>$v){
			$list[$k]['imgurl'] = $this->url."data/upload/service_img/".$v['img'];
		}
		$this->_tojson("1","success",$list);
	}
	
	//服务详情
	public function service_item(){
		$info = M("service")->where(array("id"=>$_GET['ser_id']))->find();	
		
		$info['info'] = str_replace("/data/upload/editer/image/",$this->url."data/upload/editer/image/",$info['info']);
		$this->_tojson("1","success",$info);
	}
	
}